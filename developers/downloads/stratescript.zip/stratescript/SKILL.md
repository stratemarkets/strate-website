---
name: stratescript
description: Write, check and fix StrateScript code for the Strate trading platform — custom indicators, simulated strategies (backtests) and research studies on futures charts, from simple moving averages to order flow, footprint, cumulative delta, the order book and full order-by-order (MBO) data such as absorption, icebergs, refills, sweeps, pulled liquidity and queue position. Use this skill whenever the user mentions Strate, StrateScript, a `.strate` file, "My indicators", or asks for an indicator, strategy, backtest, signal, alert, pattern or study to run in Strate, even if they only describe the trading idea (e.g. "mark big prints", "absorption at the bid", "test a delta divergence fade") without naming the language.
license: Proprietary. Provided for use with Strate.
---

# StrateScript

StrateScript is the scripting language built into Strate. One script is one of three kinds:

| Kind | Header | Use |
|---|---|---|
| Indicator (default) | `indicator "Name" { overlay: true }` | Draws on the chart, alerts. |
| Strategy | `strategy "Name" { costs: { commission: 2.5 usd, slippage: 1 tick } }` | **Simulated** orders + a Report. Never sends a real order. `costs:` is required. |
| Research | `research "Name" { overlay: true }` | Measures what happens after a signal: `study()`, `report()`, `compare()`. |

The body runs once per bar, oldest to newest. Event handlers (`on trade`, `on order`, `on match`, `on book`, …) and
patterns run on market events, all before the body of their bar.

Your knowledge of other trading languages does not transfer reliably: StrateScript has its own names, units and rules.
Write from the references in this skill, not from memory of similar languages.

## Workflow

### 1. Understand the request

Pin down, from the request or by stating assumptions:

- **Instrument and units.** Tick size matters (ES: tick 0.25, point value 50). Distances are in ticks or points — see
  the units rule below.
- **Chart unit.** Time bars (`1m`, `5s`…) or range/renko/volume/delta/tick/reversal bars.
- **Where it runs.** Live chart, Replay of a recorded session, or long backtest on local MBO replay files. Long
  backtests have no book snapshots, no footprint, no drawings, no `request(…, symbol:)`.
- **Data depth needed.** Bars only → bars + footprint → trades one by one → book snapshots (250 ms) → order-by-order
  (MBO). Pick the shallowest level that answers the question. MBO-only code still runs without MBO; it just gets `na`.
- **What the user wants to control.** Every threshold, window and color they might tune becomes a setting. So does
  every horizon hidden in a word: "holds" (for how long?), "near" (how many ticks, from which price?), "large", "fast",
  "after", "refill" (within what delay?). Give each a stated default, never a buried constant.
- **Numbers without a unit.** "Stop 4" may mean 4 ticks or 4 points, and in StrateScript `stop: 4` means 4 **points**.
  Never translate silently: ask, or put the unit in the setting's title (`Stop (ticks)`) and say which one you used.
- **Raw sizes given by the user** ("200 lots"): keep them as the default, but say how common such a value is if you
  know (on ES, the size shown at the best price is often several hundred contracts in RTH), and offer a normalized unit.
- **Missing material.** "Change my strategy" without the script: ask for it; never rebuild "their" script from guesses.
  A missing entry rule is a question, not an invention; if you show a placeholder, label it as one.
- **Requests that need the future** (tomorrow's high, a bar's close before it closes, an outcome used to filter its own
  entry): say it cannot be done honestly, why in one sentence, and offer the closest causal version.
- **Contradictions.** When the request cannot hold as stated (a fade whose stop "at the other side of the range" sits
  beyond the target), ask; if you write it anyway, say in the first lines of your answer which reading you chose.
- **Language.** Write all user-visible text (setting titles, plot titles, labels, alerts) in one language: the user's,
  unless they ask otherwise.

If one point truly cannot be guessed, ask one short question. Otherwise choose the most likely reading and write the
assumptions as `//` comments at the top of the script, and repeat them in your answer.

### 2. Choose the kind and the building blocks

- Drawing or alerting → `indicator`. Price-scale things (levels, bands, labels on price) → `overlay: true`. Anything on
  another scale (volume, delta, CVD, ratios, ranks, z-scores, counts) → `overlay: false` (its own pane), otherwise it is
  drawn off-screen.
- "Would this have made money / how often does X work" → `strategy` (P&L with stops, targets, costs) or `research`
  (outcome distribution after a signal at fixed horizons). Research is the right first step for a new idea.
- Start from a template in `assets/templates/` (see the table at the end) rather than from a blank page.

### 3. Write the script

Follow the core rules below. Read the reference file for any area you use (table at the end): the exact field names,
defaults and errors are there. Prefer the raw primitives (`mbo.level`, `on order`, `norm.*`) and write the definition
in the open, so the user can read and change every step.

### 4. Verify — always, before giving the script

Run the bundled checker, which calls the check of the user's running Strate app on this machine:

```
python3 scripts/verify.py my_script.strate           # one or more .strate files
python3 scripts/verify.py answer.md                  # every ```strate block of a Markdown file
cat script.strate | python3 scripts/verify.py -      # from standard input
```

It prints `OK` with the plots and settings the script declares, or the error code, line, column, message and suggested
fix. It is the same check the StrateScript editor runs: the script is parsed, then executed on a synthetic market (300
one-minute ES bars of a single RTH afternoon, small orders, MBO events on the last 60 bars). The check only reads the
script: it changes no chart, script or setting in the app, so it is safe to run while the user works. Details, options
and limits: `references/verification.md`.

**`OK` means the script ran, not that every branch ran.** Read the `events` line: when a branch never fired (realistic
thresholds, previous-day levels, session resets, rare MBO cases never happen on that market), force it in a temporary
copy and check again (`references/verification.md` › Covering branches).

If the checker reports that Strate is not reachable (the app is not running, or this agent runs on another machine),
say so plainly, review the script against `references/checklist.md`, and ask the user to paste it and report the red
error box if one appears. Never claim a script was verified when it was not.

### 5. Fix

Use the error code: `references/errors.md` gives the cause and the fix for every code. Fix, verify again, repeat until
`OK`. `request(…, symbol: "NQ")` always fails the check with E936: check the rest with that call replaced.

### 6. Hand the script over

Give the complete script in one ```strate block, then tell the user, briefly:

1. **Where to paste it.** In a chart's **Indicators** window, category **Custom**, add **StrateScript (preview)**. The
   StrateScript panel opens beside the chart; choose **Empty script** (or **+ New indicator** in the script menu at the
   top of the panel), go to mode **Code**, replace the editor's content with the script. It is checked as they type and
   runs about 250 ms after the last keystroke (**Run**, or ⌘↵ on a Mac, runs at once).
2. **Errors.** A red box under the editor shows `Line N · message` and often a fix; hovering its title shows the code
   (`E930 · column 10`). Ask them to send you that text if it appears.
3. **Settings.** List the settings the script exposes (the checker prints them) and what each one does. They are in
   mode **Parameters** › **Settings**.
4. **Keeping it.** Script menu › **Add to My indicators** keeps a named script on the chart and lists it in the
   **My indicators** category for any chart. The script needs a non-empty name.
5. **Strategies and research.** Results are in mode **Parameters** › **Report** (with DEV/VAL halves, a day bootstrap
   interval, sweeps of one setting, CSV export, long backtests on local MBO replay files).
6. **Data needs and depth.** Say when the script needs MBO data (Replay of a recorded session, live with Strate's MBO
   recording, or a long backtest) or book data, and that without it the MBO values are `na` and nothing is drawn,
   without error. Say how far back it sees: an indicator gets MBO for the last **30 minutes** by default
   (`mbo_history:`) and book snapshots for 2 hours; a strategy or research script on a chart reads MBO from a fixed
   start (default: the latest 9:30 or 18:00 at launch), so its Report covers only that; many days need a long backtest.
   A script creating objects (`label.new`…) from events keeps at most 500 of them: the oldest disappear.
7. **Assumptions and limits.** Repeat the assumptions you made and anything the check could not exercise.

## Core rules (the mistakes that cost the most)

1. **Header first**, at most one. Unknown header keys and unknown named arguments are **ignored silently**:
   `latancy: 60ms` keeps the default, `stopp: 4 ticks` places a trade with no stop. Spell them from the references.
2. **Units.** A quantity is a number literal, a space, a unit: `4 ticks`, `2 points`, `2.5 usd`. In `enter(stop:,
   target:)`, `study(stop:, target:, cost:)` and `costs: { slippage: }`, **a plain number is points**: `stop: 4` is
   16 ticks on ES. `4ticks` (no space) is E004. `n ticks` with a variable is E106: write `price(n)` (ticks → price
   distance); `ticks(d)` converts back.
3. **Durations** are written attached: `250ms`, `30s`, `5m` (minutes), `2h`. `5 m` with a space is an error. A duration
   compared with a plain number other than 0 is E922: compare with `5s`, or divide (`d / 1s`).
4. **`na`.** Every comparison with `na` is false, even `!=`. Test with `na(x)`, replace with `nz(x)`. Arithmetic with
   `na` gives `na`; division by zero gives `na`.
5. **Scope.** Plain `x = …` at the top level is a series reset to `na` at each bar. `var`/`state` keep their value
   (top level only). The first assignment inside a block creates a local: declare `y = na` at the top level first.
   Handlers see `state`/`var` variables, settings and constants; body series are `na` inside handlers.
6. **Per-bar accumulation from events:** `state n = 0`, increment in the handler, use `n` in the body, then reset it at
   the **end** of the body (`n = 0`).
7. **History** `x[n]` works on top-level variables and built-in series, not on expressions nor calls
   (`(a+b)[1]` and `highest(high, n)[1]` are E912: assign first, `hh = highest(high, n)`, then `hh[1]`) nor on
   function locals. A negative index reads the future (E911). `bar.footprint` inside a handler is E911.
8. **No future.** The language has no lookahead: `request(tf, …)` returns the last *closed* higher-timeframe bar,
   handlers only see the past, the bar still forming has `bar.confirmed == false`. Require `bar.confirmed` for markers,
   alerts and body entries that must not flicker on the live bar.
9. **Strings** do not add to numbers: `"n=" + str(n)` (E921 otherwise). `print` and `str` show a list as `na`.
10. **Comparisons** are not chainable (`a < b < c` is E114). `if a = b` is E100: use `==`.
11. **Positional arguments come before named ones** (E115). Functions, types, handlers, patterns and imports are
    declared at the top level only.
12. **Normalize at every event.** Call `norm.*` (and other stateful functions such as `ema`, `stats.*`, `crossover`)
    unconditionally, before the `and`/`if` that uses the result; otherwise their population only holds the filtered
    cases. In a pattern, compute them in the statements before `when`.
13. **Data loading is decided from the script's text.** Use the real names (`on trade`, `mbo.`, `book`, `footprint`…);
    aliasing `x = mbo` then `x.level(…)` gives `na`. A research script driven only by bars needs an empty
    `on trade(t) { }` so its studies can be measured.
14. **Long windows need history keys:** `mbo.level(…, window:)` beyond `level_history:` (default `2m`, max `30m`) and
    `of.*` windows beyond `flow_history:` (default `5m`, max `60m`) give E933. Add the header key the message gives.
15. **Time of a value.** In handlers and patterns, `session.*`, `bar.hour`, `bar.minute` describe the bar in progress
    (its open), not the event: use `session.in(range, event.time)`. A body decision is made at the bar's close: filter
    entries with `session.in(range, bar.close_time)`. Previous-day values (`prev.*`, `request("1d", …)`) are `na`
    until such a day exists in the data.
16. **Strategies:** `costs:` is required; one position at a time (exit before reversing); `limit`/`stop` entries need a
    non-`na` `price:`; no trailing stop parameter (manage it with `exit()`); `persist` is not allowed (use `var`).

## Product principles to respect

- **The user decides.** Never hard-code a threshold the user may want to tune: make it an `input.*`. Do not present
  any value as "optimal" or "best"; give sensible defaults and say they are starting points.
- **Raw primitives over recipes.** Absorption, icebergs or spoofing have no single correct formula. Write the
  definition explicitly with `mbo.level`, `on order`, `on match`, `norm.*`, or import a shipped definition and say it
  is one competing definition among several (`references/patterns.md`).
- **Normalization is a choice.** When a raw threshold would depend on the instrument or the hour, offer a unit choice
  (`input.choice` + `norm.unit`: rank, zscore, x_median, x_mean, raw) instead of picking one silently.
- **Honest simulation.** Strategies and research are measured on real trades with latency, slippage and commission.
  Keep decisions causal, use `bar.confirmed`, keep costs realistic, judge on the VAL half, and look for a plateau in a
  sweep, never the best point. `references/strategies.md` has the rules.

## Reference map

Read only what the task needs.

| File | Read it for |
|---|---|
| `references/language.md` | Syntax, script kinds, every header key, types, operators, variables and scope, history, control flow, functions, custom types, collections, imports, units, budget |
| `references/builtins.md` | Bars, time, chart, instrument, sessions (first RTH bar, previous day, values inside handlers), `request`, moving averages, `stats.*`, `norm.*`, math, text formatting, colors, settings (`input.*`), footprint and imbalances |
| `references/order-flow.md` | `on trade` fields, what one trade is, `on order` (orders leaving the book, orders resting before the data, reloading orders), `on match`, `mbo.*`, `mbo.level` statistics, `book`, `of.*` (`of.cvd` resets), event order, MBO history (`mbo_from`, `mbo_history`…), what data exists where, what triggers loading |
| `references/patterns.md` | Event handlers, `pattern` blocks (`confirm:` timing, "holds for D"), `on signal`, custom clocks, the shipped pattern library and its override keys |
| `references/plotting.md` | Plots, fills, levels, markers, objects, tables, drawing in a bar's column, `stat`, panes and scales, alerts, `print` |
| `references/strategies.md` | `enter`/`exit`/`cancel`, units, stops at a price level, decision time and latency, trading hours, fill models, `position`, `on fill`/`on exit`, Report, sweeps, long backtests, causality rules |
| `references/research.md` | `study`, `report`, `compare`, how outcomes are measured, signals without patterns, choosing a normalization population |
| `references/errors.md` | Every error code with cause and fix |
| `references/limits.md` | Bounds, performance, what is not supported, pitfalls |
| `references/examples.md` | 16 complete verified scripts, from a moving average to MBO absorption, strategies and research |
| `references/verification.md` | How `scripts/verify.py` works, what `events` counts, the synthetic market, covering branches, what the check does not cover |
| `references/checklist.md` | Manual review when the checker cannot reach Strate |

## Templates (`assets/templates/`)

All of them pass the check as they are. Copy one, rename it, then edit.

| File | Starting point for |
|---|---|
| `indicator-overlay.strate` | Lines, bands, markers and alerts on the price chart |
| `indicator-pane.strate` | A measure in its own pane (delta, volume, ratios) |
| `trade-flow.strate` | Accumulating trades one by one into a per-bar value |
| `mbo-pattern.strate` | An order-by-order definition as a `pattern`, normalized, with explanations |
| `footprint.strate` | Reading and drawing the bar's footprint |
| `strategy-bars.strate` | A strategy deciding at bar close, stops/targets in ticks from settings |
| `strategy-events.strate` | A strategy deciding on MBO events, with `fill_model: queue` |
| `research-pattern.strate` | Studying the outcome of pattern signals |
| `research-events.strate` | Studying raw events without a pattern, comparing definitions |
