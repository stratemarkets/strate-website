#!/usr/bin/env python3
"""Check StrateScript code with the Strate app running on this computer.

The Strate app serves a local check on 127.0.0.1 (the same check its StrateScript editor runs before executing a
script). This tool sends each script to it and prints the result: OK with the plots and settings the script declares,
or the error code, line, column, message and suggested fix.

Usage:
  python3 verify.py script.strate [more.strate ...]
  python3 verify.py answer.md              # every ```strate block of a Markdown file
  cat script.strate | python3 verify.py -  # standard input
Options:
  --port N        port of the Strate app (default: try 18736, then 8736; or env STRATE_PORT)
  --import P=FILE text for an import path, e.g. --import my/Tools=tools.strate (repeatable)
  --json          print raw JSON results
  --quiet         print only failures and the summary
In a Markdown file, a block preceded by the line <!-- expect: E930 --> must fail with that code.
Exit code: 0 all OK, 1 at least one script failed, 2 Strate could not be reached (nothing was checked).

Only the Python standard library is used. Nothing is sent anywhere but 127.0.0.1. The check only reads the script:
it changes no chart, script or setting in the app.
"""
import json
import os
import re
import sys
import urllib.error
import urllib.request

DEFAULT_PORTS = [18736, 8736]
HOST = "127.0.0.1"
TIMEOUT = 60


class Unreachable(Exception):
    pass


def post_check(port, source, imports):
    body = json.dumps({"source": source, "imports": imports}).encode("utf-8")
    req = urllib.request.Request(
        "http://%s:%d/script/verifier" % (HOST, port), data=body, method="POST",
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise Unreachable("HTTP %d from port %d" % (e.code, port))
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise Unreachable("port %d: %s" % (port, getattr(e, "reason", e)))
    if not isinstance(data, dict) or "ok" not in data:
        raise Unreachable("port %d answered, but not like Strate's check" % port)
    return data


def fetch_library(port, name):
    """Text of a shipped definition (import "strate/patterns/<name>"), served by the running app."""
    if not re.fullmatch(r"[A-Za-z0-9_\-]+", name):
        return None
    url = "http://%s:%d/bibliotheque/patterns/%s.strate" % (HOST, port, name)
    try:
        with urllib.request.urlopen(url, timeout=TIMEOUT) as r:
            return r.read().decode("utf-8")
    except Exception:
        return None


def find_port(explicit):
    ports = [explicit] if explicit else DEFAULT_PORTS
    errors = []
    for p in ports:
        try:
            post_check(p, "x = 1\n", {})
            return p
        except Unreachable as e:
            errors.append(str(e))
    raise Unreachable("; ".join(errors))


def script_name(src):
    """Name in the header (indicator/strategy/research "Name"), or None."""
    for line in src.splitlines():
        s = line.strip()
        if not s or s.startswith("//"):
            continue
        m = re.match(r'(indicator|strategy|research)\s+"([^"]*)"', s)
        return m.group(2) if m else None
    return None


def import_paths(src):
    return re.findall(r'^\s*import\s+"([^"]+)"', src, re.M)


def load_inputs(args):
    """List of (label, source, expected error code or None)."""
    items = []
    for a in args:
        if a == "-":
            items.append(("<stdin>", sys.stdin.read(), None))
            continue
        with open(a, encoding="utf-8") as f:
            text = f.read()
        if a.lower().endswith(".md"):
            lines = text.splitlines()
            i = 0
            while i < len(lines):
                if lines[i].strip().startswith("```strate"):
                    start = i + 1
                    expect = None
                    k = i - 1
                    while k >= 0 and not lines[k].strip():
                        k -= 1
                    m = re.match(r"<!--\s*expect:\s*(E\d+)\s*-->", lines[k].strip()) if k >= 0 else None
                    if m:
                        expect = m.group(1)
                    body = []
                    i += 1
                    while i < len(lines) and not lines[i].strip().startswith("```"):
                        body.append(lines[i])
                        i += 1
                    items.append(("%s:%d" % (a, start), "\n".join(body) + "\n", expect))
                i += 1
        else:
            items.append((a, text, None))
    return items


def fmt_default(kind, v):
    """Readable default value of a setting."""
    if kind == "duration" and isinstance(v, (int, float)):
        ns = int(v)
        for unit, size in (("h", 3600 * 10**9), ("m", 60 * 10**9), ("s", 10**9), ("ms", 10**6)):
            if ns and ns % size == 0:
                return "%d%s" % (ns // size, unit)
        return "%dns" % ns
    if kind == "int" and isinstance(v, float) and v.is_integer():
        return str(int(v))
    if isinstance(v, str):
        return json.dumps(v)
    return json.dumps(v)


def show_error(label, src, res):
    e = res.get("error", {})
    code, line, col = e.get("code", "?"), e.get("line", 0), e.get("column", 0)
    print("KO   %s  %s line %s, column %s: %s" % (label, code, line, col, e.get("message", "")))
    lines = src.splitlines()
    if isinstance(line, int) and 1 <= line <= len(lines):
        print("       %4d | %s" % (line, lines[line - 1]))
        if isinstance(col, int) and col >= 1:
            print("            | %s^" % (" " * (col - 1)))
    if e.get("fix"):
        print("       fix: %s" % e["fix"])
    if code == "E936" and "symbol" in src:
        print("       note: request(..., symbol:) always fails this check (no other instrument here); it can be fine on a chart.")


def main(argv):
    port, imports, files, as_json, quiet = None, {}, [], False, False
    it = iter(argv)
    for a in it:
        if a == "--port":
            port = int(next(it))
        elif a == "--import":
            spec = next(it)
            path, _, fname = spec.partition("=")
            with open(fname, encoding="utf-8") as f:
                imports[path] = f.read()
        elif a == "--json":
            as_json = True
        elif a == "--quiet":
            quiet = True
        elif a in ("-h", "--help"):
            print(__doc__)
            return 0
        else:
            files.append(a)
    if not files:
        print(__doc__)
        return 2
    if port is None and os.environ.get("STRATE_PORT"):
        port = int(os.environ["STRATE_PORT"])

    try:
        port = find_port(port)
    except Unreachable as e:
        print("NOT CHECKED: Strate's local check is not reachable (%s)." % e)
        print("Start the Strate app on this computer, or paste the script into the StrateScript panel and read its error box.")
        return 2

    items = load_inputs(files)
    # scripts given together can import each other as my/<Name>, like scripts of the same chart
    for _, src, _ in items:
        n = script_name(src)
        if n:
            imports.setdefault("my/" + n, src)

    failed, results = 0, []
    for label, src, expect in items:
        imp = dict(imports)
        for p in import_paths(src):
            if p.startswith("strate/patterns/") and p not in imp:
                t = fetch_library(port, p.split("/", 2)[2])
                if t is not None:
                    imp[p] = t
        try:
            res = post_check(port, src, imp)
        except Unreachable as e:
            print("NOT CHECKED: %s" % e)
            return 2
        results.append({"script": label, "result": res})
        if expect is not None:
            got = (res.get("error") or {}).get("code")
            if got != expect:
                failed += 1
            if not as_json and (got != expect or not quiet):
                print("%s   %s  expected %s, got %s" % ("OK" if got == expect else "KO", label, expect, got or "OK"))
            continue
        if not res.get("ok"):
            failed += 1
        if as_json:
            continue
        if res.get("ok"):
            if not quiet:
                outs = ", ".join("%s %s" % (o.get("kind"), json.dumps(o.get("title") or "")) for o in res.get("outputs", []))
                sets = ", ".join("%s (%s, default %s)" % (s.get("title"), s.get("type"), fmt_default(s.get("type"), s.get("default")))
                                 for s in res.get("settings", []))
                print("OK   %s" % label)
                print("       outputs: %s" % (outs or "none"))
                print("       settings: %s" % (sets or "none"))
                print("       events: %s, market events replayed: %s" % (res.get("events"), res.get("market_events")))
                if res.get("events") == 0:
                    print("       note: no marker, print, alert, signal, pattern signal or simulated order fired on the synthetic")
                    print("             market. Branches behind such conditions did not run: force them in a temporary copy")
                    print("             (references/verification.md, Covering branches).")
        else:
            show_error(label, src, res)
    if as_json:
        print(json.dumps(results, indent=2, ensure_ascii=False))
    summary = "CHECKED %d script(s) on port %d: %d OK, %d failed" % (len(items), port, len(items) - failed, failed)
    print(summary, file=sys.stderr if as_json else sys.stdout)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
