# The language

Contents: How a script runs · Lexical rules · Script kinds · Header keys · Types · Operators · Variables and scope ·
History · `bar.confirmed` · Control flow · Functions · Custom types · Collections · Imports · Units · Budget

A comment `// → text` after a `print(...)` shows what the line prints on the last bar of the check's synthetic market.

## How a script runs

- The **body** (top-level statements) runs once per bar, oldest bar to newest.
- **Event handlers** (`on trade`, `on order`, `on match`, `on book`, `on session`, …) and **event patterns** run on
  market events, in exchange order. All events of a bar run before the body of that bar.
- Patterns declared with `on: bar` are evaluated after the body of each bar.
- On a live chart the last bar is recalculated as data arrives, each time from the state of the previous bar, so nothing
  is counted twice.

## Lexical rules

| Element | Rule |
|---|---|
| Names | ASCII only: `[A-Za-z_][A-Za-z0-9_]*`. Accented letter → E005. |
| Comments | `// …` to end of line; `/* … */` (not nested; unclosed → E001). |
| Numbers | `20`, `0.5`, `1_000_000`, `1e3`, `2.5e-1`. Write `0.5`, never `.5` (E116). |
| Durations | Number + unit, **no space**: `ns us ms s m h d w`. `m` = minutes (no month unit). `1.5h` allowed. |
| Strings | `"…"` on one line. Escapes `\n \t \" \\`. A line break inside → E002. No `'…'` strings (E006). |
| Colors | `#RRGGBB` or `#RRGGBBAA` (`#26a69a80` = 50 % opacity). Other → E003. |
| Quantities | Number literal, **space**, unit word: `4 ticks`, `2 points`, `2.5 usd`. `4ticks` → E004. |

**Reserved words** (never variable names): `indicator research strategy pattern import as from fn type enum method var
state const persist on when if else for in while return break continue and or not true false na self`.

Built-in names (`close`, `plot`, `buy`…) are not reserved: assigning `close = 5` hides the built-in for the rest of the
script. Avoid it.

**Text constants** usable without quotes: `buy sell bid ask long short solid dashed dotted left right both center full`
(`side: right` = `side: "right"`).

**End of statement**: end of line or `;`. A line continues when it is inside `( … )` or `[ … ]`; or ends with an
operator, `,`, `?`, `:` or `.`; or the next line starts with `and`, `or`, `?`, `:`, `.`, `..`, `*`, `/`, `%`, `+`, a
comparison or `else`. A line starting with `-` is a new statement.

```strate
x = 1 +
  2
y = (1
  + 2)
ok = true
  and false
print(x, y, ok)   // → 3 3 false
```

## Script kinds

| Kind | Rules |
|---|---|
| `indicator "Name"` | Default without a header. Only kind that may use `persist` (and only with a non-empty name). |
| `strategy "Name"` | `costs:` required (E939). Only place for `enter`, `exit`, `cancel`, `position.*`, `on fill`, `on exit`. |
| `research "Name"` | Only place for `study()`, `report()`, `compare()` (E938 elsewhere). |

The name may be empty (`indicator ""`) but then the script cannot go to My indicators, be imported, or use `persist`.

## Header keys

```
indicator "Name" { key: value, key: value }
```

At most one header, before any other statement (E104). Entries separated by commas or line breaks.
**Unknown keys are ignored without error.** Values are literals written in the header (`level_history: 5m`): a setting
or a variable cannot set them, so a window setting that may exceed a history key must be clamped in code.

### Display keys (all kinds)

| Key | Values | Default | Error |
|---|---|---|---|
| `overlay` | `true` draws on prices; only the literal `false` creates a pane | `true` | — |
| `candles` | `false` hides the chart's candles while the script is shown | visible | — |
| `height` | pane height in px, 40–800 (user drag wins) | 140 | — |
| `background` | pane background `#rrggbb[aa]` | chart background | — |
| `min`, `max` | fixed pane scale bounds (one alone fixes one bound) | automatic | E942 if not a number or `min >= max` |
| `format` | `"compact"` (12.4k), `"volume"`, `"percent"` (adds %, does **not** multiply), `"price"` | plain | E942 |
| `precision` | axis decimals, 0–10 | automatic | E942 |
| `labels` | last-value tags on the right axis | on in a pane, off on prices | E942 |
| `visible_on` | text or list: bar types `"time" "range" "renko" "volume" "delta" "tick" "reversal"` or units `"5s" "1m" "1h" "1d" "1w" "8r" "4k" "500v" "300delta" "100t" "3x"` | everywhere | E942 |

A wrong type for `overlay`, `candles`, `height` or `background` is ignored silently.

### Engine keys (all kinds)

| Key | Values | Default | Error |
|---|---|---|---|
| `budget` | operations per bar and per event, 1–20,000,000 | 200,000 | E902 |
| `initial_balance` | IB length for `session.ib_high/low`, whole minutes `1m`–`390m` | `60m` | E942 |
| `level_history` | per-price MBO history kept for `mbo.level`, up to `30m` | `2m` | E942 |
| `flow_history` | trade/OFI history kept for `of.*`, up to `60m` | `5m` | E942 |
| `mbo_history` | indicators: rolling MBO window (no fixed maximum; bounded by the data that exists); strategy/research: fixed start = launch − duration, rounded down to the half hour | `30m` (indicators) | non-duration ignored |
| `book_history` | same for book snapshots | `2h` (indicators) | non-duration ignored |
| `mbo_from` | fixed MBO start: `auto`, `launch`, `rth`, `session`, `start`, `rolling`, or `"HH:MM"` (New York) | indicators `rolling`; strategy/research `auto` | E942 |
| `book_from` | same for book snapshots; falls back to `mbo_from` | as `mbo_from` | E942 |
| `mbo_max` | max MBO events held for one open bar, 1,000–100,000,000 | 25,000,000 | E942; E944 when exceeded |

### Strategy keys

| Key | Values | Default |
|---|---|---|
| `costs` | **required** `{ commission: 2.5 usd, slippage: 1 tick }` (literals) | — (E939) |
| `fill_model` | `through` (prudent), `touch`, `queue` — words without quotes | `through` |
| `latency` | duration ≥ 0 | `60ms` |

```strate
indicator "Delta pane" { overlay: false, height: 200, background: #0b1d33, min: -500, max: 500, format: "compact", precision: 0, labels: true }
histogram(delta, delta >= 0 ? #26a69a : #ef5350, title: "Delta")
hline(0, color: #888888)
```

```strate
indicator "Tuned" { overlay: true, visible_on: ["time", "8r"], budget: 5000000, initial_balance: 30m }
plot(session.ib_high, #e8c15a, title: "IB high")
plot(session.ib_low, #e8c15a, title: "IB low")
```

## Types

Dynamic typing. Annotations (`var x: float = 0`, `x: float` in parameters, `-> float`) are documentation only, never
checked. A bare `x: int = 3` (without `var`/`state`/`const`/`persist`) is E103.

| Type | From | Notes |
|---|---|---|
| number | `20`, `0.5` | 64-bit float; non-finite results become `na` |
| bool | `true`, `false` | |
| string | `"text"` | `+` joins; compared alphabetically |
| color | `#rrggbb[aa]`, `rgb()`, `alpha()`, `mix()`, `input.color()` | only `==`, `!=`; `str(color)` → `#rrggbbaa` |
| duration | `5s`, `input.duration()`, time − time | nanosecond precision |
| time | `bar.time`, `event.time`, `now()`, `.time` fields | an instant (ns since 1970 UTC) |
| na | `na` | missing value |
| list, map, ring, window | `[…]`/`array()`, `map()`, `ring(n)`, `window(d)` | references |
| object | instance of your `type` | reference |
| function | `fn(x) { … }` or a function's name | |
| plot handle | returned by `plot`, `histogram`, `candle`, `level`, `hline`, `bar_color`, `bg_color` | used by `fill` |
| library objects | footprint, level, trade, book, order event, match, resting order, level statistics, line, box, label, table | read fields with `.` |

Generic constructors `array<T>()`, `map<K, V>()`, `ring<T>(n)` are accepted. Write `window(10s)`, never `window<T>(…)`.

**Truth** (in `if`, `while`, `and`, `or`, `not`, `?:`, marker/alert/pattern conditions): `true` and finite non-zero
numbers are true; everything else (`false`, `0`, `na`, strings, colors, lists, objects) is false.

## Operators

Lowest to highest precedence: `?:` (right-assoc., only the chosen branch is evaluated) · `or` `||` · `and` `&&` ·
`not` `!` · `== != < <= > >=` (not chainable: E114) · `..` (only in `for`) · `+ -` · `* / %` · unary `-` ·
quantity `N unit` · call `()`, field `.`, index `[]`.

| Operands | Operators | Result |
|---|---|---|
| number, number | `+ - * / %` | `%` keeps the left sign (`-7 % 3` = `-1`) |
| string, string | `+`, comparisons | joined text; alphabetical |
| string + other type | `+` | E921: `str(x)` first |
| duration, duration | `+ -` → duration; `/` → number (`d / 1s` = seconds); comparisons | `*` → E920 |
| duration, number | `d * 2`, `2 * d`, `d / 2` → duration | `+ - <` with a number other than 0 → E922 |
| time − time | → duration | time + time → E920 |
| time ± duration | → time | |

**`na` rules**: arithmetic with `na` → `na`; division by zero → `na`; **every comparison with `na` is false, including
`!=`**; `and`/`or` short-circuit and return a bool.

```strate
d = 5s + 250ms
t = bar.time + 5m
print(d * 2, d / 1s, (t - bar.time) / 1m, 7 % 3, -7 % 3, 7 / 0)   // → 10500ms 5.25 5 1 -1 na
print(na != 1, na == na, not (na == 1), "a" < "b")                 // → false false true true
```

## Variables and scope

| Form | Where | Lifetime | `x[n]` |
|---|---|---|---|
| `x = expr` (first assignment, top level) | body | **series**: reset to `na` when each bar opens | yes |
| `var x = expr` | top level only (E903) | initialized once, kept bar to bar | yes |
| `state x = expr` | top level only | same as `var`; signals "shared with handlers" | yes |
| `const x = expr` | top level only | evaluated once on the first bar; assigning → E909 | yes |
| `persist x = expr` | top level, named `indicator` only (E943) | like `var` + saved across app restarts | yes |

- The first assignment inside a block (`if`, `for`, `while`) creates a **local**; reading it outside → E930. Declare it
  first at the top level (`y = na`).
- Assigning, inside a nested block, to a local that already exists (a handler's or function's local, changed in an
  `if`) changes that local; it never creates a second one.
- Assigning, from a block, function or handler, to a name that exists at the top level changes the top-level variable
  (also inside a function: `fn f() { g = 2 }` changes the top-level `g`).
- Functions see their parameters, their locals and top-level variables, not the caller's locals.
- `x += 1` on an undeclared name → E905.
- Collections and objects are references: after `b = a`, `b.push(2)` changes `a`.
- **Inside handlers and patterns**: `var`/`state`/`const`/`persist`, settings and `instrument.*` hold current values.
  So does a plain top-level variable computed only from literals, settings, `instrument.*` and other such variables
  with operators (`w = win > 2m ? 2m : win`, `dist = n * instrument.tick`). Any other plain variable (one that calls a
  function such as `price(n)` or `sma`, or reads bar data) is a body series: `na` in handlers — keep what handlers
  need in `state`, or compute it inside the handler. A value stored in `state` by the body is, inside a handler, the
  value from the last closed bar.
- Functions can read and change top-level `var`/`state` variables and collections (`fn bump(k) { m[k] = nz(m.get(k))
  + 1 }` updates a `state` map), from the body or from a handler.

```strate
indicator "Counters"
var bars = 0
state seen = 0
const k = 3
bars += 1
seen += 1
up = close > open ? 1 : 0
print(bars, bars[1], seen, k * 2, up[1] + up)
```

```strate
last_up = na
if close > open { last_up = close }
print(na(last_up) ? "down bar" : "up bar")
```

**`persist`**: data only (numbers, texts, bools, lists, maps, rings, your objects; a drawing, function, table,
footprint or book → E943). Identified by indicator name + instrument + chart unit + settings; live and Replay have
separate memories. Written after closed bars only. Bounds 256 KB, 50,000 values, 16 nesting levels, 500 memories per
mode (beyond: not written, no error). The panel's **…** menu shows and clears it.

```strate
indicator "Session high memory" { overlay: true }
persist best = 0.0
if high > best { best = high }
plot(best, #e8c15a, title: "Best high")
```

## History: `x[n]`

- `x[0]` current value; `n` whole number ≥ 0 (computed values are rounded). Negative → E911 (reads the future).
- Beyond the loaded history: `na`. No other depth limit.
- Works on top-level variables (any kind) and built-in series named directly: `close[1]`, `bar.close[2]`,
  `volume[3]`, `bar.time[1]`, `session.rth[1]`.
- Not on an expression (`(close + 1)[1]` → E912) nor on a function's local.
- On a variable holding a list/map/ring/window, `x[i]` reads an element, not history.
- **Stateful functions** (`ema`, `sma`, `highest`, `change`, `cum`, `crossover`, `stats.*`, `of.cvd`, `norm.*`…) keep a
  separate state per call place (and per call place of the enclosing function).

```strate
mid = (high + low) / 2
k = 2
print(close[1], bar.close[2], mid[k], close[100000])
```

## The bar still forming: `bar.confirmed`

False only on the last bar while it is forming (live chart, Replay cursor; time bars until their end is reached; other
bar types until the next bar opens). True everywhere else (history, the check, long backtests). Related: `bar.last`,
`bar.index` (0 = first bar received), `bar.gap` (after a real data gap; moving averages restart).

```strate
signal_up = crossover(close, sma(close, 20)) and bar.confirmed
marker(signal_up, shape: "triangle_up", location: "below")
alert(signal_up, "Close crossed above SMA 20")
```

## Control flow

- `if c { … } else if c { … } else { … }` (`}` and `else` may be on different lines).
- `for i in a..b { … }`: both bounds included and rounded; counts down if `a > b`; a `na` bound skips the loop;
  > 10,000 steps → E906. Ranges exist only in `for` (E901 elsewhere).
- Collections: `for x in list` (ring, window: values) · `for k in map` (keys, increasing) · `for i, x in list` ·
  `for k, v in map` · `for t, x in window` (time, value). The loop works on a copy.
- `while c { … }`: > 10,000 iterations → E906. `break`, `continue` act on the innermost loop.
- `return [expr]` leaves a function (value `na` without expression) or ends a handler. **At the top level, `return`
  and `break` do not stop the bar**: the following statements still run. Use `if` to skip work.

```strate
s = 0
for i in 0..5 {
  if i % 2 == 0 { continue }
  s += i
}
n = 0
while true {
  n += 1
  if n >= 3 { break }
}
a = [10, 20, 30]
txt = ""
for i, x in a { txt += str(i) + ":" + str(x) + " " }
m = map()
m["b"] = 2
m["a"] = 1
for k, v in m { txt += k + "=" + str(v) + " " }
print(s, n, txt)   // → 9 3 0:10 1:20 2:30 a=1 b=2
```

## Functions

```
fn name(a, b = 2, c: float = 1) -> float {
  return a + b + c
}
```

- Declared at the top level (a `fn` inside a block → E100); can be called above its declaration.
- Positional or named arguments: `f(1)`, `f(b: 5, a: 1)`. Positional after named → E115. Missing parameter without
  default → E915. Extra arguments and unknown names are ignored. Defaults are evaluated at each call.
- Recursion: at most 65 nested calls (E914 beyond).
- A function returns only through `return`; without it the result is `na` (the last expression is not returned).
- `f = fn(x) { return x * k }` is a function value: it copies the locals visible where it is created; top-level
  variables are read live. A script function's name is also a value (pass it to `map`, `filter`, `count`…).

```strate
fn add(a, b = 10) { return a + b }
fn big(x) { return x >= 2 }
k = 3
mul = fn(x) { return x * k }
fn smooth(x) { return ema(x, 3) }
print(add(1), add(1, 2), add(b: 5, a: 1), mul(2), [1, 2, 3].map(mul).sum(), [1, 2, 3].count(big), smooth(close) != smooth(volume))
// → 11 3 6 6 18 2 true
```

## Custom types, enums and methods

- `type Name { field: type, field: type = default }` — name starts uppercase (E107).
- `Name { field: value }` — missing fields take their default or `na`; unknown field → E932; unknown type → E916.
- Fields read `z.field`, changed `z.field = v`, `z.field += 1` (only fields of your own types are assignable, E904).
- `enum Mode { Waiting, Active }` → `Mode.Waiting`, compared with `==`.
- `method Type.name(self, …) { … }`; `self` outside a method → E917.
- An instance written directly in an `if` condition needs parentheses: `if p.x == (P { x: 1 }).x { … }`.
- Instances are references; kept in a `state` list or map, they keep their fields across bars.

```strate
enum Mode { Waiting, Active }
type Zone { top: float, bottom: float, hits: int = 0, mode: Mode = Mode.Waiting }
method Zone.contains(self, p) { return p >= self.bottom and p <= self.top }
z = Zone { top: high, bottom: low }
z.hits += 1
print(z.contains(close), z.hits, z.mode == Mode.Waiting)   // → true 1 true
```

## Collections

All are references. Limits: 1,000,000 elements per list/map (E941); `ring(n)` n in 1…1,000,000 (E940);
`window(d)` d > 0 (E940). Whole-collection operations cost about `1 + n/8` budget operations.

**List** `[…]` / `array()`
- `a[i]` (negative counts from the end; out of range → `na`); `a[i] = v` (out of range → E938; `a[a.len()] = v`
  appends); `a[i] += v`. Fields `size`, `length`.
- Change: `push(x, …)`, `pop()`, `shift()`, `insert(i, x)`, `remove(i)`, `set(i, x)`, `clear()`,
  `sort(desc = false)`, `reverse()`.
- Read: `get(i)`, `len()`/`size()`, `contains(x)`, `index_of(x)` (−1 if absent), `first()`, `last()`,
  `slice(from, to)`, `copy()`.
- Stats: `sum()`, `avg()`/`mean()`, `max()`, `min()`, `percentile(p)`, `median()`, `stdev()` (population), `rank(x)`,
  `zscore(x)`.
- With a function: `filter(f)`, `map(f)`, `find(f)`, `find_index(f)`, `any(f)`, `all(f)`, `count(f)`, `min_by(f)`,
  `max_by(f)`, `sort_by(f, desc = false)` (in place, returns `na`). A non-function → E933.

**Map** `map()`
- Keys: numbers (also times, durations), texts, bools (other → E939), kept in increasing order, numbers before texts.
- `m[k]` (missing → `na`), `m[k] = v`, `m[k] += v` (missing counts as 0).
- `set(k, v)`, `get(k, default)`, `has(k)`, `remove(k)`, `add(k, x = 1)`, `get_or_insert(k, v)`, `keys()`,
  `values()`, `len()`, `clear()`, `first_key()`, `last_key()`. Fields `size`, `length`.
- `keys()` and `values()` return new lists: removing entries while looping over `m.keys()` is safe.
- Elements are values like any other: `m[id].set_text("x")` calls a method of an object stored in a map.

**Ring** `ring(n)` — keeps the last `n` pushed values.
- `push(x, …)`, `get(i)`, `r[i]`, `len()`, `clear()`, `contains(x)`, `sum()`, `avg()`, `max()`, `min()`, `first()`
  (oldest), `last()`, `values()`, `percentile(p)`, `median()`, `stdev()`, `rank(x)`, `zscore(x)`.
- Fields `size`, `length`, `capacity`, `full`.

**Window** `window(10s)` — keeps values pushed during the last duration, on the time of the event or bar processed.
- `push(x[, t])`, `sum()`, `avg()`, `max()`, `min()`, `len()`, `first()`, `last()`, `values()`, `clear()`,
  `percentile(p)`, `median()`, `stdev()`, `rank(x)`, `zscore(x)`. Fields `size`, `length`, `duration`.

`len(x)` works on lists, texts, maps, rings, windows. `print`/`str` show a list as `na`: print elements or `len()`.

```strate
a = [3, 1, 2]
a.sort()
a.push(7)
m = map()
m.add("n")
m.add("n", 4)
r = ring(3)
r.push(1, 2, 3, 4)
print(a[0], a[-1], a.sum(), a.median(), m["n"], m.get("x", "none"), r.first(), r.sum(), r.full)
// → 1 7 13 2.5 5 none 2 9 true
```

## Imports

```
import "path" [as alias] [{ name: value, … }]
```

- `"strate/patterns/<file>"`: a shipped definition (list in `patterns.md`).
- `"my/<name>"`: another script **of the same chart** whose header has that name (an `indicator` or `strategy`, not a
  `research` script).
- Unknown path, duplicate alias, an imported script that itself imports, an override the import does not declare → E937.
- Default alias: last path segment, lower case, non-alphanumerics → `_` (`i` prefix if it starts with a digit).
- Everything declared at the imported script's top level is reached through the alias (`tools.basis`,
  `tools.dev(x)`). Its settings appear as `alias · Title`. Its patterns keep running; `on signal(s from alias)`
  listens to them.
- `{ name: value }` replaces a top-level declaration of the imported script (typically an `input.*`, which then leaves
  the Settings tab).
- One level only. From the imported header only `level_history`, `flow_history`, `mbo_history`, `book_history` are
  used (longest wins); an imported `mbo_history` never moves a strategy's fixed start.

```strate
indicator "Tools"
len = input.int("Length", 20)
fn dev(x) { return x - sma(x, len) }
basis = sma(close, len)
```

```strate
indicator "Uses tools" { overlay: true }
import "my/Tools" as tools { len: 50 }
plot(tools.basis, title: "Basis")
plot(close + tools.dev(close), title: "Close + deviation")
```

## Units

| Unit word | Value |
|---|---|
| `tick`, `ticks` | number × `instrument.tick` (price distance; ES: `4 ticks` = 1.0) |
| `point(s)`, `contract(s)`, `event(s)`, `trade(s)`, `usd`, `level(s)` | number unchanged (readability only) |

- A unit only follows a number literal: `n ticks` → E106. Use `price(n)` (= `n * instrument.tick`) or `ticks(d)`.
- In `enter(stop:, target:)`, `study(stop:, target:, cost:)` and `costs: { slippage: }`, **a plain number is a price
  distance in points**: `stop: 1` = 4 ticks on ES.

```strate
print(4 ticks, 1 tick, 2 points, 2.5 usd, ticks(1.0), price(4), instrument.tick)   // → 1 0.25 2 2.5 4 1 0.25
```

## Budget and protections

The engine counts operations (not time), so a script behaves the same on any machine.

| Bound | Value | Error |
|---|---|---|
| Operations per bar (body) and per event (each handler and pattern separately) | 200,000; header `budget:` 1–20,000,000 | E902 |
| Loop iterations (`for` range, `while`) | 10,000 | E906 |
| Nested function calls | 65 | E914 |
| Syntax nesting | 200 levels | E117 |
| Script length | 200,000 characters | E950 |

```strate
indicator "Heavy loop" { budget: 5000000 }
s = 0
for i in 0..9000 { s += i }
print(s)   // → 40504500
```
