# Plotting, alerts, console

Contents: Where things are drawn · Series · Lines and backgrounds · Markers · Objects · Tables · Drawing in a bar's
column · `stat` · Simple drawings · Panes · Alerts · `print`

## Where things are drawn

- `overlay: true` (default) draws on the price chart; `overlay: false` gives the script its own pane below.
- A pane script can still put these on the price chart with `overlay: true` (or `pane: "price"`) on the call: `plot`,
  `histogram`, `candle`, `level`, `hline`, `bg_color`, `bar_color`, `fill`, `marker`, `label`, `bubble`, `box`,
  `line`, `alert`, `signal`. A series' place is fixed by its first call.
- **E948** when: a price script uses `overlay: false` / `pane: "panel"` on a call (it has no pane — set the header to
  `overlay: false` instead); `overlay:` not a bool, `pane:` not `"price"`/`"panel"`, or both disagree; a pane script
  uses `overlay: true` on `cell`, `hbar`, `draw.*`, `line.new`, `box.new`, `label.new`, `table.new`, `stat` or
  `candle(…, x:, w:)` (they stay in the script's own area); `fill` joins a price plot with a pane plot, or gets its own
  `overlay:`.
- Unknown named options of drawing functions are ignored silently.

## Series: `plot`, `histogram`, `candle`, `fill`

| Function | Signature | Notes |
|---|---|---|
| `plot` | `plot(value, color?, color:, title:, width:, style:)` → handle | Color may change per bar. `style`: `"solid"` (default), `"dashed"`, `"dotted"`, `"step"`, `"circles"`, `"cross"`, `"area"`, `"columns"` (unknown → solid). `na` = gap. |
| `histogram` | `histogram(value, color?, color:, title:)` → handle | Bars from 0. |
| `candle` | `candle(o, h, l, c, color?, color:)` → handle | A candle series. With `x:`/`w:` (and `wick:`) it draws in the bar's column instead and returns `na`. |
| `fill` | `fill(p1, p2, color?)`, `fill(p, 0, color)`, `fill(p, h)` with `h = hline(…)` | Color may change per bar; `na` fills nothing. Other forms → E926. |

Titles appear in the legend and in Settings, where the user can recolor, restyle or hide each plot.

```strate
indicator "EMA cloud" { overlay: true }
fast = ema(close, 9)
slow = ema(close, 21)
pf = plot(fast, #26a69a, title: "Fast", width: 2)
ps = plot(slow, #ef5350, title: "Slow", style: "dashed")
fill(pf, ps, fast > slow ? #26a69a30 : #ef535030)
```

```strate
indicator "Absorbed volume" { overlay: false }
absorbed = volume - abs(delta)
p = plot(absorbed, #2962ff, title: "Absorbed")
fill(p, 0, #2962ff20)
plot(ema(close, 20), #e8c15a, title: "EMA", overlay: true)
marker(absorbed > stats.percentile(absorbed, 100, 90), shape: "diamond", location: "below", overlay: true)
```

## Lines and backgrounds

| Function | Signature | Notes |
|---|---|---|
| `hline` | `hline(value, color:, style:, width:, text:)` → handle | Does not change the auto scale; `na` draws nothing. Dashed by default. A constant value is one line from edge to edge; a value that changes draws one segment per run of equal values, the last one reaching the right edge. |
| `level` | `level(price, color:, text:)` → handle | Horizontal line included in the auto scale. |
| `bg_color` | `bg_color(color)` | Background of the bar's column; `na` = none. |
| `bar_color` | `bar_color(color)` | The bar's candle color. |

`bg_color`, `bar_color`, plots and markers belong to the **current** bar: there is no option to recolor an earlier
bar. To mark an earlier bar once something is known later, draw into its column (`cell(…, bar: k)`, `draw.*(…, bar:
k)`, below) or place an object at its time (`label.new(bar.time[n], …)`). This is not a lookahead: it is drawn when the
information exists. On history, though, it looks as if it had been known at that bar: say so, and never use such a
mark as a signal for that bar.

```strate
indicator "Session shading" { overlay: true }
bg_color(session.rth ? na : #ffffff06)
bar_color(delta > 0 ? #26a69a : #ef5350)
level(prev.close, color: #e8c15a, text: "prev close")
```

## Markers

```
marker(condition, shape:, location:, price:, color:, size:, text:, tip:)
```

One marker per call place and per bar where `condition` is true. `shape`: `"triangle_up"`, `"triangle_down"`,
`"arrow_up"`, `"arrow_down"`, `"circle"`, `"cross"`, `"diamond"`, `"square"` (default: `triangle_down` above,
`triangle_up` below, `circle` at a price). `location`: `"above"` (default), `"below"`, `"price"` (requires `price:`).
`size`: `"small"`, `"normal"`, `"large"`. `text:` short text; `tip:` hover text. Other values → E927. With
`location: "price"`, a `na` price draws nothing (no error).

```strate
indicator "Cross markers" { overlay: true }
fast = ema(close, 9)
slow = ema(close, 21)
marker(crossover(fast, slow), shape: "arrow_up", location: "below", color: #26a69a, text: "X", tip: "cross at " + str(close, "0.00"))
marker(crossunder(fast, slow), shape: "arrow_down", location: "above", color: #ef5350)
marker(volume > 2 * sma(volume, 50), location: "price", price: close, shape: "circle", size: "small", color: #e8c15a)
```

## Objects: `line.new`, `box.new`, `label.new`

Created once, then moved, changed or deleted — the tool for zones and lines extending over time, and for anything drawn
from an event handler.

| Constructor | Signature |
|---|---|
| `line.new` | `line.new(t1, p1, t2, p2, color:, width:, style:, glow:, pulse:)` |
| `box.new` | `box.new(t1, top, t2, bottom, color:, border:, text:, text_color:, fade: "left" \| "right", glow:)` |
| `label.new` | `label.new(t, price, text, color:, bg:, text_color:, glow:, pulse:)` |

- Times must be `time` values (`bar.time`, `t.time`, `s.time`…; else E928). A `na` price creates nothing, returns `na`.
- There is no `extend:` option: to keep a line or box reaching the latest bar, move its end on every bar
  (`set_right(bar.time)`, `set_end(bar.time, p)`), as in the example below.
- While the last bar is forming, its body is recomputed from the previous bar's state at each update: objects the body
  creates on that bar (`if bar.last { label.new(…) }`) are rebuilt, not piled up. Each event is processed once, so
  objects created in handlers are not duplicated either.
- `glow:` halo 0–40 px; `pulse:` pulses for a duration up to 60 s (`true` = 3 s).
- At most 500 objects per script; beyond, the oldest are deleted. A script creating one per event (trade, order,
  signal) reaches that within minutes on a busy market: say so, offer a per-bar view (`marker`, `stat`, `histogram`),
  or reuse objects (move and `set_text` one label per price or per order, kept in a map: `tags[id].set_text(…)`).
- Fields: `time1`, `price1`, `time2`, `price2`, `text`, `deleted` (aliases `time`, `price`, `top`, `bottom`).
- Methods: `set_start(t, p)`, `set_end(t, p)`, `set_left(t)`, `set_right(t)`, `set_top(p)`, `set_bottom(p)`,
  `set_time(t)`, `set_price(p)`, `set_text(s)`, `set_color(c)`, `set_border(c)`, `set_glow(px)`, `set_fade(side)`,
  `set_bg(c)`, `pulse(d)`, `delete()`. Other → E933.

```strate
indicator "Session box" { overlay: true }
state zone = na
if session.is_new or na(zone) {
  zone = box.new(bar.time, high, bar.time, low, color: #35CE0020, border: #35CE00, fade: "left", glow: 10)
}
zone.set_right(bar.time)
zone.set_top(max(zone.price1, high))
zone.set_bottom(min(zone.price2, low))
```

## Tables

```
t = table.new(position, columns, rows, bg:, border:, frame:, text_color:, size:)
t.cell(col, row, text, text_color:, bg:, size:, align:)
```

`position`: `"top_left" "top_center" "top_right" "middle_left" "middle_center" "middle_right" "bottom_left"
"bottom_center" "bottom_right"`. 1–50 columns and rows; at most 20 live tables; calling `table.new` again at the same
code place and position replaces the table; only its last state is drawn. Cells from 0 (outside → E928). `align`:
`"left" "center" "right"`. `size`: `"tiny" "small" "normal" "large" "huge"` or 6–40 px. Other methods: `clear()`,
`clear(col, row)`, `set_position`, `set_bg`, `set_border`, `set_frame`, `set_text_color`, `set_size`, `delete`. Fields
`position`, `columns`, `rows`, `deleted`. Wrong position/size/align → E928.

```strate
indicator "Bar table" { overlay: true }
state t = table.new("top_right", 2, 2, bg: #101010, text_color: #ffffff)
if bar.last {
  t.cell(0, 0, "Delta", align: "left")
  t.cell(1, 0, str(delta, "+0"), text_color: delta > 0 ? #22c55e : #ef4444)
  t.cell(0, 1, "Volume", align: "left")
  t.cell(1, 1, str(volume, "0.0k"))
}
```

## Drawing inside a bar's column (footprint-style displays)

`x:` and `w:` are fractions of the bar's width (0 left edge, 1 right edge). `bar: k` (on `cell`, `hbar`, `draw.*`)
draws in the column of the earlier bar of index `k` (`bar.index − n`); a later index is clamped to the current bar.

| Function | Signature | Notes |
|---|---|---|
| `cell` | `cell(price, text, side:, bg:, color:, size:, ticks:, bar:, col:, cols:, x:, w:, tip:)` | One row (or `ticks:` rows). `side`: `"left"`, `"right"`, `"full"` (default; else E927). `col: k, cols: n` = k-th of n sub-columns (E936 out of range). `bar:` targets an earlier bar by index. |
| `hbar` | `hbar(price, value, max, side:, width:, color:, ticks:, bar:, col:, cols:, x:, w:, tip:)` | Length `value / max` of `width` bars (default 1); `side` default `"left"`; nothing if `max` ≤ 0 or `na`. |
| `draw.rect` | `draw.rect(low, high, x:, w:, fill:, border:, radius:, tip:)` or `draw.rect(price, ticks: n, …)` | `(low, high)`: exactly between the two prices (row middles). `(price, ticks: n)`: `n` whole rows from `price` up (from half a tick below to half a tick above the top row). |
| `draw.text` | `draw.text(price, text, x: 0.5, align: "center", color:, size: 11, bold:, ticks:, tip:)` | `align` left/center/right (else E937). |
| `draw.line` | `draw.line(p1, p2, x1: 0, x2: 1, color:, width: 1, style:)` | |
| `draw.candle` | `draw.candle(o, h, l, c, x: 0.4, w: 0.2, color:, wick:)` | |

`chart.row_ticks(min_px)` and `chart.columns(min_px)` adapt the layout to the zoom.

```strate
indicator "My footprint" { overlay: true, candles: false }
rows = chart.row_ticks(14)
fp = bar.footprint.rows(rows)
for lv in fp.levels {
  c = lv.delta > 0 ? #26a69a : #ef5350
  cell(lv.price, str(lv.sell), side: left, color: #ffffff, size: 9, ticks: rows)
  cell(lv.price, str(lv.buy), side: right, color: #ffffff, size: 9, ticks: rows, bg: alpha(c, 25))
}
draw.rect(fp.poc, ticks: rows, x: 0, w: 1, border: #e8c15a)
```

```strate
indicator "Bar columns" { overlay: true, candles: false }
draw.candle(open, high, low, close, x: 0.35, w: 0.3, color: close >= open ? #26a69a : #ef5350, wick: #c8c8c8)
draw.text(high, str(volume, "0k"), x: 0.5, align: "center", size: 9)
cell(close, str(delta, "+0"), side: right, color: #ffffff, size: 9)
hbar(low, volume, 2000, side: left, color: #2962ff60)
```

## Statistics row: `stat`

`stat("Title", value, format:, color:, bg:)` adds a row of values under the bars, one row per call place. `format:`
uses `str` codes; `na` leaves the cell empty.

```strate
indicator "Stats rows" { overlay: true }
stat("Delta", delta, format: "+0", color: delta > 0 ? #26a69a : #ef5350)
stat("Volume", volume, format: "0.0k")
```

## Simple per-bar drawings

`label(time, price, "text", color:)`, `box(t1, p1, t2, p2, color:, border:, text:)`,
`line(t1, p1, t2, p2, color:, width:, style:)`, `bubble(price, size, color)` draw once on the current bar (several per
bar allowed) and cannot be changed afterwards. Prefer `label.new`, `box.new`, `line.new`.

## Panes and scales

The header's display keys (`height`, `background`, `min`, `max`, `format`, `precision`, `labels`, `candles`,
`visible_on`) control a pane — see `language.md`. `format: "percent"` adds `%` without multiplying: plot `x * 100` for a
0–1 ratio. `candles: false` hides the chart's candles while the script draws its own.

## Alerts

```
alert(condition, "Message", every: duration)
```

- At most one alert per call place and per bar (a live bar recalculated many times still counts once).
- `every:` minimum delay between two alerts of the same call, in bar time.
- Drawn as a small orange mark at the top of its bar; a pane script can draw it on prices with `overlay: true`.
- The app signals only **new** alerts on recent bars, never historical ones nor right after a context change
  (instrument, unit, session, code). A hidden script signals nothing. Options in the panel's **…** menu: **Alert
  sound**, **Alert notifications**, **Alerts in Replay too**, **Alert log…**. Alerts also appear in the Console.
- Use `bar.confirmed` to alert only on closed bars.
- `alert` belongs to the bar: to alert on an event, record it in `state` in the handler, alert from the body, reset.

```strate
indicator "Cross alert" { overlay: true }
len = input.int("Length", 20, min: 1)
avg = sma(close, len)
plot(avg, #e8c15a, title: "SMA")
cross = crossover(close, avg)
alert(cross and bar.confirmed, "Close crossed above the SMA", every: 30m)
marker(cross and bar.confirmed, shape: "triangle_up", location: "below")
```

```strate
indicator "Large print alert" { overlay: true }
minSize = input.int("Min size", 100, min: 1)
state biggest = 0
on trade(t) {
  if t.size > biggest { biggest = t.size }
}
alert(biggest >= minSize, "Print of " + str(biggest) + " contracts")
biggest = 0
```

## Console: `print`

`print(a, b, …)` writes one line (values joined by spaces) in the **Console** drawer (mode **Code**), for the last 500
bars only, 500 characters per line. It never changes what is drawn. Lists print as `na`.
