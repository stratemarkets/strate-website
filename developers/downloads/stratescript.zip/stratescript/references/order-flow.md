# Order flow: trades, MBO, book, `of`

Contents: Where the data exists · What triggers loading · `on trade` · `on order` · `on match` · `mbo` · `mbo.level` ·
Book snapshots · `of.*` · Event order and causality · How much history · Worked examples

## Where the data exists

| Data | Replay of a recorded session | Live | Long backtest (local MBO replay files) |
|---|---|---|---|
| Bars (OHLCV, delta) | yes | yes | built from trades (time bars only) |
| Footprint | yes, where Strate has the trades (`bar.footprint.available`) | same | `na` |
| Trades (`on trade`) | yes | yes | yes |
| Sweep fields (`t.sweep`…) | inside the MBO window | inside Strate's MBO recording | yes |
| Book snapshots (`on book`, `book.*`) | every 250 ms | every 250 ms | `na` |
| Order by order (`on order`, `on match`, `mbo.*`, `of.ofi`) | exactly as in the files | from Strate's MBO recording | yes |
| `session.*`, `prev.*` | yes | yes | yes (previous days of the same contract) |
| `request(…, symbol:)` | if that symbol's minutes exist | yes | `na` |

- **Live MBO**: when a script reads MBO, Strate starts recording that instrument's order-by-order feed (up to 8
  instruments), starting from a full book snapshot. Nothing exists before the recording started.
- **Replay**: the book is rebuilt from the first replay file; nothing after the Replay cursor is ever visible.
- **Without MBO**: `mbo.available` false, every `mbo.*` `na`, `on order`/`on match` never run, sweep fields `na`,
  `of.ofi` `na`. **No error.** Without book data: `book.available` false, `on book` never runs.
- Live bars close once data at or after their end arrives, or 30 s after their end.

```strate
indicator "Data check" { overlay: false }
print("mbo", mbo.available, "book", book.available, "footprint", bar.footprint.available)
plot(mbo.available ? 1 : 0, title: "MBO")
```

## What triggers loading (scripts on a chart)

Strate decides from the script's **text** (line comments `//` ignored; a `/* … */` comment is NOT ignored):

| Data | Loaded when the text contains |
|---|---|
| Trades | `on trade`, a `strategy` header, `on: trade` or `on: level`, `clock.time(`, `clock.volume(`, `clock.trades(`, `clock.range(`, `clock.events(`, `of.flow(`, `of.trade_count(`, `of.aggression(`, `of.decay(`, `of.burst(`, `of.vpin(` |
| Book snapshots | `on book`, `on: book`, or the word `book` |
| Footprint | the word `footprint` |
| Order by order | `on order`, `on match`, `on: order`, `on: match`, `mbo.`, `fill_model: queue`, `.sweep`, `.sweep_start`, `.sweep_end`, `.aggressor_id`, `.passive_id`, `.passive_count`, `of.ofi(`, or `on trade` together with `.levels` |

A pattern `on: trade` is not `on trade`: one that reads only `trade.levels` does not request MBO, and `trade.levels`
stays `na`. Reading any sweep field (`trade.sweep_end`…) or `mbo.` requests it.

Consequences: call these under their own names (`x = mbo` then `x.level(…)` gives `na`, data never requested); a
research script driven by bars needs `on trade(t) { }`. A long backtest rebuilds the MBO book only for scripts (or
their imports) containing `on order`, `on match`, `mbo.` or `of.ofi(`.

## Trades one by one: `on trade(t)`

Runs for every trade in exchange order, all before the bar's body; own budget per call.

| Field | Meaning |
|---|---|
| `t.time`, `t.price`, `t.size` | |
| `t.side` | `"buy"` (buyer aggressed), `"sell"`, or `na` |
| `t.delta` | `+size` buy, `−size` sell |
| `t.is_buy`, `t.is_sell` | bools; both false when the side is unknown (`t.side` `na`, `t.delta` 0) |

**What one trade is.** With MBO, one execution of one aggressive order at one price. Without MBO, one trade report of
the market-data feed (price, size, aggressor side); how a feed groups executions into reports varies, so a size
threshold on `t.size` is a threshold on reports. For the size of the whole aggressive order, read `t.sweep` at
`t.sweep_end` (MBO). Tell the user which one the script counts.

With MBO data (else `na` — test `na(t.levels)`), each trade = one execution of one aggressive order at one price:

| Field | Meaning |
|---|---|
| `t.sweep` | Total size of that aggressive order across all prices |
| `t.levels` | Distinct prices it traded |
| `t.sweep_start`, `t.sweep_end` | First / last execution of the order (test `t.sweep_end` to act once per order) |
| `t.aggressor_id` | Aggressive order id (`na` if the feed gives none) |
| `t.passive_id`, `t.passive_count` | First resting order hit at this price; number hit at this price |

Executions are grouped into one aggressive order when they share timestamp, side and aggressor id (or an unknown id).
Trades before the start of the MBO window have `na` sweep fields.

```strate
indicator "Large-print volume" { overlay: false }
minSize = input.int("Min size", 20, min: 1)
state big = 0
on trade(t) {
  if t.size >= minSize { big += t.delta }
}
histogram(big, big >= 0 ? #26a69a : #ef5350, title: "Signed large prints")
big = 0
```

## Order events: `on order(o)`

Every MBO event that changes a resting order (add, cancel, modify, fill), in exchange order. When it runs, `mbo`
already includes the event (`mbo.size(o.price)` is the size after it); the `queue_position`, `previous_*` fields
describe the order before it.

| Field | Value |
|---|---|
| `o.time`, `o.id` | |
| `o.action` | `"add"`, `"cancel"`, `"modify"`, `"fill"` |
| `o.is_add`, `o.is_cancel`, `o.is_modify`, `o.is_fill` | bools |
| `o.side` | Resting side `"bid"`/`"ask"` (a fill against a buying aggressor is `"ask"`) |
| `o.price` | Event price (modify: new price) |
| `o.size` | Add: size · cancel: size removed · modify: new size · fill: size filled |
| `o.queue_position` | Rank in its queue **before** the event, 0 = front; `na` on add |
| `o.priority_lost` | Modify that increased size or moved price (goes to the back) |
| `o.previous_size`, `o.previous_price` | Before the event; `na` on add |
| `o.age` | Since the original add (modify does not reset); `na` on add |
| `o.modifications` | Modifies before this event (0 on add) |

Queue rules: size decrease and partial cancel keep the place; size increase or price change go to the back. A modify of
an unknown order is treated as an add; cancels/fills of unknown orders leave the book unchanged (handler still runs,
with `na` position/previous/age).

- **An order that leaves the book** — full cancel, or a fill of its whole remaining size — is gone when the handler
  runs: `na(mbo.order(o.id))` is true. A partial fill leaves it with `o.previous_size − o.size`.
- **An add with an id already resting** replaces that order (new size, new place at the back, age restarts at 0).
- **Reloading orders (icebergs).** How a hidden order shows its next slice depends on the exchange feed: the **same id**
  added again or modified up (`o.is_add`, or `o.is_modify` with `o.priority_lost` and `o.size > o.previous_size`),
  or a **new id** at the same price. Write custom code that accepts the forms the user means, and say which ones it
  counts. In `mbo.level`, a refill is the displayed size rising back above `depleted_below` within `refill_within`
  of a depletion. Each refill is counted in exactly one of `refill_same_id` (an add, size increase or move into the
  price by an id already seen at that price in the window, at or before the depletion) or `refill_new_id` (any
  other); both depend on `depleted_below` and `refill_within`. `replenishments` = their sum, or `refill_same_id`
  alone with `same_id_only: true` (which changes nothing else). Traded volume beyond what was displayed is
  `lv.hidden_filled`.
- Keep maps keyed by order id small: remove the id when `na(mbo.order(o.id))` (`examples.md` #10).
- **Orders resting when the MBO data starts** (start of the recording, of the Replay, or of the script's MBO window)
  are in the starting book (`mbo.order(id)`, `mbo.level`, queues) but never had an `on order` add: code first meets
  them at their next cancel, modify or fill (`o.previous_size` gives their size then). Code that tracks orders from
  their add (large orders, spoofing) misses them unless it also handles the first event of an id it has not seen.
- **"Near the market" has several meanings**: distance to the opposite best (where the order would trade:
  `mbo.best_ask − o.price` for a bid), to its own side's best (how deep it sits), or to the last trade. "Price
  approached" = that distance shrank since the add. Choose one, say which, or offer it as a setting.

```strate
indicator "Pulled at the front" { overlay: false }
state pulled = 0
on order(o) {
  // a resting order canceled while it was first in its queue
  if o.is_cancel and o.queue_position == 0 { pulled += o.size }
}
histogram(pulled, #ef5350, title: "Size pulled at the front")
pulled = 0
```

## Executions: `on match(m)`

One call per aggressive execution (aggressor + every resting order hit at the same timestamp; a multi-price sweep is
one match). Runs after its last fill and before that execution's `on trade` calls.

| Field | Value |
|---|---|
| `m.time` | |
| `m.side` | Aggressor `"buy"`/`"sell"` |
| `m.size` | Total aggressor size |
| `m.first_price`, `m.price` | First and last price traded |
| `m.levels` | Price span in ticks + 1 (counts skipped prices; distinct prices: `t.levels`) |
| `m.fills`, `m.largest_fill` | Resting fills; largest single fill (`na` if none) |
| `m.orders` | List of resting order ids hit, in order |
| `m.aggressor_id` | `na` when the feed gives none |

```strate
indicator "Orders hit per execution" { overlay: false }
state most = 0
on match(m) {
  if m.orders.len() > most { most = m.orders.len() }
}
histogram(most, #2962ff, title: "Most resting orders hit by one execution")
most = 0
```

## The order-by-order book: `mbo`

Readable anywhere (body, handlers, patterns); state after the latest MBO event processed. Prices are rounded to the
tick; everything is `na` while `mbo.available` is false. Ages are measured at `mbo.time`.

| Member | Returns |
|---|---|
| `mbo.available` | False until the first MBO event |
| `mbo.orders` | Number of resting orders |
| `mbo.time` | Time of the latest MBO event |
| `mbo.best_bid`, `mbo.best_ask` | `na` if a side is empty |
| `mbo.size(price)`, `mbo.count(price)` | Resting size / number of orders at a price |
| `mbo.queue(price)` | List of sizes, front first |
| `mbo.orders(price)` | List of resting orders, front first |
| `mbo.mean_age(price)` | Size-weighted mean age (duration), `na` if none |
| `mbo.order(id)` | Resting order or `na` if gone |
| `mbo.levels(side, n = 10)` | Prices of the `n` best levels, best first; side `bid`/`ask` (`buy`/`sell` accepted, else E933); n clamped 1–500 |
| `mbo.large(min_size)` | Resting orders ≥ `min_size`, biggest first (ties: lower id), at most 500; negative/`na` → E933 |
| `mbo.level(price, …)` | Level statistics (next section) |

Resting order fields: `.id`, `.side`, `.price`, `.size`, `.age`, `.position` (0 = front), `.modifications`.

```strate
indicator "Queue at the best bid" { overlay: false }
bb = mbo.best_bid
q = mbo.queue(bb)
plot(na(bb) ? na : q.len(), #2962ff, title: "Orders at best bid")
plot(na(bb) or q.len() == 0 ? na : q.first(), #e8c15a, title: "Size at the front")
plot(na(bb) ? na : mbo.mean_age(bb) / 1s, #ffffff80, title: "Mean age (s)")
```

```strate
indicator "Large resting orders" { overlay: true }
minSize = input.int("Min size", 50, min: 1)
if bar.last {
  for o in mbo.large(minSize) {
    label.new(bar.time, o.price, o.side + " " + str(o.size) + " #" + str(o.position) + " " + str(o.age), color: o.side == "bid" ? #26a69a : #ef5350)
  }
}
plot(close, title: "Close")
```

## Level statistics: `mbo.level`

```
lv = mbo.level(price, window: 30s, depleted_below: 0, refill_within: 2s, same_id_only: false)
```

Everything that happened at one price over a sliding window ending at `mbo.time`. `window` a duration > 0 (else
E933) and ≤ the header `level_history:` (default `2m`, max `30m`; longer → E933 whose message gives the header line).
`na` before any MBO event or without MBO.

| Field | Meaning |
|---|---|
| `price`, `window` | |
| `displayed`, `queue_length`, `mean_order_age` | Now: resting size, order count, size-weighted mean age |
| `added` | Size added: adds, size increases, orders moved here |
| `canceled` | Size removed without trading: cancels, decreases, orders moved away |
| `filled` | Displayed size filled |
| `net` | `added − canceled − filled` |
| `cancel_ratio` | `canceled / added` (`na` if nothing added) |
| `aggressor_hits`, `aggressor_volume` | Number and volume of aggressor trades at the price |
| `hidden_filled` | Aggressor volume − displayed filled, ≥ 0 (traded beyond what was shown) |
| `depletions` | Times displayed size fell to `depleted_below` or less |
| `replenishments` | Refills above the threshold within `refill_within` of a depletion (same-id only if `same_id_only`) |
| `refill_same_id`, `refill_new_id` | Refills by an order already seen at that price / by others |
| `refill_delay` | Median refill delay (duration), `na` if none |
| `time_at_best` | Duration the price was best bid or ask during the window |

Totals are cheap; `depletions`, `replenishments`, `refill_*`, `time_at_best` scan the window once per call. A long
`level_history:` keeps every event of every price: keep it as short as the windows allow.

```strate
indicator "Hidden volume at the best ask" { overlay: false, level_history: 5m }
win = input.duration("Window", 2m)
lv = mbo.level(mbo.best_ask, window: win)
plot(na(lv) ? na : lv.hidden_filled, #e040fb, title: "Hidden filled")
plot(na(lv) ? na : lv.aggressor_volume, #2962ff, title: "Aggressor volume")
```

## Book snapshots: `book` and `on book(b)`

Aggregated size per price, every 250 ms, within 300 ticks of the center, dated at the end of their step (never early).
`book` = the latest snapshot processed: in the **body** (which runs after all the bar's events) the last snapshot of the
bar; in a handler, the last one up to that event (before the bar's first snapshot: the last one before the bar).
`on book(b)` runs per snapshot, `b` has the same members.

| Member | Value |
|---|---|
| `available`, `time` | |
| `best_bid`, `best_ask`, `mid`, `spread`, `bid_size`, `ask_size` | |
| `microprice` | `(bid × ask_size + ask × bid_size) / (bid_size + ask_size)`; mid if both 0 |
| `size(price)` | `na` beyond 300 ticks |
| `depth(side, levels = 10)` | Total size of `levels` levels from the best (side `bid`/`ask`/`buy`/`sell`, else E933); clamped 1–300 |
| `imbalance(levels = 10)` | `(bids − asks)/(bids + asks)`, −1…+1; **a method**: `book.imbalance` without `()` → E932 |

History: indicators replay the last `book_history:` (default `2h`); strategies/research start at a fixed point.

```strate
indicator "Book imbalance" { overlay: false, min: -1, max: 1 }
levels = input.int("Levels", 5, min: 1, max: 300)
plot(book.imbalance(levels), #2962ff, title: "Imbalance")
plot(na(book.microprice) ? na : (book.microprice - book.mid) / instrument.tick, #e8c15a, title: "Microprice - mid (ticks)")
hline(0)
```

## The `of` module (aggressor flow over a time window)

| Function | Returns |
|---|---|
| `of.cvd(reset: "session")` | Cumulative **bar** delta: adds `delta` once per bar (a bar with `na` delta adds nothing), restarts (from that bar's delta) on the first bar received and on the first bar of each period: `"session"` = bar opening in a new CME session (18:00), `"day"` = new New York date (midnight), `"rth"` = first bar opening in 9:30–16:00 after one that did not; `"none"` (`"never"`) never. It keeps accumulating outside RTH (it is not `na` there). Positional allowed; other → E933 |
| `of.flow(side = "both", window = 30s)` | Aggressor volume per second (0 without trades) |
| `of.trade_count(side = "both", window = 30s)` | Number of trades (0 without trades) |
| `of.aggression(window = 30s)` | `(buy − sell) / total`, −1…+1; `na` without trades |
| `of.decay(side = "both", window = 30s)` | Volume of last third ÷ first third of the window; `na` if first third empty (< 1 = flow dying) |
| `of.burst(side = "both", window: 1s, min_trades: 10)` | Bool: ≥ `min_trades` trades in the window |
| `of.vpin(bucket, buckets: 50)` | 0…1: mean `abs(buy − sell)/bucket` over the last full buckets of `bucket` contracts; `bucket` > 0 (E933); buckets clamped 1–1000; `na` until filled |
| `of.ofi(window = 30s)` | Order flow imbalance at best bid/ask summed over the window; needs MBO, else `na` |

- `side`: `"buy"`, `"sell"`, `"both"` (else E933); `window`: a duration (else E933). Positional or named.
- The window ends at the latest event processed (handler: the event; body: the bar's last event, not its close).
- History kept for `flow_history:` (default `5m`, max `60m`); longer window → E933 with the header line to add.

```strate
indicator "Flow" { overlay: false }
win = input.duration("Window", 30s)
plot(of.flow("buy", win), #26a69a, title: "Buy volume / s")
plot(-of.flow("sell", win), #ef5350, title: "Sell volume / s")
plot(nz(of.ofi(win)), #e8c15a, title: "OFI")
hline(0)
```

```strate
indicator "CVD" { overlay: false }
plot(of.cvd(reset: "rth"), #2962ff, title: "CVD since the RTH open")
plot(cum(delta), #ffffff60, title: "CVD since the first bar")
```

## Event order and causality

- By time. At the same timestamp: MBO events first, then trades, then the book snapshot.
- One execution gives `on order` per fill, then `on match` once, always before its first `on trade`. Several executions
  at one timestamp: all their MBO events first (orders and matches may alternate), then all their trades.
- All events of a bar run before its body. Clocks fire after the handlers and patterns of the event that closed them.
- In handlers: `open…delta` = bar so far; `bar.delta_high/low` `na`; `bar.footprint` → E911.
- Nothing looks back in the event stream: the visible past is bounded by `level_history:`, `flow_history:` and what the
  script stores itself.

## How much history

**Indicators**: rolling windows — MBO: the last `mbo_history:` (default `30m`, start at the latest :00/:30 before
`now − mbo_history`, never before the first bar); book: the last `book_history:` (default `2h`). There is no fixed
maximum: a longer value replays more (more time and memory), bounded by what exists (live: since Strate started
recording; Replay: since the first replay file). **Tell the user**: with the default, an MBO indicator shows nothing
older than about 30 minutes.

**Strategies and research** start at a fixed point so results do not drift with time, set by `mbo_from:` (`book_from:`
falls back to it):

| Value | Start |
|---|---|
| `auto` (default) | 9:30 New York if launched during RTH, else 18:00 |
| `launch` | Minute of launch |
| `rth` / `session` | Latest 9:30 / 18:00 at or before launch |
| `"HH:MM"` | Latest HH:MM (New York) at or before launch |
| `start` | First bar of the chart |
| `rolling` | Rolling window, like an indicator |

So with the default, a strategy or research Report on a chart covers at most the time since the latest 9:30 or 18:00
before launch. `mbo_from: start` reaches the chart's first bar (more memory and time); many days need a long backtest
(`strategies.md`). An indicator may set `mbo_from:` for a fixed start. In strategy/research, `mbo_history: 2h` without `mbo_from:` = two
hours before launch, rounded down to the half hour. **Launch** = first run on that chart (instrument, tick, unit,
Replay session); editing code or settings, scrolling or zooming recalculate from the same start; moving Replay before
the launch or re-adding the script relaunches.

Memory: with a fixed start data is streamed (roughly constant memory). `mbo_max:` bounds MBO events held for the open
bar (default 25,000,000, ~32 bytes each; exceeded → E944: shorter timeframe or raise it). An open bar holds at most 8 h
of book snapshots.

```strate
strategy "Fixed start" { overlay: true, mbo_from: "08:00", costs: { commission: 2.5 usd, slippage: 1 tick } }
plot(mbo.orders, title: "Resting orders")
```

## Worked examples (raw primitives; each is one possible definition)

### Absorption: heavy hitting at a price that holds

```strate
indicator "Absorption (raw)" { overlay: true, level_history: 2m }
win = input.duration("Window", 30s, tooltip: "Up to 2m (level_history)")
minRank = input.float("Min volume rank", 95, min: 0, max: 100)
normWin = input.duration("Normalize over", 30m)
minCount = input.int("Values before ranking", 50, min: 1)
heldPct = input.float("Held at best (% of window)", 60, min: 0, max: 100)

on match(m) {
  w = win > 2m ? 2m : win          // the window cannot exceed level_history
  lv = mbo.level(m.price, window: w)
  // ranked at every execution, before any filter, so the population holds all of them
  rk = norm.rank(na(lv) ? na : lv.aggressor_volume, normWin, min_count: minCount)
  if not na(lv) and rk >= minRank and lv.time_at_best >= w * heldPct / 100 and lv.displayed > 0 {
    // buyers hitting the ask that holds: sellers absorbed them
    label.new(m.time, m.price, (m.side == "buy" ? "ask absorbs " : "bid absorbs ") + str(lv.aggressor_volume), color: m.side == "buy" ? #ef5350 : #26a69a)
  }
}
plot(close, title: "Close")
```

### Iceberg-like refills: more traded than displayed

```strate
indicator "Refills (raw)" { overlay: true, level_history: 2m }
win = input.duration("Window", 60s, tooltip: "Up to 2m (level_history)")
within = input.duration("Refill within", 2s)
minHidden = input.int("Min hidden volume", 20, min: 1)
minRefills = input.int("Min refills", 2, min: 1)

on trade(t) {
  if not na(t.levels) and t.sweep_end {
    lv = mbo.level(t.price, window: win > 2m ? 2m : win, refill_within: within)
    if not na(lv) and lv.hidden_filled >= minHidden and lv.replenishments >= minRefills {
      label.new(t.time, t.price, "refill " + str(lv.hidden_filled) + " / " + str(lv.refill_same_id) + " same id", color: #e040fb)
    }
  }
}
plot(close, title: "Close")
```

### Pulled liquidity: large orders canceled in full after a short life

A script that creates an object per event keeps only the latest 500 (`label.new`…); on a busy market they cover a short
time. The `stat` rows below keep a per-bar total for the whole chart.

```strate
indicator "Pulled size (raw)" { overlay: true }
minSize = input.int("Min size", 50, min: 1)
maxAge = input.duration("Max age", 5s)
maxTicks = input.int("Max distance from best (ticks)", 4, min: 0)

state pulledBid = 0
state pulledAsk = 0
on order(o) {
  if o.is_cancel and na(mbo.order(o.id)) and o.previous_size >= minSize and o.age <= maxAge {
    best = o.side == "bid" ? mbo.best_bid : mbo.best_ask
    if not na(best) and abs(o.price - best) <= maxTicks * instrument.tick {
      if o.side == "bid" { pulledBid += o.previous_size } else { pulledAsk += o.previous_size }
      label.new(o.time, o.price, "pulled " + str(o.previous_size) + " after " + str(o.age), color: #ffb300)
    }
  }
}
stat("Bid pulled", pulledBid, format: "0")
stat("Ask pulled", pulledAsk, format: "0")
pulledBid = 0
pulledAsk = 0
```

### Queue at the best bid, order by order

```strate
indicator "Best bid queue" { overlay: true }
if bar.last and mbo.available {
  i = 0
  for o in mbo.orders(mbo.best_bid) {
    if i < 5 { label.new(bar.time, o.price, "#" + str(o.position) + " id " + str(o.id) + " size " + str(o.size) + " age " + str(o.age)) }
    i += 1
  }
}
plot(close, title: "Close")
```
