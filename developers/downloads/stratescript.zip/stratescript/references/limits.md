# Limits, performance, unsupported features, pitfalls

## Bounds

| Bound | Value | Beyond |
|---|---|---|
| Script length | 200,000 characters | E950 |
| Syntax nesting | 200 levels | E117 |
| Operations per bar (body) and per event (each handler, pattern) | 200,000; `budget:` 1–20,000,000 | E902 |
| Loop iterations (`for` range, `while`) | 10,000 | E906 |
| Nested function calls | 65 | E914 |
| List / map size | 1,000,000 | E941 |
| `ring(n)` | 1–1,000,000 | E940 |
| `norm.*` populations (`by:` keys, all calls together) | 200,000 | E933 |
| `norm.*` window in values | 1,000,000 | clamped |
| Objects (`line.new`, `box.new`, `label.new`) | 500 per script | oldest deleted |
| Tables | 20 live; 1–50 columns and rows | E928 on size |
| `print` | last 500 bars, 500 characters per line | ignored |
| `mbo.levels(side, n)` | 1–500 | clamped |
| `mbo.large(min)` | 500 results | truncated |
| `book.depth`, `book.imbalance` | 300 levels | clamped |
| `of.vpin(…, buckets:)` | 1–1,000 | clamped |
| `level_history:` | default 2 min, max 30 min | E942; longer `mbo.level` window E933 |
| `flow_history:` | default 5 min, max 60 min | E942; longer `of.*` window E933 |
| `mbo_history:` / `book_history:` (indicators) | default 30 min / 2 h; no fixed maximum (bounded by the data that exists, time and memory) | — |
| `mbo_max:` | default 25,000,000 (1,000–100,000,000) MBO events per open bar | E942 / E944 |
| Book snapshots per open bar | 8 hours | E944 |
| `initial_balance:` | 1–390 whole minutes | E942 |
| Bars, indicator | chart's last 2,000 | — |
| Bars, strategy/research on a chart | launch: last 4,000–8,000 (all if fewer), grows to 48,000, then start moves by 8,000; with footprint: last 2,000 | — |
| Bars per script | 50,000 | E945 |
| `persist` | 256 KB, 50,000 values, 16 nesting levels; 500 memories per mode | not written |
| Live MBO recording | 8 instruments | — |
| `request(…, symbol:)` | 8 symbols | — |

Strategies and research: one position at a time; equity curve 300 points; Report trade list 200; CSV 200,000 trades;
bootstrap `ci:` 0–20,000 (default 1,000; 400 in sweeps); sweep 40 values; long backtest 600 days, 20,000 bars/day,
15,000,000 MBO events per day's window, one at a time, default limit 120 min.

## Performance

- Budget counts operations, not time: identical on any machine. If E902 appears, look first for loops over large
  collections run on every event.
- Collection operations (sum, sort, keys, percentile…) cost about `1 + n/8`; `mbo.large(min)` about one per 64 resting
  orders; `mbo.level` totals are cheap, `depletions`/`replenishments`/`refill_*`/`time_at_best` scan the window once
  per call.
- `level_history:` keeps every event of every price: on busy markets keep it as short as the windows allow.
- Maps keyed by order id grow all day: forget ids once the order left the book (see `examples.md` #10, #11).
- Strategy/research scripts with a fixed MBO start stream the data: memory stays roughly constant.

## Not supported

- Real orders (strategies are always simulated).
- Several positions, pyramiding, direct reversal, trailing stops (`trail:` does not exist).
- Dates as values (`2025-01-02`); ranges outside `for`.
- `set<…>`, `heap<…>`, `deque<…>`, `series<…>`; `window<T>(…)` (write `window(d)`).
- Imports of more than one level; imports other than `strate/patterns/<file>` and `my/<name>`.
- Unicode escapes in strings (`\u{41}` stays as written).
- `persist` in strategies and research.
- Book snapshots, footprints, `request(…, symbol:)` and drawings in long backtests.
- `request(…, symbol:)` in the built-in check (E936 there).
- Reading the future: negative history, the footprint inside a handler, data after the Replay cursor.
- Undocumented header keys and named arguments are ignored, not rejected.

## Pitfalls (checked in reviews)

- A comparison with `na` is always false, even `!=`: use `na(x)` / `nz(x)`.
- The first assignment inside a block creates a local: declare shared variables at the top level.
- `return`/`break` at the top level do not stop the rest of the body.
- `const` is evaluated on the first bar only (`const k = close` freezes the first close).
- `signal(...)` always draws a mark, even with a false argument: put it in an `if`.
- `print`/`str` show a list as `na`.
- Unknown header keys and named arguments are silently ignored: check the spelling.
- `sign(0)` is 1.
- `window(10s)`, never `window<float>(10s)`.
- A plain number in `stop:`/`target:`/`cost:`/`slippage:` is points.
- `book.imbalance` is a method: `book.imbalance()`.
- Body series are `na` inside handlers: share values through `state`.
- Event accumulators must be reset at the end of the body, after they are used.
- `norm.*` behind `and`/`if` sees a filtered population.
- `overlay: true` with a non-price measure draws it off-screen: use `overlay: false`.
- MBO-dependent code silently returns `na` without MBO data: test `mbo.available` and tell the user what data it needs.
- `crossover(close, lvl)` against a level that jumps (a new day's `prev.high`, a reset `var`) fires on the jump itself:
  require `lvl == lvl[1]` (the level unchanged since the previous bar).
- `session.*`, `bar.hour` in handlers and patterns are the bar's (its open), not the event's: `session.in(r, event.time)`.
- `prev.*` and `request("1d", …)` are `na` without a previous day in the data (and on the check's synthetic market);
  `request("1d", …)` is built from the chart's own bars, so its first day may be partial.
- `fp.imbalances` / `fp.stacked` count an empty diagonal row as 0: set `min_volume:`.
- `draw.rect(low, high)` stops at the row middles; use `draw.rect(low, ticks: n)` for whole rows.
- `input.duration` is not clamped: clamp windows that must stay within a history key.
- Objects (`label.new`…) are limited to 500: event-driven labels disappear quickly on a busy market.
- `events: 0` in the check means no marker, print, alert, signal or simulated order fired there; objects are not
  counted. Force the branch to test it.
- A function without `return` returns `na`.
- `input.*` clamps the default to `min:`/`max:` as well.
- A pattern `on: trade` that reads only `trade.levels` does not request MBO: write a sweep field or `mbo.` too.
- Orders resting before the MBO data starts have no `on order` add: tracking from the add misses them.
- A cancel is not necessarily a whole cancel: test `na(mbo.order(o.id))` for "the order left the book".
- A target "at 1R" reads below 1R in the Report (commission is subtracted).
- A default the user did not choose (a horizon, a size, a target) must be stated, not hidden.
