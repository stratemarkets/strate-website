# Options data in StrateScript

Read options chains and option trades from your scripts, turn them into levels and flows on your futures chart, alert on them, and use them as context in simulated strategies. The same script runs live, in Replay and in long backtests.

- **SPX · NDX · SPY · QQQ**
- Live · Replay · long backtest
- Strategies simulated on ES, MES, NQ, MNQ

## What options data lets you build

StrateScript reads two kinds of options data, for the indexes **SPX** and **NDX** and the ETFs **SPY** and **QQQ**:

- **Chain snapshots**, with `options.chain()`: the whole chain of one underlying at one moment. For each option: strike, expiry, call or put, settlement, open interest, gamma and implied volatility. On top of that, Strate computes gamma exposure, dealer vanna and charm, the zero-gamma level, and the conversion of every strike into a price on your futures chart.
- **Option trades**, with `on option_trade`, `on option_block` and `on option_feed`: every print one by one, with its side, greeks and amounts, plus the orders, bursts and multi-leg structures (verticals, straddles, condors, calendars…) that Strate builds from them.

Use options data alone, or together with bars, trades and order-by-order (MBO) data in the same script.

| What you can build | Main tools | See |
|---|---|---|
| Levels on the futures chart: call and put walls, zero gamma, gamma exposure by strike | `options.chain()`, `s.strikes()`, `s.zero_gamma()`, `s.gex_at()` | Zero gamma and walls |
| Greeks, implied volatility, skew, dealer vanna and charm | `s.options()`, `o.iv`, `o.delta`, `o.vanna`, `o.charm` | 25 Delta Skew |
| React to each new snapshot | `on options(s)` | on options |
| Black-Scholes prices, greeks and implied volatility | `bs.price`, `bs.delta`… `bs.iv` | Black-Scholes |
| Prints one by one, with side, greeks and amounts | `on option_trade(t)` | Put/Call Ratio, Volume by Strike |
| Orders, bursts and spreads, counted once | `on option_block(b)` | Net Premium Flow, Big Trades |
| Flows: net premium, customer delta, dealer gamma (under a stated convention) | `notional`, `delta_dollars`, `gamma_dollars`, `future_equivalent` | Dealer Gamma Flow, Customer Delta Flow |
| Data health: gaps and coverage of the recording | `on option_feed(e)`, `option_trades.status()`, `option_trades.coverage()` | Status and coverage |
| Alerts | `alert(…)` on values read from the chain | Near an options wall |
| Simulated strategies on futures, with options as context | a `strategy` script that reads `options.chain()` | Absorption with zero gamma |

> **Options are read, never traded.** Strategies trade only the futures (ES, MES, NQ, MNQ), and only in simulation. Your options data connection is read only: Strate never sends an order through it.

**Chart families.** On ES and MES the chart's options family is SPX (and its ETF, SPY). On NQ and MNQ it is NDX (and QQQ). `options.chain()` with no argument reads the family's index, so the same script works on ES and on NQ. Strikes of the chart's family are converted into prices on your futures chart (another family needs `basis:` or `ratio:`).

## Where the data comes from

### Your own options data connection

Each user connects **their own** options data account, in Strate's connections. It gives real-time chain snapshots: Strate assembles one every 10 seconds by default (10, 20, 30 or 60 seconds, one setting for charts and scripts). Option trades arrive print by print.

The Connections window shows the options data account Strate supports, and the app's options displays tell you when it is missing or needs checking.

### A delayed public source

When your connection gives nothing usable (no connection, a connection that is down, still loading or stale), a public source delayed by 15 minutes takes over for the chain. It is the snapshot the app already shows on its charts; scripts receive it only while the app shows it. A script can tell which source it reads (`s.source` is `"live"` or `"delayed"`) and can refuse delayed data with `source: "live"`.

### Recordings on your computer

While Strate follows an underlying (a chart shows its options levels, or a script reads it) and your connection is connected, the snapshots and the option trades are **recorded on your computer**. Replay and long backtests read these recordings.

- To record an underlying every trading day, even when no chart shows its options, tick **Record the chain even when the indicator is hidden** in the Recordings window, Options tab (SPX is ticked by default; NDX, SPY and QQQ can be added). Strate then records it from 9:15 a.m. to the options close, New York time, while it is running and connected.
- Recordings are kept for the number of sessions set in the **Option GEX Heatmap** settings (**Sessions kept per underlying**, 20 by default); older days answer `not_kept`. Chain recordings are read only while your options data connection is set up and connected, and changing the connection's keys erases them.
- Recording started with the versions of **October 31, 2026** (chain snapshots) and **November 6, 2026** (option trades). Earlier days, and days the app did not follow, have no options data: scripts get `available = false` with a reason, never an error.
- Option trades cover a **followed subset** of the chain, not the whole of it: today the 0DTE options of SPX and NDX in a band around the price, recentred as the price moves, and SPY and QQQ when a script or a display reads them.

### No look-ahead, by construction

One rule applies in live, Replay, long backtests and the built-in check: **a snapshot is visible at instant τ when its publication time, plus one second, is at or before τ.** The script reads the latest visible one.

- τ is the event's time in a handler, the close of a closed bar in the body, and the earlier of the close and "now" on the bar still forming (the clock live, the cursor in Replay).
- The extra second covers the difference between your computer's clock and the exchange's timestamps. If your clock is measurably behind, the margin grows and warning `W955` says so.
- Option prints become visible one second after they are handed over; a multi-leg structure about 2.5 seconds after its first leg, once it is closed.
- At equal times, order-by-order events, futures trades and book snapshots run first, then chain snapshots, then option events.

So a bar recalculated later, or replayed, sees the same snapshots at the same times as it did live, within the small quantization of the recording. Exceptions: partial snapshots, provisional open interest, delayed snapshots and exact publication times are recorded only while a script reads options live; other periods replay with complete snapshots only, published at their assembly time. Days older than the sessions kept answer `not_kept`.

### What a script never gets

- A script run from another computer, or while Strate is open to the network, receives no options data (`account` is `"none"`).
- A script never sees the settings of the app's options displays (expiry filters, manual offsets). Everything it uses is written in the script, so it gives the same result on every computer.

## A first script

Open the **Indicators** window of a chart, add **StrateScript (preview)** from the **Custom** category, and choose **Empty script**. In the **Code** mode, paste this and press **Run** (or **⌘↵**):

```strate
indicator "Options status" { overlay: false }
s = options.chain()
print(s.available, s.reason, s.source, s.underlying)   // → true check synthetic SPX
plot(s.available ? s.age / 1s : na, title: "Greeks age (s)")
```

`options.chain()` with no argument reads the index of the chart's family. The built-in check runs your script on a synthetic chain, which is why it prints `true check synthetic SPX`; on a live chart the same line prints `true ok live SPX`.

The first script on option trades adds up call and put contracts as they print (a running total, since `state` keeps its value from bar to bar), leaving spread legs to `option_block`:

```strate
indicator "Option prints per bar" {
  overlay: false,
  option_trades: { underlyings: ["SPX"] }
}
state calls = 0
state puts = 0
on option_trade(t) {
  if t.spread_leg { return }                  // legs of spreads are counted in option_block
  if t.is_call { calls += t.sign * t.size } else { puts += t.sign * t.size }
}
st = option_trades.status()
plot(st.available ? calls : na, #26a69a, title: "Call contracts")
plot(st.available ? puts : na, #ef5350, title: "Put contracts")
bg_color(st.state == "gap" ? #80808033 : na)
```

`t.sign` is +1 for a new print and −1 for a cancellation, so `total += t.sign * f(t)` stays exact for any `f`. Keep a script in **My indicators** to add it to any chart, or start from one of the built-in Options templates.

## The chain: `options.chain()`

### Arguments

Signature:

```
options.chain(underlying, source: "any", partial: false, basis:, ratio:)
```

| Argument | Values | Default |
|---|---|---|
| `underlying` | `"SPX"`, `"NDX"`, `"SPY"`, `"QQQ"`, written as a literal text | The index of the chart's family |
| `source:` | `"any"`, `"live"` (your connection only), `"delayed"` (the delayed source only) | `"any"` |
| `partial:` | `true` also shows a snapshot that is still loading | `false`: the latest complete snapshot |
| `basis:` | futures price minus index price, imposed | measured |
| `ratio:` | futures price divided by ETF price, imposed | measured |

`options.chain()` always returns a chain object, never `na`. The underlying must be a literal text (`options.chain("SPY")`), because Strate reads the script's text to decide which chains to load. `options.underlyings` lists the family's underlyings, index first.

### Always test `available`

When no snapshot can be read, `available` is false and `reason` says why. Missing data is never an error. The codes are stable; `reason_text` gives the same reason as an English sentence.

| `reason` | When |
|---|---|
| `ok` | A snapshot is visible. |
| `check` | The built-in check's synthetic chain is visible. |
| `no_options_for_instrument` | The chart is not ES, MES, NQ or MNQ, and no underlying was written. |
| `no_account` | Live: no options data connection, and no delayed snapshot received. |
| `connection_down` | Live: the connection is set up but not delivering, and no delayed snapshot received. |
| `loading` | Live: the first complete snapshot, or the expiries the script reads, are still loading. |
| `source_filtered` | Only the other source is available (see `source:`). |
| `not_recorded` | No snapshot is recorded for this day or this time. |
| `expiries_not_recorded` | Replay or long backtest: that time was recorded for other expiries only. |
| `before_first_snapshot` | This day has snapshots, but none is published yet at this instant. |
| `not_kept` | The day is older than the sessions you keep. |

```strate
indicator "Why not" { overlay: false }
s = options.chain("NDX")
print(s.available, s.reason, s.conversion)   // → false not_recorded none
d = options.chain(source: "delayed")
print(d.available, d.reason)   // → false source_filtered
plot(s.available ? 1 : 0, title: "NDX available")
```

On the check's ES chart there is no NDX chain, and no delayed one: hence the two printed reasons.

### Chain fields

| Field | Meaning |
|---|---|
| `available`, `reason`, `reason_text`, `underlying` | Whether a snapshot is visible, why not, and which underlying. |
| `source`, `delay` | `"live"`, `"delayed"`, `"synthetic"` (the check) or `"none"`; `0s` or `15m`. |
| `time`, `greeks_time`, `price_time` | Publication time in Strate (visibility is decided by it only); time of the latest greeks; time of the underlying's price. |
| `age`, `stale` | The script's instant minus `greeks_time`; true beyond 5 minutes (live) or 60 minutes (delayed). Information only. |
| `spot`, `chart_spot` | The underlying's price, and the same price on the chart. |
| `conversion`, `basis`, `ratio`, `conversion_time` | How index prices become chart prices (`"basis"`, `"ratio"`, `"manual"`, `"none"`). |
| `partial`, `coverage` | A partial snapshot (with `partial: true`) and the share of gamma exposure it covers, 0 to 1. |
| `oi_provisional`, `oi_day`, `oi_previous_day` | Whether the open interest is confirmed for the session, and which day it belongs to. |
| `closing`, `account` | A session close from the delayed source; `"connected"` or `"none"` live, `"unknown"` elsewhere. |
| `count`, `band_low`, `band_high` | Options in the snapshot; lowest and highest strike followed (index prices). |

### Filters

These named arguments select options in `count`, `options`, `strikes`, `expiries`, `zero_gamma` and `gex_at`. They combine with "and".

| Filter | Values |
|---|---|
| `type:` | `"call"`, `"put"`, `"both"` (default) |
| `expiry:` | `"all"` (default), `"0dte"`, `"no0dte"`, `"monthly"` |
| `dte_min:`, `dte_max:` | days to expiry, fractions allowed |
| `expiry_day:` | a day or a list of days (days since 1970-01-01, like `session.day`) |
| `settlement:` | `"am"`, `"pm"`, `"both"` (default) |
| `strike_min:`, `strike_max:` | index (or ETF) prices |
| `price_min:`, `price_max:` | chart prices |
| `min_oi:` | minimum open interest |

`"0dte"` means the expiries of the reference day: after the 4 p.m. close and over the weekend it is the next session's expiry, never an empty list. `"monthly"` is the third Friday of the month (the Thursday before when that Friday is a market holiday).

```strate
indicator "Chain counts" { overlay: false }
s = options.chain()
print(s.count(), s.count(expiry: "0dte"), s.count(type: "call"), s.count(expiry: "monthly"))   // → 136 34 68 34
plot(s.count(expiry: "0dte", min_oi: 1000), title: "0DTE options with OI ≥ 1000")
```

### Chain methods

| Method | Returns |
|---|---|
| `s.options(filters…, max: 2000)` | A list of options (`max` from 1 to 20,000). |
| `s.count(filters…)` | The number of options kept (cheap). |
| `s.strikes(filters…, step:)` | Strike rows sorted by strike; `step:` groups strikes by a chart distance. |
| `s.option(strike, expiry_day, type, settlement:)` | One option, or `na`. |
| `s.expiries(filters…)` | Expiries: `.day`, `.time`, `.settlement`, `.dte`, `.count`. |
| `s.zero_gamma(filters…, range: 20, index: false)` | The zero-gamma level as a chart price (or an index price), or `na`. |
| `s.gex_at(index_price, filters…)` | Total dealer gamma exposure if the underlying were at that price. |
| `s.to_chart(index_price)`, `s.to_index(chart_price)` | Conversion between index and chart prices. |

`zero_gamma` recomputes the gamma of every kept option with Black-Scholes along a range of prices, weighted by open interest (calls +, puts −), and returns the crossing nearest to the current price, searching within `range` percent and within the strikes followed. It is computed once per snapshot and set of filters, then cached.

### Option and strike fields

| Option field | Meaning |
|---|---|
| `strike`, `price` | Strike as an index price; the same strike as a chart price. |
| `is_call` | True for a call, false for a put (there is no `type` field). |
| `settlement`, `expiry`, `expiry_day`, `dte` | `"am"` or `"pm"`; expiry instant; expiry day; days to expiry. |
| `oi`, `gamma`, `iv` | Open interest; gamma published by the source; implied volatility as a fraction. |
| `gex`, `dealer_gex` | `gex`: gamma exposure in dollars per 1 % move, always positive. `dealer_gex`: `+gex` for a call, `−gex` for a put (dealers assumed long calls, short puts, as on the app's charts). |
| `delta`, `feed_delta` | Black-Scholes delta recomputed by Strate (r = 0); delta published by the source. Choose your convention. |
| `prev_volume`, `prev_close` | Previous session's volume and closing price of the option. |
| `vanna`, `charm` | Dealer vanna and charm, the same method as the app's displays. Estimates from open interest, not dealers' actual positions. |

A **strike row** from `s.strikes()` has `strike`, `price`, `call_oi`, `put_oi`, `call_gex`, `put_gex`, `net_gex`, `vanna`, `charm`, `options`, `call_prev_volume` and `put_prev_volume`. The walls below use the app's definition (largest call and put gamma exposure); they are a recipe, so change it as you like.

```strate
indicator "Option walls" { overlay: true }
exp = input.choice("Expiries", ["all", "0dte", "no0dte", "monthly"], "all")
s = options.chain()
cw = na
pw = na
bestC = 0
bestP = 0
if s.available {
  for k in s.strikes(expiry: exp) {
    if k.call_gex > bestC { bestC = k.call_gex; cw = k.price }
    if k.put_gex > bestP { bestP = k.put_gex; pw = k.price }
  }
}
plot(cw, #26a69a, title: "Call wall", style: "step")
plot(pw, #ef5350, title: "Put wall", style: "step")
plot(s.available ? s.zero_gamma(expiry: exp) : na, #e8c15a, title: "Zero gamma", style: "dashed")
```

### Chart prices and index prices

An index and its futures contract do not trade at the same price, and an ETF trades at a fraction of its index. Every price of the options world (`strike`, `spot`, `strike_min`…) is an index or ETF price; every field named `price` (and `chart_spot`, `to_chart`, `zero_gamma`) is a chart price.

- **Index** (SPX on ES or MES, NDX on NQ or MNQ): chart price = index price + basis.
- **ETF** (SPY, QQQ): chart price = ETF price × ratio.

The engine measures the conversion on the chart's own trades: the last trade at or before the snapshot's price time, at most 60 seconds earlier, never a later one. Without such a trade, chart prices are `na` and warning `W954` appears. `basis:` or `ratio:` impose the conversion.

```strate
indicator "Conversion" { overlay: true }
s = options.chain()
print(s.conversion, s.to_chart(s.spot) == s.chart_spot)   // → basis true
m = options.chain(basis: 20)
print(m.conversion, m.basis)   // → manual 20
plot(s.chart_spot, #e8c15a, title: "Index on the chart", style: "step")
```

### Which expiries are loaded

Strate reads your script's text to decide which expiries to load. The script loads only the expiries it uses when **every** call that depends on expiries has a literal filter: `expiry: "0dte"`, `"no0dte"` or `"monthly"`, `dte_max: N`, or `expiry_day: J`. Anything else (a variable, a calculation, `expiry: "all"`, no filter) loads every expiry, which takes longer.

```strate
indicator "0DTE gamma" { overlay: false }
s = options.chain()
plot(s.available ? s.count(expiry: "0dte") : na, title: "0DTE options")
plot(s.available ? s.zero_gamma(expiry: "0dte") : na, title: "0DTE zero gamma")
```

### New snapshots: `on options`

Signature:

```
on options(s) { … }
```

The handler runs once for each snapshot published, for each underlying the script reads; `s.underlying` tells which one. Declare it at the top level. Partial snapshots run it only when the script contains `partial: true` somewhere.

```strate
indicator "Call wall moves" { overlay: true }
state last = na
on options(s) {
  if s.available and s.underlying == "SPX" {
    best = 0
    w = na
    for k in s.strikes(type: "call") {
      if k.call_gex > best { best = k.call_gex; w = k.price }
    }
    if not na(last) and not na(w) and w != last { label.new(s.time, w, "call wall " + str(last) + " → " + str(w)) }
    last = w
  }
}
plot(close, title: "Close")
```

A handler that only stores what it needs in `state` variables, and lets the body draw, is usually cheaper.

### Data quality

Every snapshot says what it is; nothing is filtered behind your back.

- **Source.** With the default `source: "any"`, the chain follows what the app delivers and never flips back and forth between real-time and delayed. When it switches to delayed, `greeks_time` can move back by about 15 minutes.
- **Three times.** `time` is when the snapshot became visible; `greeks_time` and `price_time` say how old its contents are. Greeks are refreshed in blocks, so `age` is often above a minute even in real time.
- **Partial snapshots** appear in the first minutes after Strate starts following an underlying. They are ignored unless you pass `partial: true`.
- **Open interest** is published once a day, early in the morning, New York time. Before that, the snapshot carries the previous figures: `oi_provisional` and `oi_previous_day` say so.

```strate
indicator "Options quality" { overlay: false }
s = options.chain(partial: true)
print(s.source, s.partial, s.coverage, s.oi_provisional, s.oi_previous_day, s.closing, s.account)   // → synthetic false 1 false false false unknown
plot(s.available and not s.stale ? 1 : 0, title: "Fresh")
```

### Market totals: `options.totals`

`options.totals(u)` is ready for the source's own whole-market totals (volumes, put/call ratio, IV by expiry). **Today your options data connection does not provide these totals**: `available` is false and `reason` is `"not_provided"`, so a script written for them runs and shows nothing rather than a zero.

```strate
indicator "Market put/call" { overlay: false }
m = options.totals("SPX")
plot(m.available ? m.put_call_ratio : na, title: "P/C (whole market)")
```

## Option trades

Besides the chain, scripts read the **option prints themselves**, one at a time, and the **blocks** Strate builds from them. Nothing is computed for you: totals, ratios and profiles are scripts, which keeps every definition in your hands.

### The header: `option_trades:`

Settings live in the script's header. Every key is optional, and every key except `underlyings` accepts an `input.*` setting. The header alone loads nothing: a handler or a call to `option_trades.…` does.

| Key | Default | Role |
|---|---|---|
| `underlyings` | the chart family's index | Which feeds to load: a literal list among `"SPX"`, `"NDX"`, `"SPY"`, `"QQQ"`. |
| `from` | `rolling` | First instant at which the handlers run: `session`, `rth`, `start`, `rolling`, `"HH:MM"`, `auto`, `launch`. |
| `bursts`, `burst_delay`, `burst_by` | `true`, `1000ms`, `"side"` | Group successive orders of one option into bursts. |
| `buy_from`, `sell_to` | `1.0`, `0.0` | Side of a simple order from its position in the bid-ask spread (default: strictly at the ask / at the bid). |
| `structure_wait`, `structure_tolerance`, `by_condition` | `1500ms`, `3ms`, `true` | How the legs of a structure are assembled. |
| `side_margin`, `edge_margin` | `0.25`, `25` | When a structure counts as bought or sold; when it may be incomplete. |
| `backfill` | `"separate"` | Prints sent again at subscription: kept apart, merged, or dropped. |
| `retention` | `15m` | Memory of prints, to match cancellations, corrections and duplicates (5 min to 4 h). Longer uses more memory. |
| `min_print_size`, `min_block_size` | `1` | Skip small prints or blocks before the handler runs. |
| `max_bar_events`, `fuel_per_day` | see errors | Protection limits (`E957`, `E967`). |
| `basis`, `ratio` | measured | Conversion to chart prices imposed, as in `options.chain`. |

### Prints: `on option_trade(t)`

Runs for every print of the requested underlyings, legs of spreads included, and for cancellations and corrections:

- a **cancellation** repeats every field of the original print; only `sign` changes (−1);
- a **correction** gives two calls in a row: `kind = "cancel"` (old value) then `kind = "new"`, both with `correction = true`;
- a cancellation whose origin is unknown arrives with `matched = false` and every amount at 0, so a total is never poisoned (`W959` counts them);
- duplicates are dropped.

| Fields | Meaning |
|---|---|
| `time`, `trade_time`, `recv_time`, `session_day`, `id`, `seq` | Visibility time; exchange trade time; hand-over time; session day; rank of the print in the day; feed sequence. |
| `kind`, `correction`, `sign`, `matched` | `"new"` or `"cancel"`; part of a correction; +1 / −1; origin found. |
| `underlying`, `root`, `symbol`, `strike`, `is_call`, `expiry`, `expiry_day`, `dte`, `years`, `settlement`, `multiplier` | The option. `strike` is an index price: use it as the key of a total by strike. |
| `price`, `chart_price` | The strike as a chart price. **Not the premium.** |
| `premium`, `size`, `notional` | Contract price, contracts, `premium × size × multiplier`. |
| `bid`, `ask`, `side`, `dir`, `position`, `feed_side` | Quote carried by the print; `"buy"`, `"sell"`, `"mid"` or `"unknown"`; +1, −1, 0 or `na`; position in the spread; raw aggressor flag of the feed. |
| `oi`, `spot`, `iv`, `iv_source` | Open interest known at the print; underlying price; implied volatility and where it came from. |
| `delta`, `gamma`, `vega`, `theta`, `vanna`, `charm` | Black-Scholes greeks of the option at that spot and IV. |
| `delta_dollars`, `gamma_dollars`, `future_equivalent` | Amounts signed on the **customer** side by `dir`; 0 at mid. |
| `spread_leg`, `backfill`, `in_gap`, `exchange`, `condition` | Leg of a structure; sent again at subscription; received during a gap; raw feed flags. |

### Blocks: `on option_block(b)`

Runs for each action of the grouping, when it becomes true: a block **appears**, a burst **grows**, a structure closes, a block is **cancelled** or **corrected** (`b.kind`: `"appear"`, `"grow"`, `"cancel"`, `"correct"`). The legs of a structure never appear alone here. A block is an order or a burst of one option, or a multi-leg structure: verticals, ratios, straddles, strangles, risk reversals, butterflies, condors, iron condors and iron butterflies, calendars, diagonals…

**One rule for totals.** `b` is the state after the action and `b.prev` the state delivered at the previous call for this block (`na` at `appear`). Context (spot, IV, greeks, chart price) is frozen in the block at its first piece, so adding `value(b)` and removing `value(b.prev)` is exact:

```strate
indicator "Customer delta of blocks" {
  overlay: false,
  option_trades: { underlyings: ["SPX"] }
}
state d = 0
on option_block(b) { d += b.delta_dollars - (na(b.prev) ? 0 : b.prev.delta_dollars) }
plot(d / 1e6, title: "Customer delta ($M)")
```

Useful block fields: `is_structure`, `family`, `name`, `short_name`, `size`, `buy_size`, `sell_size`, `notional`, `net_notional`, `delta_dollars`, `gamma_dollars`, `future_equivalent`, `strike`, `price`, `side` (`"bought"`, `"sold"`, `"undetermined"`… for a structure), `dir`, `net`, `mid`, `ratio`, `incomplete`, `alerts` and `legs` (each leg with its own strike, side, premium, greeks and amounts).

### Feed events: `on option_feed(e)`

| `e.kind` | When |
|---|---|
| `"gap_start"` | Start of a loss known at the time (connection down, full queue, sleep). |
| `"gap"` | At the known end of a gap, with `start`, `end`, `cause` and `lost`. |
| `"coverage"` | The list of followed options changed (band, expiries, added, removed). |
| `"open"`, `"close"` | The feed or the recorder started or stopped. |

### Status and coverage

`option_trades.status(u)` and `option_trades.coverage(u)` read the feed at the script's instant, so a closed bar gives the same value live and in Replay.

- `status`: `state` (`"ok"`, `"gap"`, `"not_recorded"`, `"before_first_event"`, `"not_kept"`, `"check"`), `available`, `reason_text`, `recorded`, `since`, `last`, `gaps`, `lost`, `unmatched`, `duplicates`, `live_state`…
- `coverage`: `count`, `strike_low`, `strike_high`, `price_low`, `price_high`, `expiries`, `symbols`, `time`, and two methods: `covers(strike, expiry_day, "call"|"put")` and `covered_time(…, since: t)`.
- `option_trades.to_chart(strike, u)` and `option_trades.to_index(price, u)` convert at the script's instant.

> **A strike that is not followed is not a zero.** Prints cover the followed band only. Test `coverage()` before reading "nothing traded" into an empty strike.

## Black-Scholes: `bs.*`

Signature:

```
bs.price(type, spot, strike, years, iv, rate: 0, dividend: 0)
bs.delta / bs.gamma / bs.vega / bs.theta / bs.vanna / bs.charm (same arguments)
bs.iv(type, premium, spot, strike, years, rate: 0, dividend: 0)
```

Pure functions, with no data, available everywhere. `type` is `"call"` or `"put"`, `years` the time to expiry in years, `iv` and `rate` as fractions (0.2 = 20 %). Units: price in points of the underlying; gamma per point; vega per unit of volatility (× 0.01 per volatility point); theta and charm per **year** (÷ 365 per calendar day). An invalid constant (`"straddle"`, negative `years`, `iv` at or below 0) gives `E954`; an invalid computed value gives `na`. `bs.*` alone loads no options data.

```strate
indicator "Black-Scholes" { overlay: false }
print(bs.price("call", 100, 100, 1, 0.2, rate: 0.05))   // → 10.450584
print(bs.delta("put", 100, 100, 0.25, 0.2), bs.gamma("call", 100, 100, 0.25, 0.2))   // → -0.480061 0.039844
print(bs.iv("call", 3.987761, 100, 100, 0.25))   // → 0.2
s = options.chain()
c = s.available ? s.option(round(s.spot / 25) * 25, s.expiries()[0].day, "call") : na
plot(na(c) ? na : bs.price("call", s.spot, c.strike, c.dte / 365, c.iv) * 2, title: "Call value × 2 (index points)")
```

## Live, Replay, long backtest and the check

|  | Live | Replay | Long backtest | Built-in check |
|---|---|---|---|---|
| Chain snapshots | today's, and the previous session's from recordings | recordings of the replayed day and the previous session, up to the cursor | recordings of each day, and the previous session's last snapshot | a synthetic chain on the last 60 bars |
| Option trades | today's recordings, up to the last batch | recordings of the replayed day and the day before, cut at the cursor | recordings covering each day of the MBO file | a synthetic day on the last 60 bars |
| `source` | `live` or `delayed` | as recorded | as recorded | `synthetic` |
| Conversion to chart prices | chart trades | chart trades | the replay file's trades | synthetic trades |

- **Replay and the app agree.** At the replayed instant, `options.chain()` and the app's options displays (GEX levels, profiles, IV surface, dealer scenarios) use the same snapshot.
- **Long backtests** run a script day by day over local MBO replay files. Scripts that read option trades need, for the same days, the MBO file **and** the option recording: only days with both are played (`W956` for the others). Days without a chain recording give `not_recorded` and a `W953` warning.
- **The built-in check** runs your script on synthetic data before it executes: a chain for SPX and SPY, and a synthetic day of prints with buys, sells, mids, bursts, spreads, cancellations, corrections and a gap.
- **Live late data.** When an option batch reaches the engine after its bar was passed, the bars concerned are recalculated (`W958`). Alerts, sounds and simulated orders already sent are not changed.

```strate
indicator "Options source check" { overlay: false }
s = options.chain()
recorded = s.available or s.reason == "before_first_snapshot"
bg_color(not s.available and s.reason == "not_recorded" ? #ff980020 : na)
plot(recorded ? 1 : 0, title: "Options recorded")
```

### Warnings

Missing or degraded options data never stops a script (the protection limits `E957`, `E966` and `E967` are errors, see common errors). It appears as non-blocking warnings under the editor and in the Console, once per cause and per run.

| Code | Meaning |
|---|---|
| `W951` | The chain was unavailable at the script's last reading, or the limit of followed options left some out. |
| `W952` | The script is reading the delayed public source (15 min). |
| `W953` | A day read in Replay or a long backtest has no chain recording. |
| `W954` | No futures trade near the options price time: chart prices are `na`. |
| `W955` | Your computer's clock is behind the exchange: snapshots are published that much later. |
| `W956` | A day has no option trades recording (long backtest: or no MBO file). |
| `W957` | Gaps are visible in the option trades read. |
| `W958` | Option trades reached the engine late live: bars recalculated. |
| `W959` | Cancellations without origin (amounts at 0). |
| `W960` | A header key looks like `option_trades` (typo). |
| `W961` | Live, the recording of that underlying is turned off: today's Replay will differ. |
| `W962` | NDX 0DTE prints are sparse: add `"QQQ"`. |

## Examples and templates

Complete scripts, ready to paste. The seven marked **Built-in template** ship with the app: open the script menu at the top of the StrateScript panel and load them from the examples, category **Options**.

### Zero gamma and walls

The zero-gamma level and the strikes with the largest call and put gamma exposure, converted to chart prices, with a small status table. Expiries and source are settings.

Needs: **chain snapshots**

```strate
indicator "Zero gamma and walls" { overlay: true }

exp = input.choice("Expiries", ["all", "0dte", "no0dte", "monthly"], "all")
src = input.choice("Source", ["any", "live", "delayed"], "any")
rangePct = input.float("Zero-gamma search range (% of spot)", 20, min: 1, max: 50)
zgCol = input.color("Zero gamma", #e8c15a, group: "Colors")
callCol = input.color("Call wall", #26a69a, group: "Colors")
putCol = input.color("Put wall", #ef5350, group: "Colors")

s = options.chain(source: src)

// walls: the strike with the largest call (put) gamma exposure; the lowest strike wins a tie
callWall = na
putWall = na
bestCall = 0
bestPut = 0
if s.available {
  for k in s.strikes(expiry: exp) {
    if k.call_gex > bestCall { bestCall = k.call_gex; callWall = k.price }
    if k.put_gex > bestPut { bestPut = k.put_gex; putWall = k.price }
  }
}
zg = s.available ? s.zero_gamma(expiry: exp, range: rangePct) : na

plot(zg, zgCol, title: "Zero gamma", style: "dashed", width: 2)
plot(callWall, callCol, title: "Call wall", style: "step")
plot(putWall, putCol, title: "Put wall", style: "step")

var t = table.new("top_right", 2, 3)
if bar.last {
  t.cell(0, 0, "Options")
  t.cell(1, 0, s.underlying + " " + s.source)
  t.cell(0, 1, "Greeks age")
  t.cell(1, 1, s.available ? str(s.age) : "—")
  t.cell(0, 2, "Status")
  t.cell(1, 2, s.reason)
}
```

### Near an options wall (Alert)

Alerts once when the close arrives within a distance of the call wall or the put wall, on closed bars, with a minimum delay between alerts.

Needs: **chain snapshots**

```strate
indicator "Near an options wall" { overlay: true }

exp = input.choice("Expiries", ["all", "0dte", "no0dte", "monthly"], "all")
distTicks = input.int("Distance (ticks)", 8, min: 0)
every = input.duration("Minimum delay between alerts", 15m)

s = options.chain()
callWall = na
putWall = na
bestCall = 0
bestPut = 0
if s.available {
  for k in s.strikes(expiry: exp) {
    if k.call_gex > bestCall { bestCall = k.call_gex; callWall = k.price }
    if k.put_gex > bestPut { bestPut = k.put_gex; putWall = k.price }
  }
}
plot(callWall, #26a69a, title: "Call wall", style: "step")
plot(putWall, #ef5350, title: "Put wall", style: "step")

nearCall = not na(callWall) and abs(close - callWall) <= price(distTicks)
nearPut = not na(putWall) and abs(close - putWall) <= price(distTicks)
// alert on closed bars, when the condition becomes true
alert(nearCall and not nearCall[1] and bar.confirmed, "Near the call wall " + str(callWall), every: every)
alert(nearPut and not nearPut[1] and bar.confirmed, "Near the put wall " + str(putWall), every: every)
marker(nearCall and not nearCall[1] and bar.confirmed, shape: "diamond", location: "above", color: #26a69a, size: "small")
marker(nearPut and not nearPut[1] and bar.confirmed, shape: "diamond", location: "below", color: #ef5350, size: "small")
```

### Absorption with zero gamma (Simulated strategy)

Order-by-order absorption at the traded price, taken only on the chosen side of zero gamma, with the snapshot visible at that trade. Which side is "right" is your hypothesis: it is a setting.

Needs: **chain snapshots** and **order-by-order (MBO) data**

```strate
strategy "Absorption with zero gamma" { overlay: true, mbo_from: rth, level_history: 2m, latency: 60ms, costs: { commission: 2.5 usd, slippage: 1 tick } }

win = input.duration("Window", 30s, group: "Absorption")
minRank = input.float("Min aggressor volume rank", 97, min: 0, max: 100, group: "Absorption")
normWin = input.duration("Normalize over", 30m, group: "Absorption")
heldPct = input.float("Held at best (% of window)", 60, min: 0, max: 100, group: "Absorption")
maxMove = input.int("Max price move (ticks)", 2, min: 0, group: "Absorption")
rule = input.choice("Take", ["longs above zero gamma, shorts below", "longs below zero gamma, shorts above"], "longs above zero gamma, shorts below", group: "Options")
exp = input.choice("Expiries", ["all", "0dte", "no0dte", "monthly"], "all", group: "Options")
src = input.choice("Options source", ["live", "any"], "live", group: "Options")
maxAge = input.duration("Max greeks age", 5m, group: "Options")
stopTicks = input.int("Stop (ticks)", 8, min: 1, group: "Exits")
targetTicks = input.int("Target (ticks)", 16, min: 1, group: "Exits")

on trade(t) {
  lv = mbo.level(t.price, window: win)
  // normalized at every trade, before any condition
  rk = norm.rank(na(lv) ? na : lv.aggressor_volume, normWin, min_count: 200)
  // the snapshot visible at this trade; zero gamma is computed once per snapshot
  g = options.chain(source: src)
  zg = g.available and g.age <= maxAge ? g.zero_gamma(expiry: exp) : na
  absorbed = not na(lv) and rk >= minRank and lv.time_at_best >= win * heldPct / 100 and lv.displayed > 0 and abs(t.price - open) / instrument.tick <= maxMove
  if absorbed and not na(zg) and position.flat and position.pending == 0 {
    above = t.price > zg
    longsAbove = rule == "longs above zero gamma, shorts below"
    // sellers hitting a bid that holds: buyers absorb; buyers lifting an offer that holds: sellers absorb
    if t.is_sell and (above == longsAbove) {
      enter("buy", stop: price(stopTicks), target: price(targetTicks), timeout: 20m, tag: "bid holds")
    } else if t.is_buy and (above != longsAbove) {
      enter("sell", stop: price(stopTicks), target: price(targetTicks), timeout: 20m, tag: "offer holds")
    }
  }
}

s = options.chain(source: src)
plot(s.available ? s.zero_gamma(expiry: exp) : na, #e8c15a, title: "Zero gamma", style: "dashed")

on exit(x) {
  label.new(x.time, x.price, x.reason + " " + str(x.r, "+0.00") + "R", color: x.usd > 0 ? #22c55e : #ef4444)
}
```

### Options Net Premium Flow (Built-in template)

Net premium bought in calls and in puts since the open, from blocks, so spread legs are never counted twice; the measure can be premium, contracts or customer delta dollars.

Needs: **option trades**

```strate
// Template: Net Premium Flow — net premium bought in calls and in puts, from option blocks (orders, bursts and closed structures),
// so the legs of a spread are never counted twice. Options trades exist on recorded days only (since 2026-11-06).
// retention: 15m keeps memory low enough to add underlyings (a cancellation more than 15 min after its print then adds 0).
// Rule b / b.prev: add the block, remove what was added for its previous state (value() reads only fields of the block).
indicator "Net premium flow" {
  overlay: false,
  option_trades: { underlyings: ["SPX"], from: session, retention: 15m,
                   buy_from: input.float("Buy from (position in spread)", 1.0, min: 0.5, max: 1, group: "Side"),
                   sell_to: input.float("Sell up to (position in spread)", 0.0, min: 0, max: 0.5, group: "Side") }
}
moneyness = input.choice("Strikes", ["all", "otm", "itm"], "all")
unit = input.choice("Measure", ["premium", "contracts", "delta $"], "premium")
state calls = 0
state puts = 0

fn keep(leg) {
  if moneyness == "all" or na(leg.spot) { return true }
  otm = leg.is_call ? leg.strike > leg.spot : leg.strike < leg.spot
  return moneyness == "otm" ? otm : not otm
}
fn amount(leg) {
  if unit == "delta $" { return nz(leg.delta_dollars) }   // already signed (customer side)
  v = unit == "premium" ? leg.notional : leg.size
  return nz(leg.dir) * v
}
fn add(x, k) {
  if na(x) { return }
  for leg in x.legs {
    if na(leg.dir) or leg.dir == 0 or not keep(leg) { continue }
    if leg.is_call { calls += k * amount(leg) } else { puts += k * amount(leg) }
  }
}
on session(s) { if s.kind == "session_open" { calls = 0 ; puts = 0 } }
on option_block(b) {
  add(b, 1)
  add(b.prev, -1)
}
st = option_trades.status()
plot(st.available ? calls : na, #26a69a, title: "Net call flow")
plot(st.available ? puts : na, #ef5350, title: "Net put flow")
plot(st.available ? calls - puts : na, #e8c15a, title: "Calls - puts")
bg_color(st.state == "gap" ? #80808033 : na)
hline(0)
```

### Options Big Trades (Built-in template)

Labels large orders, bursts and spreads on the price chart at the strike's chart price; a burst that grows keeps one label, updated in place.

Needs: **option trades**

```strate
// Template: big option orders and spreads, labelled on the chart at the strike's chart price. A burst that grows keeps ONE label
// (map by b.id, updated with set_text). Structures appear after their wait (about 2.5 s with the 1 s margin). 500 objects at most:
// raise the threshold rather than show thousands.
indicator "Options big trades" {
  overlay: true,
  option_trades: { underlyings: ["SPX"], min_block_size: input.int("Prefilter (contracts)", 5, min: 1) }
}
by = input.choice("Large by", ["notional", "contracts", "rank"], "notional")
minNotional = input.float("Min notional ($)", 250000, step: 50000)
minSize = input.int("Min contracts", 100, min: 1)
minRank = input.float("Min rank (0-100)", 99, min: 0, max: 100)
showStructures = input.bool("Show structures", true)
state shown = map()          // b.id -> label, to follow a burst that grows

fn big(x) {
  if na(x) { return false }
  if by == "notional" { return x.notional >= minNotional }
  if by == "contracts" { return x.size >= minSize }
  return false
}
fn text(b) {
  head = b.is_structure ? b.short_name + " " + b.ratio : (b.legs[0].is_call ? "C " : "P ") + str(b.strike)
  return head + " " + b.side + " " + str(b.size) + " / " + str(b.notional, "0.0k") + (b.incomplete ? " ?" : "")
}
on session(s) { if s.kind == "session_open" { shown.clear() } }
on option_block(b) {
  if b.is_structure and not showStructures { return }
  lb = shown.get(b.id)
  if not na(lb) {                                   // already shown: follow its state
    if b.kind == "cancel" { lb.delete() } else { lb.set_text(text(b)) }
    return
  }
  if b.kind == "cancel" { return }
  isBig = false
  if by == "rank" {
    // rank among the blocks of the last day, fed only at their first appearance (never twice for a burst)
    if b.kind == "appear" { isBig = norm.rank(b.notional, 1d, by: b.underlying, min_count: 200) >= minRank }
  } else {
    isBig = big(b) and not big(b.prev)
  }
  if isBig and not na(b.price) {
    shown.set(b.id, label.new(b.time, b.price, text(b), color: b.dir > 0 ? #26a69a : b.dir < 0 ? #ef5350 : #808080))
  }
}
```

### Dealer Gamma Flow (Built-in template)

Gamma, delta or futures equivalent dealers would have added today, assuming they take the other side of every customer trade (a convention the script makes explicit), SPX and SPY in one unit.

Needs: **option trades**

```strate
// Template: dealer gamma flow, ASSUMING the dealer takes the other side of every customer trade (a convention, not a fact).
// Simple orders from option_trade (t.sign undoes cancellations), structures from option_block (b / b.prev rule): no double count.
// gamma_dollars = dollars of delta per 1 % move, signed on the customer side; the dealer is the opposite.
// Near expiry the gamma of a 0DTE option explodes (T -> 0): without a cutoff, the prints of the last minutes make most of the day's
// total. They are skipped by default (input below, 0 = keep all). The total also keeps what expired options added until the session
// resets: read it as flow added today, not as the dealers' position now.
indicator "Dealer gamma flow" {
  overlay: false,
  option_trades: { underlyings: ["SPX", "SPY"], from: session, backfill: "drop", retention: 15m }
}
measure = input.choice("Measure", ["gamma $", "delta $", "futures"], "gamma $")
skipLast = input.int("Skip the last minutes before expiry", 30, min: 0)
state flow = 0
fn val(x) { return measure == "gamma $" ? x.gamma_dollars : measure == "delta $" ? x.delta_dollars : x.future_equivalent }
// years = time to expiry used by the greeks, fixed at the print (the same for its cancellation)
fn keep(x) { return na(x.years) or x.years * 525600 >= skipLast }
fn legs(x) {
  if na(x) { return 0 }
  s = 0
  for leg in x.legs { if keep(leg) { s += nz(val(leg)) } }
  return s
}
on session(s) { if s.kind == "session_open" { flow = 0 } }
on option_trade(t) {
  if t.spread_leg or not keep(t) { return }        // structures go through option_block
  v = val(t)
  if na(v) { return }
  flow += -t.sign * v                              // dealer = opposite of the customer
}
on option_block(b) {
  // no test on b.dir: a leg whose side is unknown adds 0, so b / b.prev stays exact when a leg is cancelled
  if not b.is_structure { return }
  flow += -(legs(b) - legs(b.prev))
}
ok = option_trades.status("SPX").available
plot(ok ? flow : na, #2962ff, title: "Dealer flow added today")
plot(ok ? norm.zscore(flow, 500) : na, #e8c15a, title: "z-score")
hline(0)
```

### Options Put/Call Ratio (Built-in template)

Put/call ratio of the followed strikes over the last bars, in contracts or premium, and a whole-market line that stays empty until the connection publishes market totals.

Needs: **option trades**

```strate
// Template: put/call ratio of the TRACKED strikes over the last n bars (cumulative totals minus their value n bars earlier: a
// cancellation is removed from the bar where it arrives), and the whole-market ratio when the options data connection publishes it
// (options.totals: available = false, reason "not_provided" otherwise — never a zero).
indicator "Put/call ratio" {
  overlay: false,
  option_trades: { underlyings: ["SPX"], from: session }
}
unit = input.choice("Measure", ["contracts", "premium"], "contracts")
onlyBought = input.bool("Bought only", false)
n = input.int("Bars", 30, min: 1)
state c = 0
state p = 0
on option_trade(t) {
  if t.spread_leg { return }
  if onlyBought and t.dir != 1 { return }
  v = t.sign * (unit == "contracts" ? t.size : t.notional)
  if t.is_call { c += v } else { p += v }
}
cs = c
ps = p
dc = cs - nz(cs[n])
dp = ps - nz(ps[n])
band = dc > 0 ? dp / dc : na
m = options.totals("SPX")
plot(option_trades.status().available ? band : na, #e8c15a, title: "P/C (tracked strikes, last bars)")
plot(m.available ? m.put_call_ratio : na, #9c27b0, title: "P/C (whole market, day)")
hline(1)
```

### Options Volume by Strike (Built-in template)

Contracts traded since the open, by strike, as horizontal bars at the strike's chart price, with dotted lines around the followed band.

Needs: **option trades**

```strate
// Template: options volume by strike, drawn as horizontal bars at the strike's chart price on the last bar. The key is the INDEX
// strike (t.strike: stable all day), converted with option_trades.to_chart(k) at the script's instant. Outside the two dotted lines
// the strikes are NOT tracked: no bar there does not mean zero.
indicator "Options volume by strike" {
  overlay: true,
  option_trades: { underlyings: ["SPX"], from: session }
}
count = input.choice("Count", ["all", "buy", "sell", "net"], "net")
splitCP = input.bool("Calls right, puts left", true)
state calls = map()          // key = index strike
state puts = map()
on session(s) { if s.kind == "session_open" { calls.clear() ; puts.clear() } }
on option_trade(t) {
  d = nz(t.dir, 0)
  s = count == "all" ? 1 : count == "net" ? d : (count == "buy" ? (d == 1 ? 1 : 0) : (d == -1 ? 1 : 0))
  v = t.sign * s * t.size
  if t.is_call { calls.set(t.strike, calls.get(t.strike, 0) + v) } else { puts.set(t.strike, puts.get(t.strike, 0) + v) }
}
if bar.last {
  mx = 1
  for k in calls.keys() { mx = max(mx, abs(calls.get(k))) }
  for k in puts.keys() { mx = max(mx, abs(puts.get(k))) }
  for k in calls.keys() {
    v = calls.get(k)
    y = option_trades.to_chart(k)
    if not na(y) { hbar(y, abs(v), mx, side: right, color: v >= 0 ? #26a69a : #ef5350) }
  }
  for k in puts.keys() {
    v = puts.get(k)
    y = option_trades.to_chart(k)
    if not na(y) { hbar(y, abs(v), mx, side: splitCP ? left : right, color: v >= 0 ? #42a5f5 : #ff9800) }
  }
  cv = option_trades.coverage()
  if cv.count > 0 and not na(cv.price_low) {
    line.new(bar.time, cv.price_low, bar.time + 60s, cv.price_low, color: #808080, style: "dotted")
    line.new(bar.time, cv.price_high, bar.time + 60s, cv.price_high, color: #808080, style: "dotted")
  }
}
```

### 25 Delta Skew (Built-in template)

Put IV minus call IV at the 0DTE strikes whose delta is closest to ±0.25, from the chain snapshots; the delta convention is a setting.

Needs: **chain snapshots**

```strate
// Template: 25 delta skew of the 0DTE expiry, from the chain snapshots (not from trades): put IV minus call IV at the strikes whose
// delta is closest to ±target. o.delta is recomputed with r = 0; o.feed_delta is the delta published by the source (na if absent).
indicator "25 delta skew" { overlay: false }
target = input.float("Delta", 0.25, step: 0.05, min: 0.05, max: 0.5)
useFeed = input.bool("Use the source delta", false)
s = options.chain()
skew = na
if s.available {
  bc = na
  bp = na
  dc = 9
  dp = 9
  for o in s.options(expiry: "0dte", max: 2000) {
    d = useFeed ? o.feed_delta : o.delta
    if na(d) { continue }
    if o.is_call and abs(d - target) < dc { dc = abs(d - target) ; bc = o }
    if not o.is_call and abs(d + target) < dp { dp = abs(d + target) ; bp = o }
  }
  if not na(bc) and not na(bp) { skew = bp.iv - bc.iv }
}
plot(skew, #e8c15a, title: "Put IV - call IV (0DTE)")
hline(0)
```

### Customer Delta Flow (Built-in template)

Customer delta added since the open by the blocks of SPX and SPY together, in millions of dollars, with the index part on demand.

Needs: **option trades**

```strate
// Template: customer delta flow of the index AND its ETF in one unit (dollars of delta: additive between SPX and SPY), from option
// blocks (b / b.prev rule: a burst that grows, a cancellation or a correction is counted exactly once). retention: 15m keeps
// the memory of two underlyings low (a cancellation more than 15 min after its print is then not matched and adds 0).
indicator "Customer delta flow" {
  overlay: false,
  option_trades: { underlyings: ["SPX", "SPY"], from: session, retention: 15m }
}
split = input.bool("Index and ETF apart", false)
state d = 0
state di = 0
on session(s) { if s.kind == "session_open" { d = 0 ; di = 0 } }
on option_block(b) {
  x = b.delta_dollars - (na(b.prev) ? 0 : b.prev.delta_dollars)
  d += x
  if b.underlying == "SPX" { di += x }
}
ok = option_trades.status("SPX").available
plot(ok ? d / 1e6 : na, #26a69a, title: "Customer delta ($M)")
plot(ok and split ? di / 1e6 : na, #42a5f5, title: "Index only ($M)")
hline(0)
```

## Limits, pitfalls and common errors

### Pitfalls

- **Call or put: read `o.is_call`.** An option has no `type` field; `o.type` is `E101`.
- **Not every bar has options.** Test `s.available` (or `na(x)`) before using a value.
- **The underlying must be literal.** `options.chain(u)` with a variable is `E951`.
- **Index price or chart price?** `strike` and `spot` are index prices; `price` and `chart_spot` are chart prices. A strike plotted on an ES chart lands tens of points away.
- **`t.price` is not the premium.** It is the strike as a chart price; the contract price is `t.premium`.
- **Key by `strike`, draw with `to_chart`.** The conversion moves during the day.
- **Double counting.** Prints include spread legs: filter `t.spread_leg`, or work in `on option_block`.
- **Always multiply by `t.sign`,** and in blocks add `value(b)` and remove `value(b.prev)`. Never skip a block because `b.dir` is `na`.
- **0DTE greeks near expiry.** Greeks are fixed at the print and the gamma of a 0DTE option explodes in its last minutes: skip prints with little time left (`t.years`), as Dealer Gamma Flow does.
- **Delayed data looks current.** Its `time` is recent while its content is 15 minutes old: a strategy should pass `source: "live"` or test `s.source` and `s.age`.
- **`"0dte"` after the close is the next session**, never an empty list.
- **One unfiltered call loads every expiry.** Filter every call with a literal to load less.
- **One budget per bar.** The first `zero_gamma` on a new snapshot is the expensive call; keep the number of different filter sets small.
- **`on options` runs for each underlying** the script reads: test `s.underlying`.
- **500 drawn objects at most.** Labels beyond 500 disappear, oldest first: raise the threshold.
- **The last second of a bar** belongs to the next bar, because of the one-second visibility margin.

### Common errors

| Code | Cause |
|---|---|
| `E101` | `o.type` on an option: read `o.is_call`. |
| `E111` | `on options` (or another handler) declared inside a block or a function. |
| `E932`, `E933` | Unknown chain field or chain method (the message lists the valid names). |
| `E951` | Unknown or non-literal underlying, or an invalid `source:`. |
| `E952` | Invalid argument or filter (`expiry: "weekly"`, `dte_min` above `dte_max`…). |
| `E953` | `max:`, `range:` or `step:` out of bounds. |
| `E954` | Invalid constant argument to `bs.*`. |
| `E955`, `E958` | Options data or option trades read inside `request()`: read them at the top level. |
| `E956` | Invalid `option_trades:` header (unknown key, value out of bounds, `sell_to` ≥ `buy_from`). |
| `E957` | Too many option events in one bar still forming (`max_bar_events`). |
| `E959` | Invalid argument to `option_trades.…`, such as an underlying not in the header. |
| `E966` | The memory limit for option trades in one script was reached: shorten `retention` or read fewer underlyings. |
| `E967` | Option handlers used more than `fuel_per_day`: lighter handler, `min_print_size`, or blocks instead of prints. |

### What is not available

- Trading options. Strategies are simulations on ES, MES, NQ and MNQ.
- An options order book or continuous option quotes: you get chain snapshots and prints.
- Options on futures, and underlyings other than SPX, NDX, SPY and QQQ.
- Whole-market totals today (`options.totals` answers `"not_provided"`).
- Options data for days before recording started, or days the app did not follow.
- Automated execution of strategies is not part of the current version.

## Get started

1. **Download Strate** and open a chart of ES, MES, NQ or MNQ.
2. **Connect your options data account** in Strate's connections. It is your own account, read only. Without it, the app can still show the delayed public source on its charts.
3. **Open StrateScript:** Indicators window, **Custom** category, **StrateScript (preview)**. Load an **Options** template from the script menu, or paste a script from this page.
4. **Or ask Strate AI**, in the panel's **Assistant** mode, to write or explain a script. It is optional: every script here works without it.
5. **Replay a recorded day** to see your script on past sessions, or run a long backtest from the strategy Report over a folder of local MBO replay files, one per day (see Live, Replay, long backtest and the check).

Want to see Strate first? Try the interactive demo.

Strate is an analysis tool, not investment advice. Simulated results do not predict real results.
