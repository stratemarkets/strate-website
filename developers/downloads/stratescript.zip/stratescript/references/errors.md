# Error codes

The editor shows `Line N · message` and often a fix line (`Did you mean "close"?`); the code and column show on hover
(`E930 · column 10`). The checker (`scripts/verify.py`) prints all of them. Some errors have a one-click **Fix** in the
editor: did-you-mean, `close[-1]` → `close[1]`, `if a = b` → `==`, a missing comma, a positional argument after a named
one.

- **E0xx, E1xx**: the script cannot be read (syntax).
- **E9xx**: found while running. The check runs the script on a synthetic market, so most are caught before the chart;
  an error in a branch that never runs there appears on the chart when that line first runs.

While an error remains, the script does not run and the chart keeps its last valid result.

## Lexical (E0xx)

| Code | Message | Cause → fix |
|---|---|---|
| E000 | Strate engine unreachable | Not a script error: nothing was checked. Run again / start the app. |
| E001 | unclosed /* comment | Close with `*/`. |
| E002 | unclosed string | Missing `"` or a line break inside; use `\n`. |
| E003 | invalid color | `#RRGGBB` or `#RRGGBBAA`. |
| E004 | unknown suffix attached to a number | `4ticks` → `4 ticks`. Only duration units are attached. |
| E005 | non-ASCII identifier | Rename with ASCII letters. |
| E006 | unexpected character | `$`, `…`, `→`, `'` and other characters the language does not use. |

## Syntax (E1xx)

| Code | Message | Cause → fix |
|---|---|---|
| E100 | expected "x" | Missing symbol; `if a = b` → `==`; also a `fn` declared inside a block (declare at top level). |
| E101 | expected a name | After `fn`, `type`, `as`… |
| E102 | expected a string | Header without name: `strategy "My strategy" { … }`. |
| E103 | expected end of statement | Two statements on one line; unknown word at line start (`study "X"`); `5 m` with a space; `x: int = 3` without `var`. |
| E104 | a single header, placed before the statements | Move it to the top / remove the second. |
| E105 | expected a setting "name: value" | In headers, objects, import overrides. |
| E106 | expected "," or ")" | Missing comma (`ema(close 20)`); a unit after a variable (`n ticks` → `price(n)`). |
| E107 | a type name starts with an uppercase letter | `type Zone`. |
| E108 | a pattern has exactly one "when" clause | Add it, or merge two with `and`. |
| E109 | "x" needs an initial value | `var x = 0`. |
| E110 | missing "}" | Close the block. |
| E111 | "x" is only allowed at the top level | `indicator`, `strategy`, `research`, `import`, `on`, `pattern`, `type`, `enum`, `method` inside a block or function. |
| E112 | cannot assign to this expression | Left side must be a variable, a field of your type, or a list/map element. |
| E113 | expected ":" in a ? b : c | Complete the conditional. |
| E114 | chained comparisons are not allowed | `a < b and b < c`. |
| E115 | positional argument after a named argument | Positional first. The one-click fix only moves the argument: check the units of the numbers around it (`stop: 4` stays 4 points). |
| E116 | expected an expression | Missing piece; reserved word as a name (`in = 3`); `.5` → `0.5`. |
| E117 | nested more than 200 levels deep | Split the expression or blocks. |
| E199 | unexpected declaration | Declaration where not allowed. |

## Run time (E9xx)

| Code | Message | Cause → fix |
|---|---|---|
| E901 | unknown event "x" | Use a listed event. Also: a date as a value, `a..b` outside `for`, `when(…)` outside a clock, `set<…>`/`heap<…>`/`deque<…>`/`series<…>`, pattern setting `expire:`. |
| E902 | script too slow: more than N operations | Budget exceeded: smaller loops, avoid scanning big collections on every event, or header `budget: 5000000` (max 20,000,000). Also an invalid `budget:`. |
| E903 | var/state/const/persist at top level only | Move the declaration out of the block or function. |
| E904 | invalid assignment or loop | `[…] =` on a non-collection; assigning a built-in object's field; `for i, x` on something without index; > 2 loop names. |
| E905 | "x" is not defined | `x += 1` on an undeclared name: `x = 0` first. |
| E906 | loop over 10,000 iterations | Reduce or restructure. |
| E907 | for … in expects a range, list, map or ring | |
| E908 | a X has no fields | Field read on a number, text, `na`… |
| E909 | "x" is a const | Use `var`. |
| E910 | "-" expects a number | |
| E911 | [-1] reads the future | `[1]`. Also `bar.footprint` inside a handler, pattern or clock. |
| E912 | history [n] applies to a variable or a built-in series | Assign the expression to a top-level variable first; not on function locals. |
| E913 | unsupported call form | Calling something that is not a function. |
| E914 | more than 64 nested calls | Recursion too deep (max 65 nested calls). |
| E915 | missing argument "p" | Pass it or give a default. |
| E916 | unknown type "T" | Declare `type T { … }` (also for `method T.x` without the type). |
| E917 | "self" only inside a method | |
| E920 | operator does not apply | Two texts (only `+`, comparisons), two durations (only `+ - /`, comparisons), two times (only `-`, comparisons), time and duration (only `+ -`). |
| E921 | cannot add a string and a X | `"n=" + str(n)`. |
| E922 | operator does not apply to X and Y | Duration vs number other than 0: write `5s`, or `d / 1s`. Also `"a" * 2`. |
| E923 | length must be a whole number ≥ 1 | Length < 1 or `na` in `sma`, `ema`, `highest`, `stats.*`… |
| E924 | f() needs at least one value | `max()`/`min()` without argument. |
| E925 | settings or time ranges | `input.*` without title; `input.choice` without list; invalid `input.session` default or `session.in` range (`"HHMM-HHMM"`); wrong-type `input.price`/`input.time` default. |
| E926 | fill() takes two plots, or a plot and a value | `p1 = plot(…)`; `fill(p1, p2, c)` or `fill(p1, 0, c)`. |
| E927 | marker or cell option | `shape:`, `location:`, `size:` outside lists; `location: "price"` without `price:`; `cell side:` not left/right/full. |
| E928 | colors, objects, tables | `alpha`/`mix` on a non-color; wrong time/price type in `line.new`/`box.new`/`label.new`; table position, size, cell, `align`. |
| E930 | "x" is not defined | Unknown name, typo, or a block-local read outside its block ("did you mean …"). |
| E931 | unknown function "f" | Check `builtins.md` / other references. |
| E932 | "x" is not a field of … (fields: …) | Unknown field; the message lists valid ones. `book.imbalance` without `()`. |
| E933 | unknown method, or invalid argument | Bad argument of `norm.*`, `of.*`, `mbo.*`, `book.depth`, `stats.percentile`, `fp.imbalances`; window longer than the history kept. Messages: `mbo.level: window 300s is longer than the level history kept (120s)` with fix `add level_history: 5m to the header, e.g. indicator "X" { level_history: 5m }`; `of.flow: window 600s is longer than the trade history kept (300s)` with fix `add flow_history: 10m …`; beyond 30m / 60m: `… longer than the longest level history (level_history: 30m at most)`. If the window is a setting, clamp it in code too (a user can move it past the header value). |
| E934 | patterns and signals | Missing/unknown `on:`; unknown pattern setting; duplicate pattern name; `from "X"` with no pattern X; bad `side:`/`cooldown:`/`confirm:`; `acc.add()` of a non-footprint. |
| E935 | clocks, rows() | Unknown clock kind, duplicate clock, `on clock x` without clock, non-positive threshold; `fp.rows(n)` with n < 1. |
| E936 | request(), col: | Wrong arguments, unknown or non-multiple timeframe, drawing or session levels inside `request`, no bars for the symbol (always in the check for `symbol:`); `cell(…, col:)` out of range. |
| E937 | imports, align: | Import not found, duplicate alias, nested import, override not declared by the import; `draw.text align:` not left/center/right. |
| E938 | research, indexes | `study`/`report`/`compare` outside research or with bad arguments; list index out of range or not a number. |
| E939 | strategies, map keys | Missing/invalid `costs:`, `fill_model:`, `latency:`; `enter`/`exit`/`cancel`/`position`/`on fill`/`on exit` outside a strategy; bad `enter` side/type, missing or `na` `price:`, non-positive distances, non-duration timeouts; map key not number/text/bool. |
| E940 | ring(n) / window(d) bounds | n 1–1,000,000; d > 0. |
| E941 | collection larger than 1,000,000 elements | |
| E942 | invalid header value | `min`/`max`, `format`, `precision`, `labels`, `visible_on`, `initial_balance`, `level_history`, `flow_history`, `mbo_from`, `book_from`, `mbo_max`. Message says what is expected. |
| E943 | persist | Outside a named indicator, or holding a drawing/function/table/footprint/book. Use `var` or keep data only. |
| E944 | the bar holds more than N MBO events | Shorter timeframe or raise `mbo_max:`. |
| E945 | N bars sent, at most 50000 | Shorter history or higher timeframe. |
| E948 | overlay / pane | See `plotting.md` › Where things are drawn. |
| E950 | script longer than 200,000 characters | |
| E960 | (long backtest) a day could not be read | Too many bars/MBO events: larger timeframe or narrower hours window. |
| E961 | (long backtest) YYYY-MM-DD: line N: message | Script failed that day; message = underlying error. |
| E999 | internal error | Engine did not answer in time, or data arrived late twice: try again. |

## Failing examples (each fails with the code above it)

<!-- expect: E930 -->
```strate
indicator "My average" { overlay: true }
length = input.int("Length", 20)
plot(sma(close, lenght))
```

<!-- expect: E930 -->
```strate
if close > open { up = close }
plot(up)
```

<!-- expect: E911 -->
```strate
plot(close[-1])
```

<!-- expect: E912 -->
```strate
plot((close + 1)[1])
```

<!-- expect: E921 -->
```strate
print("close = " + close)
```

<!-- expect: E922 -->
```strate
d = bar.close_time - bar.time
if d > 60 { print("long bar") }
```

<!-- expect: E905 -->
```strate
total += volume
```

<!-- expect: E004 -->
```strate
plot(close + 4ticks)
```

<!-- expect: E106 -->
```strate
n = input.int("Offset", 4)
plot(close + n ticks)
```

<!-- expect: E114 -->
```strate
plot(low < close < high ? 1 : 0)
```

<!-- expect: E939 -->
```strate
strategy "No costs" { overlay: true }
if close > open { enter("buy", stop: 8 ticks) }
```

<!-- expect: E938 -->
```strate
indicator "Not research"
pattern "Up" {
  on: bar
  side: "buy"
  when close > open
}
on signal(s) { study(s) }
```

<!-- expect: E933 -->
```strate
indicator "Window too long" { overlay: false }
lv = mbo.level(close, window: 3m)
plot(nz(lv.added))
```

<!-- expect: E911 -->
```strate
indicator "Footprint in a handler"
on trade(t) { fp = bar.footprint }
```

<!-- expect: E948 -->
```strate
indicator "Price script" { overlay: true }
plot(volume, overlay: false)
```

<!-- expect: E943 -->
```strate
strategy "No persist" { overlay: true, costs: { commission: 2.5 usd, slippage: 1 tick } }
persist n = 0
```

<!-- expect: E934 -->
```strate
indicator "Typo in pattern"
pattern "P" {
  on: bar
  group: "x"
  when close > open
}
```

<!-- expect: E937 -->
```strate
indicator "Bad import"
import "strate/patterns/absorption_held_volume" as a { minVolume: 90 }
```
