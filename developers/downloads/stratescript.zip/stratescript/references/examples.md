# Complete examples

Sixteen complete scripts, all passing the check as written, from simple to advanced. Copy one as a
starting point. Examples 8–11, 15 and 16 need order-by-order (MBO) data (Replay of a recorded session, live with Strate's
MBO recording, or a long backtest); example 12 needs book data. Each is one possible definition, with every threshold
exposed as a setting.

Contents: 1. Moving-average ribbon · 2. Session VWAP with bands · 3. Cumulative delta as candles · 4. Session volume profile · 5. Stacked footprint imbalances · 6. Opening range · 7. Unusual prints · 8. Sweeps · 9. Absorption pattern · 10. Same-order refills, order by order · 11. Pulled before touch · 12. Book pressure and microprice · 13. Volume imbalance bars · 14. Strategy: fade a delta divergence · 15. Strategy: join a defended level · 16. Research: what follows a sweep?

## 1. Moving-average ribbon

Shows: settings, plots, fill, markers.

```strate
indicator "EMA ribbon" { overlay: true }

fastLen = input.int("Fast length", 9, min: 1, group: "Lengths")
slowLen = input.int("Slow length", 21, min: 2, group: "Lengths")
upCol = input.color("Up", #26a69a, group: "Colors", inline: "c")
dnCol = input.color("Down", #ef5350, group: "Colors", inline: "c")

fast = ema(close, fastLen)
slow = ema(close, slowLen)
up = fast > slow

pf = plot(fast, up ? upCol : dnCol, title: "Fast", width: 2)
ps = plot(slow, #888888, title: "Slow")
fill(pf, ps, up ? alpha(upCol, 20) : alpha(dnCol, 20))

// only on closed bars, so the marks do not flicker on the live bar
marker(crossover(fast, slow) and bar.confirmed, shape: "triangle_up", location: "below", color: upCol)
marker(crossunder(fast, slow) and bar.confirmed, shape: "triangle_down", location: "above", color: dnCol)
```

- the plot color changes on every bar (`up ? upCol : dnCol`);
- `alpha(color, 20)` makes a 20% opaque version of a color for the fill;
- `bar.confirmed` keeps the markers stable while the last bar forms.

## 2. Session VWAP with bands

Shows: `var` totals, a reset the user chooses (CME session at 18:00 or RTH at 9:30), an approximation stated.

```strate
indicator "Session VWAP" { overlay: true }

anchor = input.choice("Anchor", ["CME session (18:00)", "RTH (9:30)"], "CME session (18:00)")
mult = input.float("Band width (std devs)", 1.0, min: 0.5, step: 0.5)

var pv = 0.0      // sum of price × volume
var pv2 = 0.0     // sum of price² × volume
var vol = 0.0     // sum of volume

rthOnly = anchor == "RTH (9:30)"
startOfRth = session.rth and not session.rth[1]
if (rthOnly and startOfRth) or (not rthOnly and session.is_new) {
  pv = 0.0
  pv2 = 0.0
  vol = 0.0
}

active = not rthOnly or session.rth
if active {
  // typical price of the bar: an approximation of the prices actually traded
  tp = (high + low + close) / 3
  pv += tp * volume
  pv2 += tp * tp * volume
  vol += volume
}

vwap = active and vol > 0 ? pv / vol : na
sd = active and vol > 0 ? sqrt(max(pv2 / vol - vwap * vwap, 0)) : na

pv_ = plot(vwap, #e8c15a, title: "VWAP", width: 2)
pu = plot(vwap + mult * sd, #e8c15a80, title: "Upper band")
pl = plot(vwap - mult * sd, #e8c15a80, title: "Lower band")
fill(pu, pl, #e8c15a10)
```

- `var` variables keep their value from one bar to the next; plain variables (`tp`, `vwap`) are recomputed on each bar;
- `session.is_new` is true on the first bar of each CME session (18:00 New York); `startOfRth` on the first bar opening
  in RTH. Until the first reset, the sums start at the first bar received (a partial session);
- with the RTH anchor nothing is drawn outside 9:30–16:00;
- the bar's typical price approximates the traded prices; for traded prices, add `lv.price * lv.volume` over
  `bar.footprint.levels` when `bar.footprint.available` (and say what is used when it is not);
- `max(…, 0)` protects the square root from tiny negative values caused by rounding.

## 3. Cumulative delta as candles

Shows: `of.cvd`, `candle`, intrabar delta.

```strate
indicator "CVD candles" { overlay: false, format: "compact", labels: true }

reset = input.choice("Reset", ["session", "rth", "day", "none"], "session")

cvd = of.cvd(reset: reset)
prevCvd = cvd - nz(delta)
hi = na(bar.delta_high) ? max(prevCvd, cvd) : prevCvd + bar.delta_high
lo = na(bar.delta_low) ? min(prevCvd, cvd) : prevCvd + bar.delta_low

candle(prevCvd, hi, lo, cvd, cvd >= prevCvd ? #26a69a : #ef5350)
hline(0, color: #888888, style: "dotted")
```

- `of.cvd(reset:)` resets at the chosen boundary; `prevCvd` is the value before this bar's delta;
- `bar.delta_high` / `bar.delta_low` are the running-delta extremes inside the bar, or `na` when the source does not
  provide them, hence the fallback.

## 4. Session volume profile

Shows: footprint accumulator, `hbar`.

```strate
indicator "Session profile" { overlay: true }

widthBars = input.int("Width (bars)", 30, min: 5)
vaPct = input.float("Value area (%)", 70, min: 10, max: 100)
col = input.color("Color", #2962ff60)

var prof = footprint.accumulator()
if session.is_new { prof.reset() }
prof.add(bar.footprint)

if bar.last and prof.available {
  biggest = 0
  for lv in prof.levels { biggest = max(biggest, lv.volume) }
  for lv in prof.levels {
    hbar(lv.price, lv.volume, biggest, side: left, width: widthBars, color: col)
  }
}

va = prof.value_area(vaPct)
plot(prof.poc, #e8c15a, title: "POC", style: "step")
plot(na(va) ? na : va.high, #2962ff, title: "VA high", style: "dotted")
plot(na(va) ? na : va.low, #2962ff, title: "VA low", style: "dotted")
```

- `footprint.accumulator()` sums footprints; it has the same fields and methods as one footprint (`levels`, `poc`,
  `value_area`…);
- `hbar(price, value, max, width:)` draws a bar whose length is `value / max` of `width` bars;
- footprints are only loaded because the script contains the word `footprint`.

## 5. Stacked footprint imbalances

Shows: `fp.imbalances`, `fp.stacked`, cells and boxes.

```strate
indicator "Stacked imbalances" { overlay: true }

ratio = input.float("Ratio (3 = 300 %)", 3, min: 1.5, step: 0.5)
minVol = input.int("Min volume on the strong side", 10, min: 1)
stack = input.int("Min stacked rows", 3, min: 2)

fp = bar.footprint
for p in fp.imbalances("buy", ratio: ratio, min_volume: minVol) {
  cell(p, "", side: right, bg: #26a69a60)
}
for p in fp.imbalances("sell", ratio: ratio, min_volume: minVol) {
  cell(p, "", side: left, bg: #ef535060)
}
for z in fp.stacked("buy", ratio: ratio, count: stack, min_volume: minVol) {
  box.new(bar.time, z[1], bar.time + 30m, z[0], color: #26a69a20, border: #26a69a, fade: "right")
}
for z in fp.stacked("sell", ratio: ratio, count: stack, min_volume: minVol) {
  box.new(bar.time, z[1], bar.time + 30m, z[0], color: #ef535020, border: #ef5350, fade: "right")
}
```

- a buy imbalance at a price compares the buy volume there with the sell volume one row lower (the diagonal); a sell
  imbalance compares the sell volume with the buy volume one row higher;
- an empty diagonal row counts as 0, so `min_volume` keeps one-lot rows at the bar's edge from counting;
- `fp.stacked` returns `[low, high]` row prices; the boxes extend 30 minutes to the right and fade out.

## 6. Opening range

Shows: session hours, an updated box, alerts.

```strate
indicator "Opening range" { overlay: true }

minutes = input.int("Minutes", 15, min: 1, max: 120)

state hi = na
state lo = na
state zone = na

startOfRth = session.rth and not session.rth[1]
minsSinceOpen = bar.hour * 60 + bar.minute - 570   // 570 = 9:30 in minutes
inRange = session.rth and minsSinceOpen < minutes

if startOfRth {
  hi = high
  lo = low
  zone = box.new(bar.time, high, bar.time, low, color: #e8c15a15, border: #e8c15a)
} else if inRange and not na(hi) {
  hi = max(hi, high)
  lo = min(lo, low)
}

if not na(zone) and session.rth {
  zone.set_top(hi)
  zone.set_bottom(lo)
  zone.set_right(bar.time)
}

breakUp = session.rth and not inRange and close > hi and close[1] <= hi
breakDn = session.rth and not inRange and close < lo and close[1] >= lo
alert((breakUp or breakDn) and bar.confirmed, "Close outside the opening range")
marker(breakUp, shape: "arrow_up", location: "below", color: #26a69a)
marker(breakDn, shape: "arrow_down", location: "above", color: #ef5350)
```

- `session.rth and not session.rth[1]` detects the first RTH bar on any time unit;
- `minsSinceOpen` is the number of minutes since 9:30 New York, so `inRange` holds for the first `minutes` minutes;
- the box is created once and then updated with `set_top`, `set_bottom`, `set_right`.

## 7. Unusual prints

Shows: `on trade`, `norm.rank`, statistics row.

```strate
indicator "Unusual prints" { overlay: true }

minRank = input.float("Min size rank", 99.5, min: 50, max: 100, step: 0.1)
normWin = input.duration("Compare with the last", 30m)

state signed = 0
on trade(t) {
  // computed for every trade, so the population is all trades
  rk = norm.rank(t.size, normWin, min_count: 500)
  if rk >= minRank {
    label.new(t.time, t.price, str(t.size), color: t.is_buy ? #26a69a : #ef5350, pulse: 3s)
    signed += t.delta
  }
}

stat("Unusual", signed, format: "+0", color: signed >= 0 ? #26a69a : #ef5350)
signed = 0
```

- the threshold is a rank, not a size: the same setting works on any instrument and at any hour;
- `signed` is a `state` variable filled by the handler, read and reset by the body at the end of each bar.

## 8. Sweeps

Shows: order-by-order trade fields. Needs MBO data.

```strate
indicator "Sweeps" { overlay: true }

minLevels = input.int("Min prices traded", 3, min: 2)
minSize = input.int("Min total size", 20, min: 1)

on trade(t) {
  if not na(t.levels) and t.sweep_end and t.levels >= minLevels and t.sweep >= minSize {
    label.new(t.time, t.price, (t.is_buy ? "▲ " : "▼ ") + str(t.sweep) + " × " + str(t.levels),
              color: t.is_buy ? #26a69a : #ef5350, glow: 8)
  }
}
```

- `na(t.levels)` is true without order-by-order data (and before the order-by-order window starts): the test makes the
  script silent there instead of wrong;
- `t.levels` counts the distinct prices traded by the aggressive order; `t.sweep` is its total size.

## 9. Absorption pattern

Shows: `pattern`, `mbo.level`, explanations. Needs MBO data.

```strate
indicator "Absorption — my definition" { overlay: true, level_history: 2m }

win = input.duration("Window", 30s)
minRank = input.float("Min aggressor volume rank", 97, min: 0, max: 100, group: "Thresholds")
normWin = input.duration("Normalize over", 30m, group: "Thresholds")
heldPct = input.float("Held at best (% of window)", 60, min: 0, max: 100, group: "Thresholds")
maxMove = input.int("Max price move (ticks)", 2, min: 0, group: "Thresholds")

pattern "Absorption" {
  on: trade
  // buyers lifting an offer that holds = sellers absorbing: a "sell" signal
  side: trade.is_buy ? "sell" : "buy"
  cooldown: win
  show: [lv.aggressor_volume, lv.added, lv.displayed]
  lv = mbo.level(trade.price, window: win)
  // normalized at every trade, before the other conditions
  rk = norm.rank(na(lv) ? na : lv.aggressor_volume, normWin, min_count: 200)
  moved = abs(trade.price - open) / instrument.tick
  when not na(lv)
   and rk >= minRank
   and lv.time_at_best >= win * heldPct / 100
   and lv.displayed > 0
   and moved <= maxMove
}

on signal(s from "Absorption") {
  label.new(s.time, s.price, s.side == "sell" ? "offer holds" : "bid holds", color: s.side == "sell" ? #ef5350 : #26a69a)
}
```

- the event variable of `on: trade` is `trade`;
- `norm.rank` is computed before `when`, at every trade; a `na` value is not added to the population;
- the explanation attached to each signal lists every `and` term with its values, then the `show:` values;
- `level_history: 2m` keeps enough per-price history for windows up to 2 minutes.

## 10. Same-order refills, order by order

Shows: `on order`, maps keyed by price and id. Needs MBO data.

```strate
indicator "Refills, raw" { overlay: true }

within = input.duration("Refill within", 2s)
minRefills = input.int("Refills to mark", 3, min: 1)

state emptiedAt = map()    // price -> time its displayed size reached 0
state seen = map()         // order id -> price where it was seen
state gone = ring(100000)  // ids of the last 100,000 orders that left the book
state refills = map()      // price -> refills since the session start

on order(o) {
  if o.is_add or o.is_modify {
    known = seen.get(o.id, na) == o.price
    t0 = emptiedAt.get(o.price, na)
    grew = o.is_add or o.size > nz(o.previous_size)
    if grew and not na(t0) and o.time - t0 <= within {
      refills.add(o.price)
      emptiedAt.remove(o.price)
      if refills[o.price] == minRefills {
        label.new(o.time, o.price, str(minRefills) + " refills" + (known ? " (same order)" : " (new order)"), color: o.side == "ask" ? #ef5350 : #26a69a)
      }
    }
    seen[o.id] = o.price
  }
  if (o.is_fill or o.is_cancel) and mbo.size(o.price) == 0 {
    emptiedAt[o.price] = o.time
  }
  // forget an order 100,000 departures after it left the book (keeps `seen` small on a full day)
  if (o.is_fill or o.is_cancel) and na(mbo.order(o.id)) {
    if gone.full {
      oldest = gone.first()
      if na(mbo.order(oldest)) { seen.remove(oldest) }
    }
    gone.push(o.id)
  }
}

if session.is_new {
  refills.clear()
  seen.clear()
  gone.clear()
}
```

- when `on order` runs, `mbo` already includes the event, so `mbo.size(o.price) == 0` means "this event emptied the
  price";
- `o.previous_size` is the size before a modify; `nz()` covers adds, where it is `na`;
- maps keyed by price or by order id are ordinary `state` variables, cleared at each session;
- a map keyed by order id must also forget orders, or it grows with every order of the day: a list or map holds at most
  1,000,000 elements (E941). Here a `ring` remembers the last 100,000 orders that left the book; when it is full, the
  oldest one (`gone.first()`, read before the `push` drops it) is removed from `seen`. A ring's `push` and `first()` cost
  the same whatever its size, unlike `shift()` on a list, which costs about `1 + n/8` operations of the budget;
- `mbo.order(id)` is `na` once the order is gone, so `na(mbo.order(o.id))` after a fill or a cancel means "nothing of
  this order is left";
- `mbo.level(…).refill_same_id` and `refill_new_id` give a ready-made count of the same thing over a window.

## 11. Pulled before touch

Shows: cancels, order age, own memory of fills. Needs MBO data.

```strate
indicator "Pulled before touch" { overlay: true }

minSize = input.int("Min size", 100, min: 1)
minAge = input.duration("Min age", 2s)
maxTicks = input.int("Price within (ticks)", 4, min: 1)
wholeOnly = input.bool("Whole order canceled only", true)

state filledIds = map()    // ids of orders that traded at least once

on order(o) {
  if o.is_fill { filledIds[o.id] = true }
  gone = na(mbo.order(o.id))    // nothing of the order is left in the book
  if o.is_cancel and (gone or not wholeOnly) and o.previous_size >= minSize and o.age >= minAge and not filledIds.has(o.id) {
    // distance between the canceled order and the opposite best price (where trades happen)
    best = o.side == "bid" ? mbo.best_ask : mbo.best_bid
    if not na(best) {
      dist = abs(best - o.price) / instrument.tick
      if dist <= maxTicks and dist >= 1 {
        label.new(o.time, o.price, "pulled " + str(o.size) + "/" + str(o.previous_size) + " at " + str(dist) + "t", color: #ffb300)
      }
    }
  }
  // forget an order only once nothing of it is left in the book
  if (o.is_cancel or o.is_fill) and gone { filledIds.remove(o.id) }
}
```

- by default only a cancel that removes the whole order counts (`mbo.order(o.id)` is `na` after it): cutting 1 lot off
  a 150-lot order is not "pulling 150". The label shows size canceled / size before;
- `o.previous_size` is the order's size before the cancel, `o.age` its age since it was added;
- the script keeps its own memory of filled ids; without it, an order partly filled and then canceled would look like a
  spoof. An id is removed only when the order has fully left the book (`mbo.order(o.id)` is `na`): when `on order` runs,
  the book already includes the event, so a partial fill or a partial cancel leaves the order, and its memory, in place;
- the shipped definition `strate/patterns/spoofing_pulled_before_touch` is another, more complete take on the same idea.

## 12. Book pressure and microprice

Shows: `book`, a time clock. Needs book snapshots data.

```strate
indicator "Book pressure" { overlay: false, min: -1, max: 1, precision: 2 }

levels = input.int("Levels", 5, min: 1, max: 300)

clock sec = clock.time(1s)
state imbSum = 0
state microSum = 0
state n = 0

on clock sec {
  if book.available and book.spread > 0 {
    imbSum += book.imbalance(levels)
    microSum += (book.microprice - book.mid) / book.spread
    n += 1
  }
}

plot(n > 0 ? imbSum / n : na, #2962ff, title: "Depth imbalance", width: 2)
plot(n > 0 ? microSum / n : na, #e8c15a, title: "Microprice − mid (in spreads)")
hline(0, color: #888888)

imbSum = 0
microSum = 0
n = 0
```

- `book` is the latest snapshot and can be read in a clock handler;
- the clock samples at a fixed rhythm, so a burst of snapshots does not weigh more than a quiet period;
- the pane is bounded with `min: -1, max: 1`.

## 13. Volume imbalance bars

Shows: a `when` clock, shared state.

```strate
indicator "Imbalance bars" { overlay: true }

initial = input.float("Initial threshold", 200, min: 1)
alphaW = input.float("Adaptation weight", 0.1, min: 0.01, max: 1, step: 0.01)

state theta = 0
state expected = na
state started = na

on trade(t) {
  if na(started) { started = t.time }
  theta += t.delta
}

clock vib = when(abs(theta) >= nz(expected, initial))

on clock vib {
  label.new(event.time, close, str(theta, "+0") + " in " + str((event.time - started) / 1s, "0.0") + "s", color: theta > 0 ? #26a69a : #ef5350)
  expected = na(expected) ? abs(theta) : alphaW * abs(theta) + (1 - alphaW) * expected
  theta = 0
  started = na
}
```

- `when(condition)` fires on the rising edge of the condition, evaluated after every event;
- `theta`, `expected` and `started` are `state` variables shared by the trade handler and the clock;
- `event.time` inside the clock handler is the time of the trade that closed the bar.

## 14. Strategy: fade a delta divergence

Shows: `enter`, units, the Report.

```strate
strategy "Delta divergence fade" { overlay: true, costs: { commission: 2.5 usd, slippage: 1 tick }, fill_model: through, latency: 60ms }

len = input.int("Lookback (bars)", 20, min: 5)
minRank = input.float("Min |delta| rank", 80, min: 50, max: 100)
stopTicks = input.int("Stop (ticks)", 10, min: 2)
targetTicks = input.int("Target (ticks)", 15, min: 2)
hours = input.session("Entry hours (New York)", "0930-1600")

hh = highest(high, len)
ll = lowest(low, len)
dRank = stats.rank(abs(nz(delta)), 50)

newHigh = high >= hh and delta < 0 and dRank >= minRank
newLow = low <= ll and delta > 0 and dRank >= minRank

if position.flat and position.pending == 0 and bar.confirmed and session.in(hours, bar.close_time) {
  if newHigh {
    enter("sell", stop: price(stopTicks), target: price(targetTicks), timeout: 30m, tag: "fade high")
  } else if newLow {
    enter("buy", stop: price(stopTicks), target: price(targetTicks), timeout: 30m, tag: "fade low")
  }
}

on exit(x) {
  label.new(x.time, x.price, x.reason + " " + str(x.r, "+0.00") + "R", color: x.usd > 0 ? #22c55e : #ef4444)
}

marker(newHigh, shape: "diamond", location: "above", color: #ef5350, size: "small")
marker(newLow, shape: "diamond", location: "below", color: #26a69a, size: "small")
```

- `price(n)` converts a number of ticks held in a setting into a price distance (`n ticks` only works with a literal);
- a decision in the body is made at the bar's close and can fill after the 60 ms latency, so the hours are tested on
  `bar.close_time` (`session.rth` would test the bar's open);
- the four settings are sweepable from the Report; look for a plateau, not the best point.

## 15. Strategy: join a defended level

Shows: `on match`, `fill_model: queue`, fixed MBO start. Needs MBO data.

```strate
strategy "Join the defended bid" { overlay: true, mbo_from: rth, level_history: 2m, fill_model: queue, latency: 60ms, costs: { commission: 2.5 usd, slippage: 1 tick } }

win = input.duration("Window", 20s)
minRefills = input.int("Min refills", 3, min: 1)
stopTicks = input.int("Stop (ticks)", 6, min: 1)
targetTicks = input.int("Target (ticks)", 6, min: 1)

on match(m) {
  if position.flat and position.pending == 0 and mbo.available and m.side == "sell" and m.price == mbo.best_bid {
    lv = mbo.level(m.price, window: win)
    if lv.replenishments >= minRefills and lv.displayed > 0 {
      enter("buy", type: "limit", price: m.price, stop: price(stopTicks), target: price(targetTicks), expire: 30s, tag: "defended bid")
    }
  }
}

on fill(f) {
  label.new(f.time, f.price, "in " + str(f.size), color: #2962ff)
}
on exit(x) {
  label.new(x.time, x.price, x.reason + " " + str(x.ticks, "+0.0") + "t", color: x.usd > 0 ? #22c55e : #ef4444)
}
```

- `mbo_from: rth` starts the order-by-order data at the latest 9:30 New York before launch, a fixed start;
- the decision is made at the time of the execution (`on match`), not at the bar's close;
- in a long backtest over many days, this script runs on each day's MBO replay file with the same rules.

## 16. Research: what follows a sweep?

Shows: `study` on raw events, `compare`. Needs MBO data.

```strate
research "After a sweep" { overlay: true }

type Event { time: time, side: string, name: string, price: float }

minLevels = input.int("Min prices traded", 2, min: 2)

on trade(t) {
  if not na(t.levels) and t.sweep_end and t.levels >= minLevels {
    group = t.levels >= 4 ? "Sweep 4+ prices" : "Sweep 2-3 prices"
    study(Event { time: t.time, side: t.is_buy ? "buy" : "sell", name: group, price: t.price },
          horizons: [30s, 2m, 5m], target: 6 ticks, stop: 6 ticks, cost: 1 tick)
  }
}

compare(by: ["side", "rth"], ci: 1000)
```

- any object with `time`, `side`, `name` and `price` can be studied; no pattern is needed;
- each group keeps a single target/stop geometry, so its break-even win rate is meaningful;
- `compare` puts the two sweep groups side by side, split by side and by RTH / ETH.
