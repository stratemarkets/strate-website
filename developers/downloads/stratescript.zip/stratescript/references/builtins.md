# Built-in data and functions

Contents: Bars and time · Chart and instrument · Sessions · `request` · Moving averages · `stats.*` · `norm.*` · Math ·
Text · Colors · Settings `input.*` · Footprint

Order flow (`on trade`, `mbo`, `book`, `of`) is in `order-flow.md`; drawing in `plotting.md`; `enter`/`position` in
`strategies.md`; `study` in `research.md`. Times are New York time. The CME session runs 18:00 → 17:00 next day; RTH is
9:30–16:00.

## Bars and time

| Name | → | Meaning |
|---|---|---|
| `open`, `high`, `low`, `close`, `volume` (= `bar.open` …) | number | Bar values. In handlers: the bar **so far**; before its first trade they hold the previous close (`na` on the very first bar), `volume` 0. |
| `delta` (= `bar.delta`) | number / `na` | Buy − sell volume by aggressor; `na` when the source has no aggressor side. |
| `bar.buy_volume`, `bar.sell_volume` | number | `(volume ± delta) / 2`. |
| `bar.delta_high`, `bar.delta_low` | number / `na` | Running-delta extremes inside the bar; always `na` in handlers. |
| `bar.time` / `bar.close_time` | time | Open / known close (time bars: open + unit; other types: next bar's open). |
| `bar.index` | number | 0 = first bar received. |
| `bar.last`, `bar.confirmed`, `bar.gap` | bool | Last bar; bar closed; real data gap before it. |
| `bar.hour`, `bar.minute`, `bar.dayofweek` | number | New York time of the open; 1 = Monday … 7 = Sunday. |
| `bar.footprint` | footprint | See Footprint. E911 inside handlers, patterns, clocks. |
| `event.time` | time | Event being processed (bar open in the body). |
| `now()` | time | Event time in a handler; close of a closed bar; latest data time on the forming bar. |

All bar series accept history (`close[1]`, `bar.time[1]`).

**Bars received**: an indicator gets the chart's last 2,000 bars (so does a strategy/research script reading the
footprint). Other strategy/research scripts: window fixed at launch (all bars if ≤ 8,000, else the last 4,000–8,000),
growing to 48,000, then its start moves by 8,000. Never more than 50,000 (E945).

```strate
indicator "Bar fields" { overlay: false }
plot(delta, title: "Delta")
plot(bar.buy_volume - bar.sell_volume, title: "Check")
plot(nz(bar.delta_high), title: "Delta high")
print(bar.index, str(bar.time, "HH:mm"), str(bar.close_time, "HH:mm"), bar.confirmed, bar.last, bar.gap, bar.hour, bar.minute, bar.dayofweek)
```

## Chart and instrument

| Name | Meaning |
|---|---|
| `chart.timeframe` | `"5s"`, `"1m"`, `"1h"`, `"1d"`, `"1w"`, `"8r"` (range), `"4k"` (renko), `"500v"`, `"300delta"`, `"100t"`, `"3x"` (reversal), or `na`. Inside `request(tf, …)` it is `tf`. |
| `chart.timeframe_seconds` | Seconds per time bar; 0 for other types. |
| `chart.bar_type` | `"time" "range" "renko" "volume" "delta" "tick" "reversal"`. |
| `chart.tick_px`, `chart.bar_px` | Pixels per tick / per bar (steps of 5 px). |
| `chart.row_ticks(min_px = 14)` | Round ticks per row (1, 2, 4, 5, 8, 10, 16, 20, 25…) so a row is ≥ `min_px` high; 1 if unknown. |
| `chart.columns(min_px = 30)` | Columns of ≥ `min_px` that fit in a bar (≥ 1). |
| `instrument.tick`, `instrument.symbol`, `instrument.point_value` | e.g. 0.25 / `"ES"` / 50. |

## Sessions

| Name | Meaning |
|---|---|
| `session.is_new` | First bar of a CME session (also the first bar received). |
| `session.is_new_day` | First bar of a new New York date. |
| `session.is_last_bar` | Last bar of a CME session among bars received (also the last bar received). |
| `session.rth` | Bar opens within 9:30–16:00. |
| `session.day` | CME trading date (days since 1970-01-01). |
| `session.high`, `session.low` | Since 18:00. |
| `session.overnight_high`, `session.overnight_low` | Running high/low of 18:00–9:30 (it moves during the night), frozen from 9:30 to the session end (17:00); `na` from 18:00 until the new session's first minute. Sunday 18:00 opens Monday's session. |
| `session.rth_high`, `session.rth_low` | Since 9:30. |
| `session.ib_high`, `session.ib_low` | From 9:30 for `initial_balance:` (default `60m`). |
| `prev.high`, `prev.low`, `prev.close` | Last complete **RTH** session (9:30–16:00) of an earlier CME session, at most 7 days back; `na` if it was shortened or has a gap, or if it is not in the data. |
| `session.in(range, time = bar open)` | Bool. Range `"HHMM-HHMM[,…][:days]"`, New York time, start included, end excluded; `"0930-1100:12345"` = Mon–Fri; may cross midnight (belongs to the start day); `"0000-0000"` = whole day. Invalid → E925. |
| `on session(s)` | Handler: `s.kind` = `"session_open"` (18:00), `"rth_open"`, `"rth_close"`, `"session_close"` (17:00); `s.time`, `s.rth`, `s.day`. |

Session levels are built from the instrument's one-minute bars whatever the chart unit (live: about the last 8 days;
Replay: the replayed session's own minutes), never use data after the current bar's close (or after the event), are
`na` when the period's start is missing, and are not allowed inside `request` (E936). No settlement price. A minute or
bar counts in a part of the session only if it lies entirely inside it (a 9:00–10:00 bar is in neither the night nor
RTH). To show the night levels only once they are final: `session.in("0930-1700") ? session.overnight_high : na`.

- **In handlers and patterns** `session.rth`, `session.is_new`, `session.day`, `bar.hour`, `bar.minute` and
  `session.in(range)` describe the **bar in progress** (its open time), not the event. For the event's own time:
  `session.in(range, event.time)` (or `t.time`, `o.time`). In the body, a decision is made at the bar's close: test
  `session.in(range, bar.close_time)` to filter entries by the time they are actually decided.
- **First RTH bar**: there is no variable; use `startOfRth = session.rth and not session.rth[1]` (any time unit) or
  `on session(s)` with `s.kind == "rth_open"`. On range/renko/volume bars the first RTH bar may open after 9:30.
- **Resets** (`session.is_new`, `of.cvd(reset:)`, your own `var` resets) happen on the first bar whose **open** is in
  the new period; a bar straddling the boundary belongs to the period of its open.
- **Previous full CME session (24 h)**: there is no built-in (`prev.*` is RTH only). `request("1d", high)` aggregates
  the **chart's own bars** received (2,000 for an indicator): the earliest day in them may be partial, and it is `na`
  until one day has closed in them. A version that trusts only sessions seen from their first bar:

```strate
indicator "Previous session high" { overlay: true }
// High of the previous complete CME session (18:00 to 17:00), from the chart's bars; na until one was seen whole
var curHi = na
var prevHi = na
var complete = false
if session.is_new {
  prevHi = complete ? curHi : na
  curHi = high
  complete = bar.index > 0
} else {
  curHi = na(curHi) ? high : max(curHi, high)
}
plot(prevHi, #e8c15a, title: "Previous session high", style: "step")
```

On a one-minute chart 2,000 bars cover about 33 hours: use a larger unit (5m) or `prev.*` when the user wants the
previous day on a fast chart, and say so.

**No VWAP built-in**: compute it with `var` sums (`examples.md` #2, anchored at 18:00 or 9:30).

```strate
indicator "Session levels" { overlay: true, initial_balance: 30m }
plot(session.overnight_high, #8888ff, title: "ON high")
plot(session.overnight_low, #8888ff, title: "ON low")
plot(session.ib_high, #e8c15a, title: "IB high")
plot(session.ib_low, #e8c15a, title: "IB low")
plot(prev.close, #ffffff80, title: "Prev close", style: "dashed")
bg_color(session.in("0930-1030") ? #ffffff08 : na)
```

```strate
indicator "Session events" { overlay: true }
on session(s) { label.new(s.time, close, s.kind) }
plot(close, title: "Close")
```

## Other timeframes and instruments: `request`

```
request(tf, expr)                 // expr on bars of timeframe tf
request(expr, symbol: "NQ")       // expr on another instrument's one-minute bars
request(tf, expr, symbol: "NQ")   // both
```

- Returns the value from the **last closed** bar of that series at or before the current bar's close; `na` until one
  has closed. Never looks ahead.
- Without `symbol:`, the higher-timeframe bars are built from the **chart's own bars received** (2,000 for an
  indicator): `request("1d", …)` on a 1-minute chart has at most one or two days, the first possibly partial.
- `tf`: text (`"5m"`, `"15m"`, `"1h"`, `"4h"`, `"1d"`) or duration (`15m`); ≥ the chart unit and a whole multiple of it
  (E936). `"1d"` groups by CME session.
- `symbol:` must be a literal text (a variable or setting finds no bars); up to 8 symbols. Live: Strate's recorded
  one-minute bars (none → E936 "no bars for NQ here"). Replay: that symbol's minutes up to the cursor, else `na`.
- `expr` has its own memory (`request("5m", ema(close, 20))` is a real 5-minute EMA); it cannot draw nor read session
  levels (E936).
- **The built-in check has no other instrument**: any `symbol:` request fails the check with E936 even when correct.

```strate
indicator "Higher timeframes" { overlay: true }
plot(request("5m", ema(close, 20)), #e8c15a, title: "5m EMA 20")
plot(request(15m, close), #2962ff, title: "15m close", style: "step")
plot(request("1d", high), #ffffff60, title: "Day high")
```

## Moving averages and windows

Length `len` ≥ 1 (rounded; below 1 or `na` → E923). `na` until enough values. Separate state per call place.

| Function | Notes |
|---|---|
| `sma(src, len)`, `ema(src, len)`, `rma(src, len)`, `wma(src, len)` | `ema`/`rma` start from the simple average; restart after a gap; `na` source values skipped. |
| `highest(src, n)`, `lowest(src, n)` | Over the last `n` values. |
| `change(src, n = 1)` | `src − src[n]` over values seen. |
| `cum(src)` | Running sum since the first bar (`na` counts 0). |
| `crossover(a, b)`, `crossunder(a, b)` | True on the bar `a` crosses above/below `b`; false with `na`. |

## Statistics `stats.*` (per bar, over the last `n` values; `n` ≥ 1, E923 otherwise)

| Function | Notes |
|---|---|
| `stats.mean(src, n)`, `stats.median(src, n)` | |
| `stats.stdev(src, n)` | Population. |
| `stats.zscore(src, n)` | 0 when deviation is 0. |
| `stats.percentile(src, n, pct)` | `pct` 0–100 (positional or `pct:`), linear interpolation; invalid → E933. |
| `stats.rank(src, n)` | Percentile rank 0–100 of the current value, current included. |
| `stats.linreg_slope(y, x, n)` | `na` if variance 0. |
| `stats.corr(y, x, n)` | `na` if a variance is 0. |

## Normalization `norm.*` (per event or bar, over a time or count window)

Each call place keeps its own population: drop values older than the window, add `x` (unless `push:` is false or `x`
is `na`), return `x` against the population. Kept across events and bars; time = the event's (in handlers) or bar's.

| Function | Returns |
|---|---|
| `norm.rank(x, window)` | Percentile rank 0–100 (current included); 99 = top 1 %. |
| `norm.zscore(x, window)` | `(x − mean) / sd`; 0 if sd is 0. |
| `norm.ratio(x, window, "median" \| "mean")` | `x` ÷ median (default) or mean; `na` if 0. |
| `norm.percentile(x, window, pct)` | The `pct` percentile of the values (a threshold in the measure's unit). |
| `norm.mean(x, window)`, `norm.median(x, window)` | |
| `norm.count(x, window)` | Values held (even below `min_count`). |
| `norm.unit(x, unit, window)` | `unit`: `"raw"` (x unchanged, even below `min_count`), `"rank"` (or `"percentile"`), `"zscore"`, `"x_median"`, `"x_mean"`. Pair it with an `input.choice`. |

- **Window**: a duration (`30m`) or a number of values (`500`, at most 1,000,000). Other → E933.
- **Options**: `min_count: n` (`na` until n values; default 20, min 1) · `by: key` (separate population per number,
  text, bool or time key; > 200,000 populations → E933) · `push: cond` (false: compare without adding).
- E933 also for an unknown unit, `pct` outside 0–100, a third `norm.ratio` argument other than `"median"`/`"mean"`.
- **Unbiased populations**: call `norm.*` at every event, before other conditions (not behind `and` or inside an `if`);
  in a pattern, in the statements before `when`. A call that always has `push: false` never holds a value (`na`).

```strate
indicator "Volume rank" { overlay: false, min: 0, max: 100 }
unit = input.choice("Volume in", ["rank", "zscore", "x_median", "x_mean", "raw"], "rank")
win = input.int("Normalize over (bars)", 200, min: 20)
v = norm.unit(volume, unit, win)
r = norm.rank(volume, 2h, min_count: 30)
plot(r, #2962ff, title: "Rank over 2h")
plot(norm.rank(volume, 200, by: close >= open), #e8c15a, title: "Rank by bar direction")
hline(90, style: "dotted")
```

```strate
indicator "Volume vs same hour" { overlay: false }
x = norm.ratio(volume, 5000, "median", by: bar.hour, min_count: 10)
histogram(x, x > 2 ? #e8c15a : #2962ff60, title: "Volume / median of this hour")
hline(1)
```

## Math

| Function | Notes |
|---|---|
| `abs`, `sqrt`, `log` (natural), `exp`, `floor`, `ceil` | Non-finite → `na`. |
| `pow(x, y)` | |
| `round(x, decimals = 0)` | Halves away from zero (`round(2.5)` = 3). |
| `sign(x)` | −1 for negatives, **1 otherwise (`sign(0)` = 1)**; `na` → `na`. |
| `max(a, …)`, `min(a, …)` | Any `na` → `na`; non-numbers ignored; no argument → E924. |
| `nz(x, default = 0)` | `x`, or default if `na`. |
| `na(x)` | True if `x` is `na`. |
| `math.pi`, `math.e` | Constants. |

## Text and numbers

| Function | Notes |
|---|---|
| `str(x)` | Numbers without useless zeros; durations as `"5s"`, `"5250ms"`, `"1h"`; colors `"#rrggbbaa"`; times as nanoseconds; lists and `na` as `"na"`. |
| `str(number, format)` | Digits after the point = decimals (`"0.00"`); leading `+` always shows the sign; trailing `k` abbreviates k/M from 1,000 / 1,000,000 (below 1,000 decimals are dropped); trailing `%` multiplies by 100 and adds `%`. |
| `str(time, format)` | Tokens `yyyy MM dd HH mm ss SSS`, in the chart's display time zone (New York by default). |
| `len(x)` | Length of list, text, map, ring, window; `na` otherwise. |

```strate
print(str(1234.5, "0.0k"), str(0.1234, "0.0%"), str(5, "+0"), str(1500000, "0.00k"), str(950, "0.0k"), str(5s), round(1.256, 2), round(2.5))
// → 1.2k 12.3% +5 1.50M 950 5s 1.26 3
```

## Colors

| Function | Notes |
|---|---|
| `rgb(r, g, b, transparency = 0)` | 0–255; transparency 0 (opaque) – 100; clamped. |
| `alpha(color, opacity)` | Opacity 0–100; `na` → `na`; non-color → E928. |
| `mix(c1, c2, t)` | `t` 0 (c1) – 1 (c2); non-color → E928. |

`na` as a color means "nothing on this bar" for `fill`, `bg_color`, `bar_color`.

## Settings `input.*`

Each call creates a setting in mode **Parameters** › **Settings** and returns its current value. First argument = the
**title**, a text (E925 otherwise). The title is the setting's identity: renaming it brings the default back; two calls
with the same title return the first one's value. Settings belong to each chart. Only `input.int` and `input.float`
can be swept in a strategy Report.

| Function | Returns / rules |
|---|---|
| `input.int(title, default, min:, max:, step:)` | Whole number (rounded), clamped to min/max; `step:` default 1. Use `min: 1` for a count of ticks or rows. |
| `input.float(title, default, min:, max:, step:)` | Number, clamped. |
| `input.bool(title, default)` | Checkbox. |
| `input.color(title, #rrggbb[aa])` | Color. |
| `input.duration(title, 30s)` | Duration. Not clamped by the engine: to keep a window within `level_history:`/`flow_history:`, clamp it in code (`w = d > 2m ? 2m : d`; `min()`/`max()` ignore durations). |
| `input.string(title, "text")` | Text. |
| `input.choice(title, ["A", "B"], default?)` | One of the texts (first if no default); non-list → E925. |
| `input.session(title, "HHMM-HHMM[,…][:days]")` | Range text for `session.in`; invalid default → E925 (invalid user value falls back to default). |
| `input.price(title, 0)` | Price clicked on the chart; `na` until picked. Non-number default → E925. |
| `input.time(title, 0)` | Instant clicked on the chart (snapped to the bar open); `na` until picked. |

Layout options on all: `group: "Name"` (collapsible group), `inline: "id"` (same line within a group),
`tooltip: "text"`.

A setting is a variable, so it cannot take a unit word: ticks from a setting → `price(input.int("Stop (ticks)", 8))`;
points → a plain number (`input.float("Stop (points)", 2.0)`).

```strate
indicator "Inputs demo" { overlay: true }
len = input.int("Length", 20, min: 1, max: 500, group: "Calculation", tooltip: "Bars in the average")
mult = input.float("Width", 2.0, step: 0.1, group: "Calculation")
src = input.choice("Source", ["close", "hl2"], "close", group: "Calculation")
up = input.color("Up", #26a69a, group: "Colors", inline: "c")
dn = input.color("Down", #ef5350, group: "Colors", inline: "c")
hours = input.session("Hours", "0930-1600:12345")
lvl = input.price("Level", 0)
x = src == "close" ? close : (high + low) / 2
basis = sma(x, len)
dev = stats.stdev(x, len) * mult
plot(basis + dev, up, title: "Upper")
plot(basis - dev, dn, title: "Lower")
bg_color(session.in(hours) ? #ffffff08 : na)
if not na(lvl) { hline(lvl, color: #e8c15a, text: "Level") }
```

A threshold the user can express in the unit of their choice:

```strate
indicator "Heavy volume" { overlay: true }
unit = input.choice("Volume in", ["rank", "zscore", "x_median", "raw"], "rank", group: "Threshold")
minVol = input.float("Min volume", 95, group: "Threshold", tooltip: "In the unit chosen above")
win = input.duration("Normalize over", 4h, group: "Threshold")
v = norm.unit(volume, unit, win)
marker(v >= minVol and bar.confirmed, shape: "circle", location: "above", color: #e8c15a)
```

## Footprint

`fp = bar.footprint` (also `bar.footprint[n]`) — the bar's volume per price by aggressor side, in rows of **one tick**.
Read it **in the body only** (E911 in handlers, patterns, clocks). Not available in long backtests (`na`). A bar has a
footprint only where Strate has its trades: test `fp.available` and say what happens without it.

| Field | Meaning |
|---|---|
| `available` | False without trade data. |
| `levels` | List of levels, lowest price first. |
| `poc`, `high`, `low` | Max-volume price; traded extremes. |
| `volume`, `delta`, `buy`, `sell`, `trades` | Totals. |
| `step` | Row height as a **price distance** (`0.25` on ES for `bar.footprint`, `0.5` after `fp.rows(2)`); `step / instrument.tick` = ticks per row. |
| `buy_trades`, `sell_trades`, `max_trade`, `max_buy`, `max_sell`, `avg_trade`, `avg_buy`, `avg_sell`, `first_time`, `last_time` | Per-trade detail; `na` without it. |

| Method | Returns |
|---|---|
| `fp.level(price)` | Level or `na` (fields of `na` read as `na`). |
| `fp.value_area(pct = 70)` | Object `.high .low .poc`, or `na`. |
| `fp.rows(ticks)` | Same footprint with rows of `ticks` ticks (whole number ≥ 1, E935); a row's price is its lowest price. |
| `fp.imbalances(side, ratio: 3, min_volume: 0)` | Prices (lowest first) where `side` (`"buy"`/`"sell"`, else E933) has ≥ `max(min_volume, 1)` and ≥ `ratio` × the diagonal volume (buy at p vs sell one row below; sell at p vs buy one row above). |
| `fp.stacked(side, ratio: 3, count: 3, min_volume: 0)` | List of `[low, high]` row prices of ≥ `count` (min 2) consecutive imbalances, same rules as `imbalances`. |

- `ratio` is a multiple: "300 %" is `ratio: 3`. A user setting in percent is divided by 100.
- **An empty diagonal row counts as 0**, so the lowest row (buy side) or the highest row (sell side) is an imbalance as
  soon as it has `max(min_volume, 1)` contracts. Set `min_volume:` (as a setting) to avoid imbalances made of one lot.
- To shade whole rows of a zone `z` from `fp.stacked` on rows of `n` ticks:
  `draw.rect(z[0], ticks: round((z[1] - z[0]) / instrument.tick) + n, …)`. `draw.rect(z[0], z[1])` goes from the middle
  of the bottom row to the middle of the top row.

Level fields: `price`, `buy`, `sell`, `volume`, `delta`, `trades`, plus the per-trade detail fields.

`footprint.accumulator()` builds a multi-bar profile: `acc.add(bar.footprint)` (non-footprint → E934, `na` ignored),
`acc.reset()`, `acc.bars`, plus every footprint field and method (step of one tick).

```strate
indicator "Footprint read" { overlay: true }
fp = bar.footprint
va = fp.value_area(70)
plot(nz(fp.poc), #e8c15a, title: "POC", style: "circles")
plot(va.high, #2962ff, title: "VA high")
plot(va.low, #2962ff, title: "VA low")
minVol = input.int("Min volume on the strong side", 5, min: 1)
for p in fp.imbalances("buy", ratio: 3, min_volume: minVol) { cell(p, "B", side: right, color: #26a69a, size: 9) }
for p in fp.imbalances("sell", ratio: 3, min_volume: minVol) { cell(p, "S", side: left, color: #ef5350, size: 9) }
for z in fp.stacked("buy", ratio: 3, count: 3, min_volume: minVol) {
  draw.rect(z[0], ticks: round((z[1] - z[0]) / instrument.tick) + 1, x: 0, w: 1, fill: #26a69a30)
}
```

```strate
indicator "Session profile POC" { overlay: true }
var prof = footprint.accumulator()
if session.is_new { prof.reset() }
prof.add(bar.footprint)
plot(nz(prof.poc), #e8c15a, title: "Session POC")
```
