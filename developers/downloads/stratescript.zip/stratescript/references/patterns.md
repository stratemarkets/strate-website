# Handlers, patterns, signals, clocks, shipped definitions

## Event handlers

| Handler | Runs for |
|---|---|
| `on trade(t)` | every trade (`order-flow.md`) |
| `on order(o)` | every MBO add, cancel, modify, fill |
| `on match(m)` | every aggressive execution |
| `on book(b)` | every book snapshot (250 ms) |
| `on session(s)` | each session boundary (`builtins.md`) |
| `on signal(s)` / `on signal(s from "Name")` / `on signal(s from alias)` | each pattern signal |
| `on clock name` | each tick of a custom clock |
| `on fill(f)`, `on exit(x)` | strategy fills and closed trades (`strategies.md`) |

Top level only; the parameter name is free; any other event name → E901. Each call has its own budget. Variables
created inside are local to the call: keep lasting values in `state`.

## Patterns

A named condition evaluated on an event stream. Each time it becomes true it emits a **signal**: a diamond on the chart
(green `"buy"`, red `"sell"`, violet without side) that `on signal` can listen to, `study()` can measure and a strategy
can act on.

```
pattern "Name" {
  on: trade              // required: trade, level, match, order, book or bar
  side: "buy"            // optional
  price: expression      // optional
  cooldown: 30s          // optional
  confirm: 2s            // optional
  show: [value, value]   // optional
  statements…            // computed at each event
  when condition         // exactly one
}
```

| Setting | Value | Error |
|---|---|---|
| `on:` | `trade`, `level`, `match`, `order`, `book`, `bar` | E934 missing/unknown |
| `side:` | `"buy"`, `"sell"` (`"long"`, `"short"`), a signed number, or `na` | E934 |
| `price:` | Signal price; default the event's price (bar close for `on: bar`) | — |
| `cooldown:` | Min delay between two signals at the same price and side; duration (plain number = seconds, `na` = 0) | E934 |
| `confirm:` | Condition must stay true this long before emitting (details below); same format | E934 |
| `show:` | Values added to the explanation | — |

- **Event variable** named after the stream: `trade.price` in `on: trade`, `order.side` in `on: order`, `match.size`,
  `book.spread`; `on: level` is the trade stream with the variable `level`. `on: bar` has none (read `close`…).
  `trade` carries every `on trade` field, sweep fields included (`trade.sweep_end`, `trade.sweep`); write one of them
  (or `mbo.`) in the text so MBO is requested (`order-flow.md` › What triggers loading).
- Event patterns run before the bar's body; `on: bar` patterns after it.
- Statements before `when` run at every event: compute `norm.*` and other stateful functions there.
- Signals fire on the **rising edge** of `when`, per price and side (per side for `on: bar`).
- Settings may share a line: `on: bar, cooldown: 3m`.
- **How `confirm:` and `cooldown:` are timed.** The condition is evaluated only when an event of the pattern's stream
  arrives, and its state is kept **per price and side**. `confirm: 30s` emits at the first event (at that price and
  side) where the condition is true and has been true at every evaluation since at least 30 s; a false evaluation
  restarts the wait. Nothing fires between events: if no event of that stream arrives at that price after the delay,
  no signal is emitted until one does. `s.start` gives when the condition became true.
- **"Holds for D"** (a wall that stays, a level that keeps its size) needs evaluations even when nothing changes at the
  price: use `on: book` (a snapshot every 250 ms) with `price:` the level, or a clock (`clock.time(1s)`) with your own
  timer in `state`. An `on: order` or `on: trade` pattern only re-checks when an order or trade touches that price.

```strate
indicator "Ask wall holds" { overlay: true }
minSize = input.int("Min size at the best ask", 200, min: 1)
holdFor = input.duration("Held for", 30s)
pattern "Ask wall holds" {
  on: book
  price: book.best_ask
  side: "sell"
  confirm: holdFor
  cooldown: 5m
  show: [book.ask_size]
  when book.ask_size >= minSize
}
plot(close, title: "Close")
```

Here the timer is kept per price: when the best ask moves, the wait starts again at the new price. Snapshots are
aggregated sizes; to follow one order (a single order of N lots), use `on order` and `mbo.order(id)`.
- Exactly one `when` (E108). Duplicate names → E934. Any other setting → E934 (`expire:` → E901).
- The **explanation** lists each top-level `and` term of `when` with its values, then `show:` values, e.g.
  `lv.replenishments = 1 ≥ minRefills = 1`.

```strate
indicator "Big bars" { overlay: true }
minRank = input.float("Min volume rank", 95)
pattern "Big bar" {
  on: bar, cooldown: 3m
  side: close > open ? "buy" : "sell"
  show: [volume]
  rk = stats.rank(volume, 100)
  when rk >= minRank
   and close != open
}
on signal(s from "Big bar") { label.new(s.time, s.price, s.side) }
```

```strate
indicator "Defended ask" { overlay: true, level_history: 2m }
minRefills = input.int("Min refills", 1, min: 1)
pattern "Defended ask" {
  on: order
  side: "sell"
  cooldown: 30s
  lv = order.is_add and order.side == "ask" ? mbo.level(order.price, window: 60s) : na
  when not na(lv)
   and lv.replenishments >= minRefills
}
on signal(s from "Defended ask") { label.new(s.time, s.price, s.explain) }
plot(close, title: "Close")
```

## Listening: `on signal`

```
on signal(s) { … }               // every pattern of the script
on signal(s from "Name") { … }   // one pattern (unknown name → E934 with the list)
on signal(s from alias) { … }    // every pattern of an imported script
```

Fields: `s.name`, `s.time`, `s.price` (`na` if none), `s.side` (`"buy"`, `"sell"`, `na`), `s.start` (when the
condition became true, before `confirm:`), `s.explain`.

`signal(...)` **the function** is different: it draws a small mark at the top of the chart whenever it is called,
whatever its argument (one per call place and bar). Put it inside an `if`.

## Custom clocks

```
clock name = clock.time(1s)
on clock name { … }
```

Evaluated after each market event (trade, MBO event, book snapshot):

| Clock | Fires |
|---|---|
| `clock.time(d)` | First event at or after each multiple of `d` (aligned: `1m` fires each new minute) |
| `clock.volume(n)` | Every `n` contracts traded since it last fired |
| `clock.trades(n)` | Every `n` trades |
| `clock.events(n)` | Every `n` market events of any kind |
| `clock.range(d)` | When the traded high−low since it last fired reaches `d` (e.g. `clock.range(4 ticks)`) |
| `when(condition)` | Each time the condition becomes true (must turn false before firing again) |

Thresholds are evaluated once at start and must be positive (E935). A clock fires after the handlers and patterns of the
triggering event; inside, `event.time` is that event's time and `open`, `close`… the chart bar so far. Duplicate clock
names, `on clock x` without clock `x`, other forms → E935; `when(…)` outside a clock declaration → E901.

```strate
indicator "Imbalance clock" { overlay: true }
threshold = input.int("Imbalance", 200, min: 1)
state theta = 0
on trade(t) { theta += t.delta }
clock vib = when(abs(theta) >= threshold)
on clock vib {
  label.new(event.time, close, str(theta), color: theta > 0 ? #26a69a : #ef5350)
  theta = 0
}
plot(close, title: "Close")
```

```strate
indicator "One-second sampler" { overlay: false }
clock sec = clock.time(1s)
state spreadSum = 0
state n = 0
on clock sec {
  if book.available {
    spreadSum += book.spread / instrument.tick
    n += 1
  }
}
plot(n > 0 ? spreadSum / n : na, #2962ff, title: "Mean spread (ticks)")
spreadSum = 0
n = 0
```

## The shipped pattern library

Strate ships **competing** definitions written in StrateScript, imported from `strate/patterns/<file>`. None is a
default; each exposes its thresholds as settings that can be overridden on the import line. Every threshold has a unit
choice (`rank`, `zscore`, `x_median`, `x_mean`, `raw`) normalized over `normWindow`. Most need MBO data. In the
StrateScript panel's script menu they appear as **Definition:** entries; choosing one adds its full code to the chart,
which is the best way for the user to read or fork it.

| File | Definition | Override keys (default) |
|---|---|---|
| `absorption_held_volume` | High aggressor volume at a price that stayed best bid/ask for a share of the window and is still displayed | `window` (30s), `held` (50 %), `normWindow` (30m), `volUnit` ("rank"), `minVol` (98) |
| `absorption_replenishment` | High aggressor volume at a price emptied and refilled many times | `window` (30s), `within` (2s), `normWindow`, `volUnit` ("rank"), `minVol` (95), `refUnit` ("rank"), `minRefills` (98) |
| `absorption_exhaustion` | High aggressor volume while that side's flow dies out | `window` (60s), `maxDecay` (0.5), `normWindow`, `volUnit` ("rank"), `minVol` (95) |
| `absorption_hidden` | Aggressors traded far more than displayed orders filled | `window` (30s), `normWindow`, `hidUnit` ("x_median"), `minHidden` (5) |
| `refill_same_order` | Level emptied and refilled many times by an order already seen there | `window` (30s), `within` (2s), `normWindow`, `refUnit` ("raw"), `minRefills` (3) |
| `refill_new_orders` | Level emptied and refilled many times by new orders | `window` (30s), `within` (1s), `normWindow`, `refUnit` ("rank"), `minRefills` (99.5) |
| `sweep` | One aggressive order through several prices, large total size; once per order | `normWindow`, `sizeUnit` ("rank"), `minSize` (97), `lvlUnit` ("raw"), `minLevels` (2) |
| `stop_run` | Trade beyond the recent high/low inside an unusual same-side burst | `lookback` (20 bars), `burstWithin` (2s), `normWindow`, `burstUnit` ("rank"), `minBurst` (99), `beyondUnit` ("raw"), `minBeyond` (1) |
| `spoofing_pulled_before_touch` | Large order away from best, rested a while, never filled, canceled in full as price came closer | `minAge` (2s), `normWindow`, `sizeUnit` ("rank"), `minSize` (99.9), `distUnit` ("raw"), `minDist` (4) |
| `liquidity_pull` | Large size canceled at/next to the best, mostly not traded against | `window` (10s), `minRatio` (0.8), `maxHitPct` (25), `normWindow`, `canUnit` ("rank"), `minCanceled` (99) |

`normWindow` defaults to `30m` everywhere. Each imported script's settings appear in the Settings tab as
`alias · Title` unless overridden. Naming an override the file does not declare → E937 with the list.

```strate
indicator "Two absorption definitions" { overlay: true }
import "strate/patterns/absorption_held_volume" as strict { minVol: 99 }
import "strate/patterns/absorption_held_volume" as loose { minVol: 80 }
on signal(s from strict) { label.new(s.time, s.price, "strict") }
on signal(s from loose) { label.new(s.time, s.price, "loose") }
```

Prefer writing the definition in the open (see `order-flow.md` worked examples and `examples.md` #9–#11) when the user
wants to understand or change its logic; import a shipped definition when they want a known starting point or to
compare definitions side by side (a research `compare()` is the natural tool for that).
