# Research: what happens after a signal?

A `research` script defines signals, calls `study()` on each, and the **Report** (mode **Parameters**) measures the
outcomes: price change after fixed horizons, and optionally the result of a target and a stop.

```strate
research "Up-bar follow-through" { overlay: true }
minDelta = input.int("Min delta", 20)

pattern "Up bar" {
  on: bar
  side: "buy"
  when close > open
   and delta >= minDelta
}

pattern "Down bar" {
  on: bar
  side: "sell"
  when close < open
   and delta <= -minDelta
}

on signal(s) {
  study(s, horizons: [1m, 5m, 15m], target: 8 ticks, stop: 4 ticks, cost: 1 tick)
}

// the study is measured on trades: this handler makes sure they are loaded on the chart
on trade(t) { }

report(by: ["name", "side", "rth"], ci: 1000)
```

## `study()`

```
study(s, horizons: [1m, 5m, 15m], target:, stop:, cost: 0)
```

Only in a `research` script (E938 elsewhere, including strategies).

**The signal `s`**: the one received by `on signal(s …)`, **or any object of your own type with fields `time`, `side`,
`name`, `price`** (anything else → E938).

| Signal field | Use |
|---|---|
| `side` | `"buy"`/`"sell"`; without a side the signal is counted but left out of outcomes (`without_side`) |
| `name` | Group in the report (default `"signal"`) |
| `time` | Instant of the signal (default: the current event) |
| `price` | Entry if no trade has been seen yet |

| Parameter | Value | Default | Error |
|---|---|---|---|
| `horizons` | List of durations > 0, or one duration | `[1m, 5m, 15m]` | Non-duration items in a list are dropped silently; E938 if none left or a single bad value |
| `target`, `stop` | Distances > 0 (**plain number = points**) | none | ≤ 0 → E938 |
| `cost` | Distance ≥ 0 subtracted from each outcome | 0 | negative → E938 |

## How outcomes are measured

- **Entry** = last traded price at the signal's time. A study made in the body or an `on: bar` pattern is dated at the
  bar's known close and enters at the last trade at that time.
- **Horizon outcome** = (last traded price at or before t + h − entry) × direction − cost, in ticks. Data ending before
  t + h → **incomplete**, never extrapolated.
- **With target and/or stop**: target reached when a trade **touches** it (+ target − cost); stop at the price of the
  crossing trade ((that price − entry) × direction − cost); otherwise exit at the longest horizon (reason `time`).
  Results in R (÷ stop) with a stop, else ticks.
- **MFE / MAE** are measured for every study, with or without target and stop: the best and worst trade price
  reached after the signal up to the longest horizon, in gross ticks (cost not subtracted), MAE ≤ 0. The report shows
  the group's **average** only; there is no per-signal export in research. For the share of signals whose MFE reached
  X ticks, study the same signal under several names, each with `target: X` only, and read the share of exits by
  target (`compare()`). A per-trade list with `mfe_ticks`/`mae_ticks` exists in a strategy's CSV (with latency,
  slippage and one position at a time).

## `report()` and `compare()`

```
report(by: ["name", "side"], ci: 1000)
compare(by: ["side"], ci: 1000)
```

Research only (E938 elsewhere). `by:` a text or list among `"name"`, `"side"`, `"rth"` (else E938); `"side"` is always
included; `compare()` always puts `"name"` first to set definitions side by side; `"rth"` splits `rth` (9:30–16:00) vs
`eth`. `ci:` bootstrap draws 0–20,000 (default 1,000; 0 = none). No other parameter (unknown names ignored).

## The research report

Top: signals, studied, without side, incomplete, days, DEV/VAL split day, settings declared. Then per group: for each
horizon n, win rate, mean and median ticks, 95 % CI (bootstrap over days), DEV and VAL means; average MFE/MAE; with
target/stop: share of exits by target/stop/time, win rate, **break-even win rate** `100 × (stop + cost) / (target +
stop)`, mean, CI, total, max drawdown, worst streak, DEV and VAL.

- **DEV / VAL** on a chart: the days **that have signals** are split at day index ⌊n/2⌋ (differs from strategies,
  which split loaded sessions). Fewer than 2 days → no split. Long backtests: VAL start declared before running.
- **One geometry per group**: a group's block shows the target/stop/cost of its first study. Different geometries need
  different `name`s.
- **Same horizons in the whole script**: report columns are those of the first study; other studies are listed by
  position, so mixing `[30s, 2m]` with `[1m, 5m, 15m]` shows outcomes under the wrong horizons.

## Signals without patterns

```strate
research "Large prints" { overlay: true }
type Event { time: time, side: string, name: string, price: float }
minSize = input.int("Min size", 5, min: 1)

on trade(t) {
  if t.size >= minSize {
    study(Event { time: t.time, side: t.delta > 0 ? "buy" : "sell", name: "Large print", price: t.price },
          horizons: [30s, 2m], target: 6 ticks, stop: 6 ticks, cost: 1 tick)
  }
}

report(by: ["name", "side"])
```

Two definitions compared side by side, each with its own name:

```strate
research "Sweep follow-through" { overlay: true }
type Event { time: time, side: string, name: string, price: float }

on trade(t) {
  if not na(t.levels) and t.sweep_end {
    nm = t.levels >= 3 ? "Sweep 3+ levels" : "Sweep 1-2 levels"
    study(Event { time: t.time, side: t.is_buy ? "buy" : "sell", name: nm, price: t.price }, horizons: [30s, 2m, 5m])
  }
}

compare(by: ["side"])
```

### Choosing the population of a normalization

A rank or z-score says "large compared with what". Pick the population that matches the event, and fill it at every
occurrence, before any filter:

- **per execution**: `norm.rank(t.size, …)` at every trade;
- **per aggressive order** (sweeps): one value per order, at its last execution — `push: t.sweep_end`, both sides;
- **per order event**, **per bar**…: call it where each one happens, once.

```strate
research "Large sell sweeps" { overlay: true }
type Event { time: time, side: string, name: string, price: float }
unit = input.choice("Sweep size in", ["rank", "zscore", "x_median", "raw"], "rank", group: "Threshold")
minSize = input.float("Min sweep size", 99, group: "Threshold", tooltip: "In the unit chosen above")
normWin = input.duration("Normalize over", 30m, group: "Threshold")
minCount = input.int("Orders before normalizing", 200, min: 1, group: "Threshold")
minLevels = input.int("Min prices traded", 2, min: 1)

on trade(t) {
  // one value per aggressive order (both sides), added at its last execution, before any filter
  sz = norm.unit(t.sweep, unit, normWin, min_count: minCount, push: t.sweep_end)
  if t.sweep_end and t.is_sell and t.levels >= minLevels and not na(sz) {
    nm = sz >= minSize ? "Large sell sweep" : "Other sell sweep"
    study(Event { time: t.time, side: "sell", name: nm, price: t.price }, horizons: [1m, 5m, 15m])
  }
}

compare(by: ["side"])
```

The "Other sell sweep" group is the reference: the same kind of event without the size condition.

## Trades must be loaded

Outcomes are measured on trades; without them every study is incomplete (n = 0). Long backtests always have trades.
On a chart, trades load only when the text uses them (`on trade`, `on: trade`/`on: level` pattern, a clock, an
`of.flow`-type function). A research script whose signals come only from bars needs `on trade(t) { }`.

## Reading results honestly

Explain to the user: compare the win rate with the break-even win rate; look at the CI (day bootstrap) before the mean;
a DEV result is in-sample; VAL is the check; incomplete studies near the end of the data are excluded, not guessed.
