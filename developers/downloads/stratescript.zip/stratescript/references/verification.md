# Verifying a script

## The checker: `scripts/verify.py`

While the Strate app runs, it serves on this computer (address `127.0.0.1` only) the same check its StrateScript editor
runs before executing a script. `scripts/verify.py` sends scripts to it and prints the result. It needs Python 3 and
nothing else, and sends nothing anywhere but `127.0.0.1`. It does not change anything in the app: no chart, script or
setting is touched.

```
python3 scripts/verify.py script.strate [more.strate …]
python3 scripts/verify.py answer.md                  # every ```strate block of a Markdown file
cat script.strate | python3 scripts/verify.py -      # standard input
python3 scripts/verify.py --port 18736 script.strate # explicit port
python3 scripts/verify.py --import my/Tools=tools.strate uses_tools.strate
python3 scripts/verify.py --json script.strate       # raw results (summary on stderr)
python3 scripts/verify.py --quiet *.strate           # failures and summary only
```

- **Port**: tries `18736` (the installed app) then `8736`; `--port N` or the environment variable `STRATE_PORT`
  override it.
- **Imports**: `import "strate/patterns/<file>"` is resolved automatically from the running app. Scripts given in the
  same run can import each other as `my/<Name>` (like scripts of one chart); otherwise pass `--import my/Name=file`.
- **Markdown**: a block preceded by the line `<!-- expect: E930 -->` must fail with that code (useful for documented
  counter-examples).
- **Exit code**: 0 all OK · 1 at least one script failed · 2 Strate not reachable (**nothing was checked**).

### Reading the output

```
OK   my_script.strate
       outputs: plot "Basis", plot "Upper", plot "Lower"
       settings: Length (int, default 20), Band width (std devs) (float, default 2.0), …
       events: 26, market events replayed: 3085
```

`outputs` are the series the script draws (plots, histograms, levels…); `settings` are the inputs the user will see in
the Settings tab — list them when you hand the script over. `market events replayed` counts the synthetic trades, MBO
events and book snapshots fed to the script.

`events` counts exactly these, produced on the synthetic market:

| Counted | Not counted |
|---|---|
| `marker` (one per call place and bar), `print` lines, `alert` / `signal` calls that fired, `label()`, `box()`, `line()`, `bubble()`, pattern signals, strategy entries and exits | `plot`, `histogram`, `fill`, `level`, `hline`, `bg_color`, `bar_color`, `stat`, `cell`, `hbar`, `draw.*`, tables, objects made with `label.new` / `box.new` / `line.new`, `study()` |

So `events: 0` can mean "the branch never ran" or "the branch only creates objects". To know, add a witness (next
section).

```
KO   my_script.strate  E930 line 3, column 10: "clsoe" is not defined
          3 | plot(sma(clsoe, len))
            |          ^
       fix: did you mean "close"?
```

Look the code up in `errors.md`, fix, run again.

## What the check does

1. Parses the script (all E0xx/E1xx syntax errors) and resolves imports.
2. Runs it on a synthetic market, budget 200,000 operations per bar/event (or the header's `budget:`):
   - **300 one-minute ES bars** (tick 0.25, point value 50) of **one afternoon in RTH**, about 10:13 to 15:13 New York
     time. Every bar has a volume (100–260), a delta and a footprint.
   - On the **last 60 bars only**: an order-by-order book of a few orders per price (resting sizes **2 to 20 lots**),
     a dozen MBO events per bar (adds, cancels, size changes up and down, three executions of **4 to 8 lots**), the
     trades derived from them (with sweep fields), and **4 book snapshots per bar** (every 15 s).
3. Reports the first error found, or the outputs and settings.

Consequences: anything that needs a second day, the night session or a session boundary never happens there:
`prev.*` and `request("1d", …)` are `na`, `session.is_new` is true only on the first bar, `of.cvd` resets and RTH-open
logic do not fire. Thresholds sized for real ES activity (a 50-lot fill, a 200-lot wall, a 2-second cancel, a top-1 %
rank over 30 minutes) usually never trigger. There is no other instrument.

Some cases never happen there at all, whatever the threshold: a trade or aggressive order above 8 lots, a partial
cancel, an order resting before the MBO data starts, hidden volume (`hidden_filled` stays 0), a refill by the same id
(`refill_same_id` stays 0; refills by new ids do happen). Code that needs them cannot be exercised beyond running the
lines before it: say so to the user.

## Covering branches

A passing check covers only the code that ran. For each branch that matters (an entry, a signal, a label, an alert):

1. Make a temporary copy of the script.
2. Add a witness inside the branch: `print("branch A")` (one `events` per call place and bar).
3. Loosen what keeps it closed: lower the thresholds' **defaults** (`input.int("Min size", 1)`), lengthen windows
   within the history keys, replace a previous-day level with a value near the synthetic prices (around 6000), or write
   `if true or …` around the condition. A setting's value is clamped to its `min:`/`max:`, default included:
   `input.int("Min", 0, min: 1)` gives 1, so lower `min:` too when a branch needs 0.
4. Check the copy: `events` must be above 0 and the result `OK`.
5. Give the user the original script, never the forced copy.

Strategies count entries and exits in `events`, so a strategy with `events: 0` placed no simulated order there.

## What it does not cover

- **Branches that never ran** (above). An error hidden there appears on the chart when that line first runs.
- **`request(…, symbol: "XX")`** always fails with E936 here (no other instrument). Verify the rest of the script by
  temporarily replacing that call, then restore it.
- **Logic and meaning.** A passing check means the script runs; it does not mean the definition is the one the user
  wants. Explain the logic.
- **Silently ignored names.** Unknown header keys and unknown named arguments pass the check. Compare every key and
  argument with the references.
- **Data availability and depth.** MBO/book code passes the check (the synthetic market has MBO) but draws nothing on a
  chart without that data, and sees only the history its header allows (`order-flow.md` › How much history).

## Is it safe to call the user's app?

Yes. The check parses and runs the script in memory and returns the result; it does not open, add or change any
chart, script, setting or order. It is a short computation on the app's local server. Do not send hundreds of scripts
in a loop while the user is trading; one check per version of the script is enough.

## When Strate is not reachable

The checker prints `NOT CHECKED` and exits with 2 when no app answers (the app is closed, it runs on another computer,
or a firewall blocks local connections). There is no offline checker: the check is part of the app. An agent running
in a sandbox or in the cloud is in this case even when Strate is open on the user's computer. Then:

1. Say clearly that the script was **not** machine-checked.
2. Review it with `checklist.md`.
3. Ask the user to paste it into the StrateScript panel (mode **Code**) and send back the red error box text, if any
   (hover its title for the code and column). Fix from the code with `errors.md`.

Never claim a script passed the check when the checker did not run.
