# Strategies (simulated orders)

A `strategy` places **simulated** orders and produces a Report. It never sends a real order, never touches an account.
The simulation advances **on real trades**: every fill, stop and target is decided against the market's trades.

Contents: Header · Units · `enter` · `exit`/`cancel` · Stops at a price level · Decision time · Fills · `position` · `on fill`/`on exit` ·
Report · CSV · Sweeps · Long backtests · Fixed MBO start · Honest-simulation rules · Pitfalls

```strate
strategy "Bar breakout" { overlay: true, costs: { commission: 2.5 usd, slippage: 1 tick } }
len = input.int("Length", 20, min: 2)
hi = highest(high, len)
lo = lowest(low, len)
if position.flat and close > hi[1] {
  enter("buy", stop: 8 ticks, target: 16 ticks, timeout: 30m)
}
if position.flat and close < lo[1] {
  enter("sell", stop: 8 ticks, target: 16 ticks, timeout: 30m)
}
on exit(x) {
  label.new(x.time, x.price, str(x.r, "+0.00") + " R", color: x.usd > 0 ? #22c55e : #ef4444)
}
```

Entries are drawn as triangles, exits as dots (green win, red loss). Results: mode **Parameters** › **Report**.

## Header

```
strategy "Name" { costs: { commission: 2.5 usd, slippage: 1 tick }, fill_model: through, latency: 60ms }
```

| Key | Rules |
|---|---|
| `costs` | **Required** object (missing / not an object → E939). Both keys required, literals. |
| `commission` | USD per contract **per side** (round trip = `2 × commission × size`); `2.5 usd` = `2.5`; `0` allowed; negative → E939. Not a setting, not sweepable. |
| `slippage` | `n tick(s)` = n ticks; a plain number or `n point(s)` = **points** (`slippage: 1` = 4 ticks on ES); `0 tick` allowed. |
| `fill_model` | `through` (default, prudent), `touch`, `queue`, unquoted (`"queue"` → E939). |
| `latency` | Duration ≥ 0, default `60ms` (a number or negative → E939). |

Point value and tick come from the chart's instrument. **One position at a time**; a pending entry occupies the slot;
no pyramiding, no direct reversal (exit, then enter). The Report states the simulation conditions in one sentence.

## Distances and units

Stops, targets, offsets are price distances: `8 ticks` = `2 points` = `2` on ES. **`stop: 4` is 16 ticks on ES.**
A setting cannot take a unit word: `price(n)` converts ticks → distance, `ticks(d)` distance → ticks.

```strate
strategy "Fade the stretch" { overlay: true, costs: { commission: 2.5 usd, slippage: 1 tick } }
len = input.int("Length", 20, min: 2)
k = input.float("Stretch", 1.5, step: 0.25)
stopTicks = input.int("Stop (ticks)", 8, min: 1)
basis = sma(close, len)
dev = stats.stdev(close, len)
if position.flat and close > basis + k * dev {
  enter("sell", stop: price(stopTicks), target: price(stopTicks), timeout: 15m)
}
if position.flat and close < basis - k * dev {
  enter("buy", stop: price(stopTicks), target: price(stopTicks), timeout: 15m)
}
plot(basis, title: "Basis")
```

## `enter()`

```
enter(side, size: 1, type: "market", price:, stop:, target:, timeout:, expire:, tag:)  → bool
```

| Parameter | Values | Default | Behavior |
|---|---|---|---|
| `side` | `"buy"`/`"long"`/number > 0; `"sell"`/`"short"`/number < 0 | — | `na` places nothing, returns false (no error). Other text or 0 → E939. |
| `size` | number | 1 | Rounded, min 1. |
| `type` | `"market"`, `"limit"`, `"stop"` | `"market"` | Other → E939. |
| `price` | price | — | Required for limit/stop; missing **or `na`** → E939. Ignored for market. |
| `stop` | distance > 0, or `na` | none | From the actual fill price. `na` = no stop; ≤ 0 → E939. Without a stop, results are in ticks and `x.r`/`open_r` are `na`. |
| `target` | distance > 0, or `na` | none | `na` = no target; ≤ 0 → E939. A setting where 0 means "none": `target: t > 0 ? price(t) : na`. |
| `timeout` | duration > 0, or `na` | none | Market exit at the first trade at or after entry + timeout. `na` = none; a number → E939. |
| `expire` | duration > 0 | never | Pending entry withdrawn at the first trade after decision + expire. |
| `tag` | text | `""` | Carried by fills, exits, trade list, CSV. |

Returns true if placed; false if a position is open or an entry is pending. Outside a strategy → E939.
**There is no `trail:`** (unknown arguments are ignored silently): manage a trailing stop with your own logic and
`exit()`.

```strate
strategy "Buy the pullback" { overlay: true, costs: { commission: 2.5 usd, slippage: 1 tick }, fill_model: through }
offset = input.int("Offset (ticks)", 4, min: 1)
trend = ema(close, 50)
if position.flat and position.pending == 0 and close > trend {
  enter("buy", type: "limit", price: close - price(offset), stop: 8 ticks, target: 8 ticks, expire: 5m, tag: "pullback")
}
plot(trend, title: "Trend")
```

A stop entry guarded against `na` (`highest` is `na` on the first bars):

```strate
strategy "Range break" { overlay: true, costs: { commission: 2.5 usd, slippage: 1 tick } }
len = input.int("Range bars", 15, min: 2)
top = highest(high, len)
bottom = lowest(low, len)
if position.flat and position.pending == 0 and not na(top) {
  enter("buy", type: "stop", price: top + 1 tick, stop: 8 ticks, target: 16 ticks, expire: 15m, tag: "up")
}
plot(top, title: "Top")
plot(bottom, title: "Bottom")
```

## `exit()` and `cancel()`

- `exit(tag: "x")` closes the open position at market (fills after the latency). Without tag: whatever the tag; with a
  different tag: nothing. A second `exit` while one is pending is ignored. Reason `exit`.
- `cancel(tag: "x")` withdraws pending **entries** with that tag (all without a tag), returns how many. Never touches a
  pending exit.

```strate
strategy "Manual management" { overlay: false, costs: { commission: 2.5 usd, slippage: 1 tick } }
var barsIn = 0
if position.flat {
  barsIn = 0
  if close > open and close > close[1] {
    enter("buy", stop: 8 ticks, tag: "momo")
  }
} else {
  barsIn += 1
  // leave after 5 closed bars, or at the first bar close showing 6 ticks of open profit
  if barsIn >= 5 or position.open_ticks >= 6 {
    exit(tag: "momo")
  }
}
plot(position.size, title: "Size")
```

## When a decision is made, and when it can fill

- In a handler (`on trade`, `on order`, `on match`, `on book`, `on session`, `on signal`, `on fill`, `on exit`), a clock
  or an event pattern: at the **event's time**.
- In the body (and `on: bar` patterns): at the bar's **known close** (time bars: open + unit; others: next bar's open).
- An order fills only on trades **strictly after** `decision + latency`. Example on 1-minute bars: a body decision on
  the 19:49 bar is made at 19:50:00 and can fill from 19:50:00.060 (60 ms latency).

### Trading hours

Filter entries on the time the decision is made, and say what happens to a position at the end of the hours:

```strate
strategy "Hours window" { overlay: true, costs: { commission: 2.5 usd, slippage: 1 tick } }
hours = input.session("Entry hours (New York)", "0945-1530")
flatten = input.bool("Exit at the end of the hours", true)
len = input.int("Length", 20, min: 2)
stopTicks = input.int("Stop (ticks)", 8, min: 1)
tgtTicks = input.int("Target (ticks, 0 = none)", 16, min: 0)
avg = sma(close, len)
cross = crossover(close, avg)                  // computed on every bar, before any filter
inHours = session.in(hours, bar.close_time)    // a body decision is made at the bar's close
if bar.confirmed and inHours and position.flat and cross {
  enter("buy", stop: price(stopTicks), target: tgtTicks > 0 ? price(tgtTicks) : na)
}
if bar.confirmed and flatten and not position.flat and not inHours {
  exit()                                       // first bar closing outside the hours
}
plot(avg, title: "SMA")
```

`session.rth` and `session.in(hours)` without a time test the bar's **open**: a one-minute bar opening at 15:59 decides
at 16:00. In a handler, use `session.in(hours, event.time)`.

## How orders fill (per trade, price p, size v)

1. **Open position**: MFE/MAE updated (ticks from entry), then
   - **stop**: a trade touches or crosses it → exit at **that trade's price** minus slippage (reason `stop`);
   - **target**: `touch`/`queue`: a trade touches it; `through`: a trade at least 1 tick beyond → exit **at the target
     price**, no slippage (reason `target`);
   - **timeout**: first trade at or after entry + timeout → trade price minus slippage (reason `timeout`).
   The trade that opened the position is not tested against its stop/target.
2. **Eligible pending orders** (after latency; expired entries removed first):

| Order | Fills |
|---|---|
| market | trade price + adverse slippage |
| stop entry | a trade reaches/passes the level → that trade's price + slippage |
| limit, `touch` | limit price, as soon as a trade is at the limit or better |
| limit, `through` (default) | limit price, when a trade is at least 1 tick beyond |
| limit, `queue` | limit price, once the volume ahead in the MBO queue has traded, or a trade goes 1 tick beyond |

**`queue`**: volume ahead = resting size at that price that arrived before the order became eligible (from the MBO
book); it only decreases (cancels, fills, each trade at the price). Without MBO it is 0 (`queue` = `touch`). On a chart,
`fill_model: queue` alone loads MBO; in a long backtest the book is rebuilt only if the script also reads MBO
(`on order`, `on match`, `mbo.`, `of.ofi(`), otherwise `queue` behaves like `touch`.

3. **Result of a closed trade**: `ticks` net of commission per contract = gross ticks − `2 × commission / (tick × point
   value)`; `usd` = gross USD × size − `2 × commission × size`; `r` = net ticks ÷ stop ticks. Example ES: 8-tick target,
   8-tick stop, 3 contracts, 2.5 USD → 7.6 ticks, 285 USD, 0.95 R.

### Stops and targets at a price level

`stop:` and `target:` are distances from the actual fill price, so they cannot name a price ("stop at the range low").
Two honest ways:

- **Distance at decision time**: `stop: close - level` (for a long). Simple and gives R in the Report, but the level
  moves with the fill price (latency, slippage).
- **Exact level, own exit**: keep the level in `state` and call `exit()` from `on trade` when a trade prints at or
  beyond it; the exit fills at market after the latency. A distance stop can stay as a backstop and to get R.

```strate
strategy "Exit at a price level" { overlay: true, costs: { commission: 2.5 usd, slippage: 1 tick }, latency: 60ms }
len = input.int("Range bars", 15, min: 2)
hh = highest(high, len)
ll = lowest(low, len)
state stopLevel = na
if position.flat and position.pending == 0 and bar.confirmed and not na(hh[1]) and close > hh[1] {
  // backstop one tick beyond the level, as a distance (gives R in the Report)
  if enter("buy", stop: close - ll[1] + 1 tick, tag: "brk") {
    stopLevel = ll[1]
  }
}
on trade(t) {
  // exact level: exit at market at the first trade at or below it
  if position.side == "buy" and not na(stopLevel) and t.price <= stopLevel {
    exit(tag: "brk")
  }
}
on exit(x) {
  stopLevel = na
}
plot(stopLevel, #ef5350, title: "Stop level", style: "step")
```

When the requested stop is on the wrong side (a fade whose stop is "the other side of the range" would sit beyond the
target), the request is contradictory: ask, or state plainly in the answer which reading the script uses.

## `position` (strategy only, E939 elsewhere; unknown field → E932)

| Field | Content |
|---|---|
| `position.flat` | No position open |
| `position.side` | `"buy"`/`"sell"`, `na` when flat |
| `position.size` | Signed (+ long, − short, 0) |
| `position.entry_price`, `position.entry_time` | |
| `position.open_ticks` | Gross open profit in ticks at the last price processed |
| `position.open_r` | Open profit in R (`na` without stop) |
| `position.mfe`, `position.mae` | Max favorable / adverse excursion so far, gross ticks |
| `position.pending` | Pending orders, exits included |
| `position.trades` | Closed trades |
| `position.net_usd` | Net USD of closed trades |

## `on fill(f)` and `on exit(x)`

- `f`: `time`, `price`, `side`, `size`, `tag`.
- `x`: `time`, `price`, `side` (of the closed position), `reason` (`stop`, `target`, `timeout`, `exit`; `end_of_data`
  in long backtests), `ticks`, `usd` (net), `r` (`na` without stop), `entry_price`, `tag`.
- Other fields → E932; outside a strategy → E939.

```strate
strategy "Follow large prints" { overlay: true, costs: { commission: 2.5 usd, slippage: 1 tick }, latency: 60ms }
minSize = input.int("Min size", 5, min: 1)
on trade(t) {
  if position.flat and t.size >= minSize {
    enter(t.delta > 0 ? "buy" : "sell", stop: 6 ticks, target: 12 ticks, timeout: 10m, tag: "print")
  }
}
on fill(f) {
  print("fill", f.side, f.size, f.price, f.tag)
}
on exit(x) {
  print("exit", x.reason, x.ticks, x.usd, x.r)
}
```

## The Report

For all trades and for buys/sells separately: trades, sessions with entries, open position (not counted); win rate (a
0 trade counts as a loss), mean per trade with 95 % CI; average win/loss and the check line `win% × avg win + loss% ×
avg loss = mean`; total, net USD, max drawdown, worst losing streak; exit reasons (%); average MFE/MAE; equity curve
(300 points); latest 200 trades.

- **Unit**: R when every trade of the group had a stop, else ticks. R and ticks are **net of commission** (and of
  slippage on fills): with an 8-tick stop on ES and 2.5 USD per side, a target set at 1R reads about 0.95R and a
  stop about −1.05R before slippage. Say so when the user sets targets in R.
- **CI**: bootstrap over **days** (1,000 draws), needs ≥ 2 days.
- **DEV / VAL**: the loaded sessions are split in halves at session index ⌊n/2⌋ (DEV first, VAL second); trades and
  mean are shown for each. A CME session is dated by its New York trading date (starts 18:00 the evening before).
- The Report shows how many settings the script declares (more tuned settings → a good DEV result is more likely luck).

**CSV**: **Export trades (CSV)** writes every closed trade (up to 200,000) to Downloads as
`Strate-trades-<name>-YYYYMMDD-HHMMSS.csv`, columns
`side,size,entry_time_utc,entry_time_ns,entry_price,exit_time_utc,exit_time_ns,exit_price,reason,net_ticks,net_r,net_usd,mfe_ticks,mae_ticks,cum_usd,tag`
(UTC times, net results).

## Sweeps

From the Report: one `input.int` / `input.float` setting, start/end/step, at most 40 values, measured on the **DEV half
only** (VAL never looked at). Per value: mean with 95 % day-bootstrap CI, trades, days, win rate, net USD, max DD. The
sweep smooths each mean with its neighbors (3 values), shows the center of the longest run of ≥ 3 consecutive positive
smoothed values (the **plateau**), and flags the best isolated point outside it as probable noise. Intended use: keep
the plateau center, then judge that single value **once** on VAL. Time limit 30 s / 2 min (default) / 10 min / none
(60 min); MBO/book strategies from a fixed start run in the background with a Stop button. Costs and latency are header
literals: not sweepable.

## Long backtests on MBO replay files

From the Report, a `strategy` (or `research`) runs over many days of local MBO replay files, off the chart.

- **Files**: one per day, `.dbn` or `.dbn.zst`, with an 8-digit `YYYYMMDD` date in the name; date range (empty = all),
  at most 600 days.
- **Bars**: the chart's unit, time-based only (1 s to 1 day), built from the trades of the file's most active contract;
  at most 20,000 bars per day.
- **Hours window**: optional New York `HH:MM-HH:MM` within a day. For scripts reading MBO, the book is rebuilt from the
  file start up to the window start; > 15,000,000 MBO events in a day's window → E960 (narrow the window, e.g.
  `09:30-16:00`).
- **Each file runs on its own**: variables restart each day; a position open at the end is closed at the last trade
  (reason `end_of_data`, counted apart); studies too close to the end are incomplete; only `session.*`/`prev.*` see up
  to 8 previous days.
- **Not available**: `book.*`, footprints, `request(…, symbol:)` (all `na`); nothing is drawn. Trades are complete with
  sweep fields.
- **DEV / VAL declared before running**: "VAL from" (empty = middle day). By default VAL is **not read**; read it once
  the settings are fixed. A sweep in a long backtest uses DEV days only.
- One at a time, stoppable, default time limit 120 min. Errors E960 (a day could not be read), E961 (script failed on a
  day, with date and line).

## Replay, multi-day runs, fixed MBO start

On a chart a strategy reads MBO and book data from a **fixed** start (`mbo_from: auto`: 9:30 if launched during RTH,
else 18:00), so results do not drift as the chart scrolls (`order-flow.md` › How much history). Editing code or a
setting recalculates from the same start in the background; moving Replay before the launch relaunches. Bar window:
last 4,000–8,000 bars at launch (all if fewer), growing to 48,000, then the start moves by 8,000 (the Report says what
is no longer simulated); a strategy reading the footprint gets the last 2,000 bars.

## Honest-simulation rules (apply them, and explain them to the user)

- **Causality is built in, keep it**: no negative history index, `request` returns closed bars only, handlers see only
  the past, body decisions happen at the bar's close and fill after latency on later trades. Do not try to work around
  this (for example by entering at a price observed before the decision).
- **Decide on closed bars** in the body (`bar.confirmed`) so live and history behave the same.
- **Enter at a price you could have had**: market orders fill at the next eligible trade with slippage; a limit at a
  level fills only per the fill model. `through` is the prudent default; `touch` is optimistic; `queue` needs MBO.
- **Costs are mandatory and realistic**: keep at least one tick of slippage and the real commission per side unless
  the user states otherwise; never set them to zero to make results look better.
- **Stops make R meaningful**: with a stop, results are in R; without one, in ticks.
- **Few settings, one judgment**: choose on DEV, prefer a plateau center in a sweep (never "the best value"), then look
  at VAL once. The Report's settings count and day-bootstrap CI are there for this. Never report a DEV result as if it
  were out-of-sample.
- **Normalize on unfiltered populations** (`norm.*` at every event) so thresholds mean what they say.
- Research first: a `research` script tells whether a signal has follow-through before stops, targets and costs are
  layered on.

## Pitfalls

- **Changing the user's strategy**: work on the script they give you; if they did not give it, ask for it. Every
  strategy already has `costs:`: replace its values, do not add a second key. Commission and slippage are header
  literals: they cannot be settings or swept.
- Unknown header keys and unknown `enter()` arguments are ignored: `latancy: 60ms` keeps 60 ms; `stopp: 4 ticks` trades
  without a stop.
- A plain number is points.
- `limit`/`stop` with a `na` price → E939: guard with `not na(x)`.
- The check runs on a short synthetic market: an error behind a condition never true there appears on the chart when
  that line first runs.
- `persist` → E943 in a strategy: use `var`.
- `study`, `report`, `compare` are not allowed in a strategy (E938).
