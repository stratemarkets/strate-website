# Manual review checklist

Use this when `scripts/verify.py` cannot reach Strate, and for the parts the check cannot see (branches never run,
ignored names, meaning). Without the checker, tell the user plainly that the script was not machine-checked.

## Structure
- [ ] At most one header, first statement; name non-empty if the script must go to My indicators, be imported or use
      `persist`.
- [ ] Every header key spelled exactly as in `language.md` (unknown keys are silently ignored).
- [ ] Strategy: `costs: { commission: …, slippage: … }` present with literals; `fill_model` unquoted; `latency` a
      duration.
- [ ] `overlay: false` for anything not on the price scale; no `overlay: false` on a call inside an overlay script.
- [ ] Functions, types, enums, methods, handlers, patterns, clocks, imports at the top level.
- [ ] `var`/`state`/`const`/`persist` at the top level, with an initial value.

## Names and syntax
- [ ] ASCII names, no reserved word as a name (`in`, `on`, `type`, `when`…).
- [ ] Strings in double quotes on one line; colors `#RRGGBB[AA]`; `0.5` not `.5`.
- [ ] Durations attached (`30s`, `5m`); quantities with a space (`4 ticks`); no unit after a variable (`price(n)`).
- [ ] `==` in conditions; no chained comparisons; positional arguments before named ones.
- [ ] Every function, field and method exists in the references with that exact spelling (e.g. `book.imbalance()`
      with parentheses, `mbo.level(…)`, `t.sweep_end`).
- [ ] Every named argument exists for that function (unknown ones are silently ignored).
- [ ] Each pattern has `on:` and exactly one `when`; only `on side price cooldown confirm show` as settings.

## Values
- [ ] Comparisons that may involve `na` are guarded (`na(x)`, `nz(x)`); `limit`/`stop` entries have a non-`na` price.
- [ ] Text concatenation uses `str(x)`.
- [ ] Durations compared with durations (`d > 5s`, or `d / 1s > 5`).
- [ ] History only on top-level variables or built-in series; never negative; no `bar.footprint` in handlers.
- [ ] Variables first assigned in a block and read outside are declared at the top level first.
- [ ] Every function that returns a value uses `return`.
- [ ] Values shared with handlers are `state`; per-bar accumulators reset at the end of the body.
- [ ] Stop/target/cost/slippage: plain numbers are points; ticks written `N ticks` or `price(n)`.

## Data
- [ ] `mbo.level` windows ≤ `level_history:`; `of.*` windows ≤ `flow_history:`.
- [ ] Data loaded by name (`on trade`, `mbo.`, `book`, `footprint`…), not through an alias variable.
- [ ] Research driven by bars has `on trade(t) { }`.
- [ ] A pattern `on: trade` using sweep fields also names one of them (or `mbo.`) so MBO is loaded.
- [ ] Order tracking handles ids first seen at a cancel/modify/fill (orders resting before the data started), and
      "canceled" means what the user meant (whole or partial).
- [ ] MBO/book needs stated to the user; `mbo.available` / `na(t.levels)` tested where it matters.
- [ ] Not relying on book, footprint, drawings or `request(…, symbol:)` in a long backtest.

## Budget
- [ ] No loop over 10,000 steps; no scan of a large collection on every event; maps keyed by order id pruned.

## Time and history
- [ ] Handlers/patterns use `session.in(range, event.time)` when the event's time matters; body entries filter on
      `bar.close_time`.
- [ ] Crossings of a level that changes by steps are guarded (`lvl == lvl[1]`).
- [ ] Previous-day values (`prev.*`, `request("1d", …)`) handled when `na`; the user told which "previous day" it is
      (RTH or full session).
- [ ] The user told how far back the script sees (MBO 30 min by default for an indicator, fixed start for strategies).

## Principles
- [ ] Every threshold, window and color the user may tune is an `input.*`, grouped and titled clearly, including
      horizons hidden in words ("holds", "near", "after").
- [ ] Units of the user's numbers stated (ticks or points); setting titles carry their unit.
- [ ] User-visible texts in one language.
- [ ] Normalizations (`norm.*`) and stateful functions computed at every event, before filters.
- [ ] Signals and entries in the body require `bar.confirmed` when they must not flicker live.
- [ ] Nothing presented as an "optimal" setting; costs realistic; results judged on VAL, plateau not best point.
